/**
 * PyIDLE Mobile & Desktop - Theme Presets & Custom Configuration
 * Authentic IDLE customization with 8 pre-built themes and full element color customizer.
 */

export type PresetThemeId =
  | 'idle-dark'
  | 'idle-classic'
  | 'monokai'
  | 'dracula'
  | 'solarized'
  | 'nord'
  | 'matrix'
  | 'sepia'
  | 'custom';

export interface ThemeColors {
  bg: string;
  text: string;
  gutterBg: string;
  gutterText: string;
  keyword: string;
  builtin: string;
  string: string;
  comment: string;
  definition: string;
  number: string;
  error: string;
  prompt: string;
  accent: string;
  headerBg: string;
  headerBorder: string;
}

export interface IDLEPreferences {
  themeId: PresetThemeId;
  colors: ThemeColors;
  fontSize: number;
  fontFamily: string;
  indentWidth: number;
  showLineNumbers: boolean;
}

export const PRESET_THEMES: Record<Exclude<PresetThemeId, 'custom'>, { name: string; description: string; colors: ThemeColors }> = {
  'idle-dark': {
    name: 'IDLE Dark Modern',
    description: 'Modern official Python IDLE dark mode with vibrant highlights',
    colors: {
      bg: '#181825',
      text: '#cdd6f4',
      gutterBg: '#1e1e2e',
      gutterText: '#6c7086',
      keyword: '#ff9d00',
      builtin: '#cba6f7',
      string: '#a6e3a1',
      comment: '#e06c75',
      definition: '#61afef',
      number: '#fab387',
      error: '#f38ba8',
      prompt: '#fab387',
      accent: '#6366f1',
      headerBg: '#11111b',
      headerBorder: '#313244',
    },
  },
  'idle-classic': {
    name: 'IDLE Classic White',
    description: 'Original Python IDLE light palette from official CPython desktop',
    colors: {
      bg: '#ffffff',
      text: '#000000',
      gutterBg: '#f1f5f9',
      gutterText: '#94a3b8',
      keyword: '#ff7700',
      builtin: '#900090',
      string: '#00aa00',
      comment: '#dd0000',
      definition: '#0000ff',
      number: '#000000',
      error: '#ff0000',
      prompt: '#770000',
      accent: '#2563eb',
      headerBg: '#e2e8f0',
      headerBorder: '#cbd5e1',
    },
  },
  'monokai': {
    name: 'Monokai Pro',
    description: 'Classic warm contrast with vivid yellow, pink, and cyan highlights',
    colors: {
      bg: '#272822',
      text: '#f8f8f2',
      gutterBg: '#1e1f1c',
      gutterText: '#75715e',
      keyword: '#f92672',
      builtin: '#66d9ef',
      string: '#e6db74',
      comment: '#75715e',
      definition: '#a6e22e',
      number: '#ae81ff',
      error: '#f92672',
      prompt: '#fd971f',
      accent: '#a6e22e',
      headerBg: '#1b1c18',
      headerBorder: '#3e3d32',
    },
  },
  'dracula': {
    name: 'Dracula Vampire',
    description: 'Famous gothic dark purple aesthetic with neon accents',
    colors: {
      bg: '#282a36',
      text: '#f8f8f2',
      gutterBg: '#21222c',
      gutterText: '#6272a4',
      keyword: '#ff79c6',
      builtin: '#bd93f9',
      string: '#f1fa8c',
      comment: '#6272a4',
      definition: '#50fa7b',
      number: '#bd93f9',
      error: '#ff5555',
      prompt: '#ffb86c',
      accent: '#bd93f9',
      headerBg: '#191a21',
      headerBorder: '#44475a',
    },
  },
  'nord': {
    name: 'Nord Arctic',
    description: 'Calm arctic icy pastel palette with polar night background',
    colors: {
      bg: '#2e3440',
      text: '#eceff4',
      gutterBg: '#272c36',
      gutterText: '#4c566a',
      keyword: '#81a1c1',
      builtin: '#88c0d0',
      string: '#a3be8c',
      comment: '#616e88',
      definition: '#8fbcbb',
      number: '#b48ead',
      error: '#bf616a',
      prompt: '#d08770',
      accent: '#88c0d0',
      headerBg: '#232831',
      headerBorder: '#434c5e',
    },
  },
  'solarized': {
    name: 'Solarized Dark',
    description: 'Scientifically engineered low-contrast palette easy on eyes',
    colors: {
      bg: '#002b36',
      text: '#839496',
      gutterBg: '#073642',
      gutterText: '#586e75',
      keyword: '#859900',
      builtin: '#268bd2',
      string: '#2aa198',
      comment: '#586e75',
      definition: '#b58900',
      number: '#d33682',
      error: '#dc322f',
      prompt: '#cb4b16',
      accent: '#2aa198',
      headerBg: '#00212b',
      headerBorder: '#073642',
    },
  },
  'matrix': {
    name: 'Cyberpunk Matrix',
    description: 'Retro futuristic hacker terminal with phosphor green & cyber cyan',
    colors: {
      bg: '#0a0f0d',
      text: '#00ff66',
      gutterBg: '#060a08',
      gutterText: '#007733',
      keyword: '#00ffcc',
      builtin: '#33ff99',
      string: '#99ff33',
      comment: '#008844',
      definition: '#00eeff',
      number: '#00ffaa',
      error: '#ff3366',
      prompt: '#00ff66',
      accent: '#00ff66',
      headerBg: '#050807',
      headerBorder: '#004422',
    },
  },
  'sepia': {
    name: 'Vintage Paper',
    description: 'Warm cream book parchment for comfortable daylight writing',
    colors: {
      bg: '#fbf0d9',
      text: '#433422',
      gutterBg: '#f2e2c2',
      gutterText: '#9c8b74',
      keyword: '#a04000',
      builtin: '#6c3483',
      string: '#196f3d',
      comment: '#922b21',
      definition: '#1f618d',
      number: '#b9770e',
      error: '#c0392b',
      prompt: '#7e5109',
      accent: '#a04000',
      headerBg: '#ebd5b3',
      headerBorder: '#d6be96',
    },
  },
};

const PREFERENCES_KEY = 'pyidle_custom_preferences_v2';

export const DEFAULT_PREFERENCES: IDLEPreferences = {
  themeId: 'idle-dark',
  colors: PRESET_THEMES['idle-dark'].colors,
  fontSize: 13,
  fontFamily: 'JetBrains Mono',
  indentWidth: 4,
  showLineNumbers: true,
};

export function loadIDLEPreferences(): IDLEPreferences {
  if (typeof window === 'undefined') return DEFAULT_PREFERENCES;
  try {
    const saved = localStorage.getItem(PREFERENCES_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...DEFAULT_PREFERENCES,
        ...parsed,
        colors: {
          ...DEFAULT_PREFERENCES.colors,
          ...(parsed.colors || {}),
        },
      };
    }
  } catch (e) {
    console.warn('Failed to parse preferences from localStorage:', e);
  }
  return DEFAULT_PREFERENCES;
}

export function saveIDLEPreferences(prefs: IDLEPreferences): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(PREFERENCES_KEY, JSON.stringify(prefs));
  } catch (e) {
    console.error('Error saving preferences:', e);
  }
}
