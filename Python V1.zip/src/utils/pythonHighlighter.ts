/**
 * Python IDLE Syntax Tokenizer & Highlighter
 * Produces authentic IDLE color spans for Python source code.
 * Supports custom dynamic ThemeColors for complete customization.
 */

import { ThemeColors } from './themePresets';

export interface TokenSpan {
  type: 'keyword' | 'builtin' | 'string' | 'comment' | 'number' | 'definition' | 'operator' | 'plain';
  text: string;
}

const PYTHON_KEYWORDS = new Set([
  'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue',
  'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from',
  'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not',
  'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield'
]);

const PYTHON_BUILTINS = new Set([
  'abs', 'all', 'any', 'ascii', 'bin', 'bool', 'breakpoint', 'bytearray',
  'bytes', 'callable', 'chr', 'classmethod', 'compile', 'complex', 'delattr',
  'dict', 'dir', 'divmod', 'enumerate', 'eval', 'exec', 'filter', 'float',
  'format', 'frozenset', 'getattr', 'globals', 'hasattr', 'hash', 'help',
  'hex', 'id', 'input', 'int', 'isinstance', 'issubclass', 'iter', 'len',
  'list', 'locals', 'map', 'max', 'memoryview', 'min', 'next', 'object',
  'oct', 'open', 'ord', 'pow', 'print', 'property', 'range', 'repr',
  'reversed', 'round', 'set', 'setattr', 'slice', 'sorted', 'staticmethod',
  'str', 'sum', 'super', 'tuple', 'type', 'vars', 'zip',
  'True', 'False', 'None', 'Ellipsis', 'NotImplemented'
]);

/**
 * Tokenize a line of Python code for IDLE highlighting
 */
export function tokenizePythonLine(line: string): TokenSpan[] {
  const tokens: TokenSpan[] = [];
  let i = 0;
  const len = line.length;

  while (i < len) {
    const char = line[i];

    // 1. Comments: from '#' to end of line
    if (char === '#') {
      tokens.push({ type: 'comment', text: line.slice(i) });
      break;
    }

    // 2. Strings: '...', "...", '''...''', """..."""
    if (char === '"' || char === "'") {
      const quoteChar = char;
      const isTriple = line.slice(i, i + 3) === quoteChar.repeat(3);
      const quoteLen = isTriple ? 3 : 1;
      let j = i + quoteLen;
      let escaped = false;

      while (j < len) {
        if (!escaped && line.slice(j, j + quoteLen) === quoteChar.repeat(quoteLen)) {
          j += quoteLen;
          break;
        }
        if (line[j] === '\\' && !escaped) {
          escaped = true;
        } else {
          escaped = false;
        }
        j++;
      }

      tokens.push({ type: 'string', text: line.slice(i, j) });
      i = j;
      continue;
    }

    // 3. String prefixes: f"...", r"...", b"..."
    if (
      (char === 'f' || char === 'r' || char === 'b' || char === 'u' || char === 'F' || char === 'R' || char === 'B') &&
      (line[i + 1] === '"' || line[i + 1] === "'")
    ) {
      const quoteChar = line[i + 1];
      let j = i + 2;
      let escaped = false;
      while (j < len) {
        if (!escaped && line[j] === quoteChar) {
          j++;
          break;
        }
        escaped = line[j] === '\\' && !escaped;
        j++;
      }
      tokens.push({ type: 'string', text: line.slice(i, j) });
      i = j;
      continue;
    }

    // 4. Numbers
    if (/[0-9]/.test(char) || (char === '.' && /[0-9]/.test(line[i + 1] || ''))) {
      let j = i;
      while (j < len && /[0-9a-fA-FxXoObB._]/.test(line[j])) {
        j++;
      }
      tokens.push({ type: 'number', text: line.slice(i, j) });
      i = j;
      continue;
    }

    // 5. Identifiers / Keywords / Builtins
    if (/[a-zA-Z_]/.test(char)) {
      let j = i;
      while (j < len && /[a-zA-Z0-9_]/.test(line[j])) {
        j++;
      }
      const word = line.slice(i, j);

      // Check if previous non-whitespace token was 'def' or 'class'
      const prevToken = tokens.filter((t) => t.type !== 'plain' || t.text.trim().length > 0).slice(-1)[0];
      const isDefinition = prevToken && (prevToken.text === 'def' || prevToken.text === 'class');

      if (isDefinition) {
        tokens.push({ type: 'definition', text: word });
      } else if (PYTHON_KEYWORDS.has(word)) {
        tokens.push({ type: 'keyword', text: word });
      } else if (PYTHON_BUILTINS.has(word)) {
        tokens.push({ type: 'builtin', text: word });
      } else {
        tokens.push({ type: 'plain', text: word });
      }
      i = j;
      continue;
    }

    // 6. Whitespace and Operators
    let j = i;
    while (j < len && !/[a-zA-Z0-9_#"']/.test(line[j])) {
      j++;
    }
    tokens.push({ type: 'plain', text: line.slice(i, j) });
    i = j;
  }

  return tokens;
}

/**
 * Get dynamic CSS style object based on user's custom ThemeColors
 */
export function getTokenStyle(type: TokenSpan['type'], colors: ThemeColors): React.CSSProperties {
  switch (type) {
    case 'keyword':
      return { color: colors.keyword, fontWeight: 600 };
    case 'builtin':
      return { color: colors.builtin, fontWeight: 500 };
    case 'string':
      return { color: colors.string };
    case 'comment':
      return { color: colors.comment, fontStyle: 'italic' };
    case 'definition':
      return { color: colors.definition, fontWeight: 600 };
    case 'number':
      return { color: colors.number };
    case 'operator':
      return { color: colors.text };
    default:
      return { color: colors.text };
  }
}
