/**
 * PyIDLE Mobile & Desktop - Quick App / Assistant Launcher Utility
 * Allows user to configure an option inside the 3-dot drawer (defaulting to ChatGPT)
 * or choose Gemini, Claude, DeepSeek, Perplexity, or custom apps.
 * Dynamically displays the selected app's name and launches it when clicked.
 */

export interface QuickAppConfig {
  id: string;
  name: string;
  description: string;
  url: string;
  iconType: 'chatgpt' | 'gemini' | 'claude' | 'deepseek' | 'perplexity' | 'custom';
  color: string;
}

export const PRESET_QUICK_APPS: QuickAppConfig[] = [
  {
    id: 'chatgpt',
    name: 'ChatGPT',
    description: 'Open ChatGPT app or web assistant',
    url: 'https://chatgpt.com',
    iconType: 'chatgpt',
    color: '#10a37f', // OpenAI emerald
  },
  {
    id: 'gemini',
    name: 'Gemini',
    description: 'Open Google Gemini assistant',
    url: 'https://gemini.google.com',
    iconType: 'gemini',
    color: '#4285f4', // Google blue
  },
  {
    id: 'claude',
    name: 'Claude',
    description: 'Open Anthropic Claude assistant',
    url: 'https://claude.ai',
    iconType: 'claude',
    color: '#d97706', // Anthropic amber/terracotta
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    description: 'Open DeepSeek AI coder & assistant',
    url: 'https://chat.deepseek.com',
    iconType: 'deepseek',
    color: '#0284c7', // DeepSeek ocean blue
  },
  {
    id: 'perplexity',
    name: 'Perplexity',
    description: 'Open Perplexity AI research search',
    url: 'https://www.perplexity.ai',
    iconType: 'perplexity',
    color: '#0d9488', // Perplexity teal
  },
];

const STORAGE_KEY = 'pyidle_selected_quick_app_v1';
const CUSTOM_APPS_KEY = 'pyidle_custom_quick_apps_v1';

export function loadSelectedQuickApp(): QuickAppConfig {
  if (typeof window === 'undefined') return PRESET_QUICK_APPS[0];
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && parsed.name && parsed.url) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Error reading saved quick app:', e);
  }
  // Default to ChatGPT as requested by user
  return PRESET_QUICK_APPS[0];
}

export function saveSelectedQuickApp(app: QuickAppConfig): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(app));
  } catch (e) {
    console.error('Error saving quick app:', e);
  }
}

export function loadCustomQuickApps(): QuickAppConfig[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem(CUSTOM_APPS_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.warn('Error reading custom apps:', e);
  }
  return [];
}

export function saveCustomQuickApps(apps: QuickAppConfig[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(CUSTOM_APPS_KEY, JSON.stringify(apps));
  } catch (e) {
    console.error('Error saving custom quick apps:', e);
  }
}

/**
 * Launch the app safely in a new browser tab or trigger Android native app intent
 */
export function launchExternalApp(app: QuickAppConfig): void {
  if (!app || !app.url) return;
  
  // Create a real link click to trigger browser / native app association
  const link = document.createElement('a');
  link.href = app.url;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
