/**
 * PyIDLE Mobile - File Management System
 * LocalStorage persistent Virtual File System for Android Python IDE.
 * Allows creating files, folders, saving scripts, opening files, renaming,
 * importing from device storage, and exporting to .py files.
 */

import { FileItem, FolderItem, FileSystemState } from '../types';

const STORAGE_KEY = 'pyidle_android_vfs_v1';

const DEFAULT_FILES: FileItem[] = [
  {
    id: 'f_welcome',
    name: 'main.py',
    folderId: null,
    createdAt: Date.now() - 3600000,
    updatedAt: Date.now() - 3600000,
    content: `# Python V1 - Python 3 IDLE for Android & PC
# Run this script with the ▶ Run button or F5

import sys
import math

print("=" * 45)
print(" Welcome to Python V1 (Python 3.12)!")
print("=" * 45)
print(f"Python Platform: {sys.platform}")
print(f"Version: {sys.version.split()[0]}")

# Quick math demonstration
r = 7.5
area = math.pi * (r ** 2)
print(f"\\nCalculated Circle Area (r={r}): {area:.4f}")

# You can also use the Pip Manager to download
# packages like numpy, pandas, matplotlib, pygame!
print("\\nTip: Tap the 'Pip' tab to download packages!")
`,
  },
  {
    id: 'f_numpy',
    name: 'numpy_matrix.py',
    folderId: 'folder_science',
    createdAt: Date.now() - 7200000,
    updatedAt: Date.now() - 7200000,
    content: `# NumPy Numerical Computing Demo
# Tap 'Pip' -> Download 'numpy' first if not already loaded!

try:
    import numpy as np

    print("--- NumPy Array Operations ---")
    A = np.array([[2, 1], [1, 3]], dtype=float)
    B = np.array([[5, -1], [0, 4]], dtype=float)

    print("Matrix A:\\n", A)
    print("Matrix B:\\n", B)
    print("\\nMatrix Product (A @ B):\\n", A @ B)

    # Eigenvalues
    eigenvalues, eigenvectors = np.linalg.eig(A)
    print("\\nEigenvalues of A:", eigenvalues)

    # Random distribution stats
    data = np.random.normal(loc=50.0, scale=10.0, size=1000)
    print(f"\\nGenerated 1,000 normal samples: Mean={data.mean():.2f}, Std={data.std():.2f}")

except ImportError:
    print("[Notice] NumPy is not installed yet.")
    print("Please open the 'Pip' manager and install 'numpy'!")
`,
  },
  {
    id: 'f_pygame',
    name: 'touch_game.py',
    folderId: 'folder_games',
    createdAt: Date.now() - 10800000,
    updatedAt: Date.now() - 10800000,
    content: `# Pygame 2D Mobile Touch Canvas Game
# Runs directly on the Graphics Display canvas!

import pygame
import math
import random

pygame.init()
screen = pygame.display.set_mode((360, 320))
pygame.display.set_caption("Python V1 Touch Bounce")

# Clear background
screen.fill((20, 24, 39))

# Draw game arena borders
pygame.draw.rect(screen, (79, 70, 229), (10, 10, 340, 300), 2)

# Draw colorful game objects
colors = [(239, 68, 68), (59, 130, 246), (16, 185, 129), (245, 158, 11), (168, 85, 247)]

for i in range(12):
    cx = random.randint(40, 320)
    cy = random.randint(40, 280)
    radius = random.randint(12, 28)
    col = random.choice(colors)
    pygame.draw.circle(screen, col, (cx, cy), radius)

# Draw player paddle
pygame.draw.rect(screen, (255, 255, 255), (130, 280, 100, 14))

# Commit frame to screen
pygame.display.flip()

print("[Game] Pygame frame rendered to Graphics Display!")
print("Tap 'Graphics' in the bottom navigation to view it.")
`,
  },
  {
    id: 'f_plot',
    name: 'matplotlib_demo.py',
    folderId: 'folder_science',
    createdAt: Date.now() - 14400000,
    updatedAt: Date.now() - 14400000,
    content: `# Matplotlib Scientific Plotting
# Install 'matplotlib' from Pip Manager to generate plots!

try:
    import matplotlib.pyplot as plt
    import numpy as np

    x = np.linspace(0, 4 * np.pi, 200)
    y_sin = np.sin(x)
    y_cos = np.cos(x)

    plt.figure(figsize=(7, 4.2))
    plt.plot(x, y_sin, label='sin(x)', color='#4f46e5', linewidth=2.5)
    plt.plot(x, y_cos, label='cos(x)', color='#ec4899', linewidth=2.5, linestyle='--')
    plt.title('Harmonic Oscillations', fontsize=14, fontweight='bold', pad=12)
    plt.xlabel('Angle (radians)')
    plt.ylabel('Amplitude')
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend()

    # Automatically exported to Graphics Display window
    plt.show()

except ImportError:
    print("[Notice] Matplotlib is not installed yet.")
    print("Please open the 'Pip' manager and install 'matplotlib'!")
`,
  },
  {
    id: 'f_calc',
    name: 'interactive_calc.py',
    folderId: null,
    createdAt: Date.now() - 18000000,
    updatedAt: Date.now() - 18000000,
    content: `# Interactive Console Script with input()
# Try running this to test interactive IDLE input!

print("=== Quick Python Quiz ===")
name = input("Enter your coder alias: ")
if not name:
    name = "Python Explorer"

print(f"\\nHello, {name}!")
num1 = float(input("Enter first number: ") or "12")
num2 = float(input("Enter second number: ") or "8")

op = input("Choose operation (+, -, *, /): ") or "+"

if op == '+':
    res = num1 + num2
elif op == '-':
    res = num1 - num2
elif op == '*':
    res = num1 * num2
elif op == '/':
    res = num1 / num2 if num2 != 0 else "Error: Division by zero"
else:
    res = "Unknown operation"

print(f"\\nResult: {num1} {op} {num2} = {res}")
print("Thank you for testing Python V1!")
`,
  },
];

const DEFAULT_FOLDERS: FolderItem[] = [
  {
    id: 'folder_science',
    name: 'Data & Science',
    parentId: null,
    createdAt: Date.now() - 86400000,
  },
  {
    id: 'folder_games',
    name: 'Games & Graphics',
    parentId: null,
    createdAt: Date.now() - 86400000,
  },
];

class FileSystemService {
  private state: FileSystemState;

  constructor() {
    this.state = this.loadFromStorage();
  }

  private loadFromStorage(): FileSystemState {
    if (typeof window === 'undefined') {
      return {
        folders: DEFAULT_FOLDERS,
        files: DEFAULT_FILES,
        activeFileId: 'f_welcome',
        openFileIds: ['f_welcome'],
      };
    }

    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.files && parsed.files.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to parse VFS from localStorage:', e);
    }

    const initial: FileSystemState = {
      folders: DEFAULT_FOLDERS,
      files: DEFAULT_FILES,
      activeFileId: 'f_welcome',
      openFileIds: ['f_welcome'],
    };
    this.saveToStorage(initial);
    return initial;
  }

  private saveToStorage(state: FileSystemState): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.error('Error saving VFS to localStorage:', e);
    }
  }

  public getState(): FileSystemState {
    return { ...this.state };
  }

  public getFiles(): FileItem[] {
    return [...this.state.files];
  }

  public getFolders(): FolderItem[] {
    return [...this.state.folders];
  }

  public getFileById(id: string): FileItem | undefined {
    return this.state.files.find((f) => f.id === id);
  }

  public getActiveFile(): FileItem | undefined {
    return this.state.files.find((f) => f.id === this.state.activeFileId);
  }

  public setActiveFileId(id: string): FileSystemState {
    if (!this.state.openFileIds.includes(id)) {
      this.state.openFileIds.push(id);
    }
    this.state.activeFileId = id;
    this.saveToStorage(this.state);
    return this.getState();
  }

  public closeFileTab(id: string): FileSystemState {
    this.state.openFileIds = this.state.openFileIds.filter((fid) => fid !== id);
    if (this.state.activeFileId === id) {
      this.state.activeFileId = this.state.openFileIds[this.state.openFileIds.length - 1] || null;
    }
    this.saveToStorage(this.state);
    return this.getState();
  }

  public createFile(name: string, content: string = '', folderId: string | null = null): FileItem {
    const cleanName = name.endsWith('.py') ? name : `${name}.py`;
    const newFile: FileItem = {
      id: 'f_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      name: cleanName,
      content: content || `# ${cleanName}\n# Created in Python V1\n\nprint("Hello from ${cleanName}!")\n`,
      folderId,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    this.state.files.push(newFile);
    this.setActiveFileId(newFile.id);
    return newFile;
  }

  public createFolder(name: string, parentId: string | null = null): FolderItem {
    const newFolder: FolderItem = {
      id: 'folder_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      name: name.trim(),
      parentId,
      createdAt: Date.now(),
    };

    this.state.folders.push(newFolder);
    this.saveToStorage(this.state);
    return newFolder;
  }

  public saveScript(id: string, content: string): FileItem | undefined {
    const file = this.state.files.find((f) => f.id === id);
    if (file) {
      file.content = content;
      file.updatedAt = Date.now();
      this.saveToStorage(this.state);
    }
    return file;
  }

  public renameFile(id: string, newName: string): boolean {
    const file = this.state.files.find((f) => f.id === id);
    if (file) {
      file.name = newName.endsWith('.py') ? newName : `${newName}.py`;
      file.updatedAt = Date.now();
      this.saveToStorage(this.state);
      return true;
    }
    return false;
  }

  public renameFolder(id: string, newName: string): boolean {
    const folder = this.state.folders.find((f) => f.id === id);
    if (folder) {
      folder.name = newName.trim();
      this.saveToStorage(this.state);
      return true;
    }
    return false;
  }

  public moveFile(fileId: string, targetFolderId: string | null): boolean {
    const file = this.state.files.find((f) => f.id === fileId);
    if (file) {
      file.folderId = targetFolderId;
      file.updatedAt = Date.now();
      this.saveToStorage(this.state);
      return true;
    }
    return false;
  }

  public deleteFile(id: string): boolean {
    this.state.files = this.state.files.filter((f) => f.id !== id);
    this.state.openFileIds = this.state.openFileIds.filter((fid) => fid !== id);
    if (this.state.activeFileId === id) {
      this.state.activeFileId = this.state.openFileIds[0] || null;
    }
    this.saveToStorage(this.state);
    return true;
  }

  public deleteFolder(id: string): boolean {
    // Delete files inside folder as well or move them to root
    this.state.files = this.state.files.filter((f) => f.folderId !== id);
    this.state.folders = this.state.folders.filter((f) => f.id !== id);
    // Recalculate open and active files
    const remainingIds = new Set(this.state.files.map((f) => f.id));
    this.state.openFileIds = this.state.openFileIds.filter((fid) => remainingIds.has(fid));
    if (!this.state.activeFileId || !remainingIds.has(this.state.activeFileId)) {
      this.state.activeFileId = this.state.openFileIds[0] || (this.state.files[0]?.id ?? null);
    }
    this.saveToStorage(this.state);
    return true;
  }

  public duplicateFile(id: string): FileItem | undefined {
    const file = this.state.files.find((f) => f.id === id);
    if (!file) return undefined;

    const baseName = file.name.replace(/\.py$/, '');
    const copyName = `${baseName}_copy.py`;
    return this.createFile(copyName, file.content, file.folderId);
  }

  /**
   * Export / Download script to Android device file system
   */
  public downloadFile(id: string): void {
    const file = this.state.files.find((f) => f.id === id);
    if (!file) return;

    const blob = new Blob([file.content], { type: 'text/x-python;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /**
   * Import file from user's device via file input
   */
  public async importFromFileObject(file: File, folderId: string | null = null): Promise<FileItem> {
    const text = await file.text();
    const fileName = file.name.endsWith('.py') ? file.name : `${file.name}.py`;
    return this.createFile(fileName, text, folderId);
  }

  /**
   * Reset to default demo files
   */
  public resetToDefaults(): FileSystemState {
    this.state = {
      folders: DEFAULT_FOLDERS,
      files: DEFAULT_FILES,
      activeFileId: 'f_welcome',
      openFileIds: ['f_welcome'],
    };
    this.saveToStorage(this.state);
    return this.getState();
  }
}

export const fileSystemService = new FileSystemService();
