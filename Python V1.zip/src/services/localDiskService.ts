/**
 * PyIDLE & Pydroid - Local Hard Drive & Device Storage File Bridge
 * Uses the Web File System Access API (showDirectoryPicker) to give Python scripts
 * real read/write access to folders on Windows PC hard drives and Android phone storage.
 * Synchronizes with Pyodide's CPython virtual filesystem (pyodide.FS).
 */

import { FileItem, FolderItem } from '../types';
import { pyodideService } from './pyodideService';

export interface MountedDiskFolder {
  name: string;
  handle: any; // FileSystemDirectoryHandle
  filesCount: number;
}

class LocalDiskService {
  private dirHandle: any = null;
  private isSupported: boolean = false;
  private mountedFolderName: string | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.isSupported = 'showDirectoryPicker' in window;
    }
  }

  public getIsSupported(): boolean {
    return this.isSupported;
  }

  public getMountedFolderName(): string | null {
    return this.mountedFolderName;
  }

  /**
   * Prompts user to pick a real folder on their Windows PC hard drive or phone storage.
   * Gives Python real read/write access to those files!
   */
  public async mountLocalFolder(): Promise<{ files: FileItem[]; folderName: string } | null> {
    if (!this.isSupported) {
      alert(
        'Direct Hard Drive Access via showDirectoryPicker is supported in Chrome, Edge, and modern Android Chromium browsers. Using device import/export fallback.'
      );
      return null;
    }

    try {
      const dirHandle = await (window as any).showDirectoryPicker({
        mode: 'readwrite',
      });

      this.dirHandle = dirHandle;
      this.mountedFolderName = dirHandle.name;

      const loadedFiles: FileItem[] = [];
      await this.readDirectoryRecursive(dirHandle, '', loadedFiles);

      // Also sync loaded files into Pyodide's CPython filesystem so open('file.py') works
      await this.syncToPyodideFS(loadedFiles);

      return {
        files: loadedFiles,
        folderName: dirHandle.name,
      };
    } catch (err: any) {
      if (err.name === 'AbortError') {
        return null; // User cancelled picker
      }
      console.error('Error mounting local directory:', err);
      throw err;
    }
  }

  private async readDirectoryRecursive(
    handle: any,
    currentPath: string,
    resultFiles: FileItem[]
  ): Promise<void> {
    for await (const entry of handle.values()) {
      if (entry.kind === 'file') {
        // Read file content
        const fileObj = await entry.getFile();
        const text = await fileObj.text();
        const relativeName = currentPath ? `${currentPath}/${entry.name}` : entry.name;

        resultFiles.push({
          id: 'disk_' + Math.random().toString(36).substring(2, 9),
          name: relativeName,
          content: text,
          folderId: null,
          createdAt: fileObj.lastModified || Date.now(),
          updatedAt: fileObj.lastModified || Date.now(),
        });
      } else if (entry.kind === 'directory') {
        const nextPath = currentPath ? `${currentPath}/${entry.name}` : entry.name;
        await this.readDirectoryRecursive(entry, nextPath, resultFiles);
      }
    }
  }

  /**
   * Writes updated code directly to the real file on the Windows PC / phone hard drive
   */
  public async saveFileToDisk(fileName: string, content: string): Promise<boolean> {
    if (!this.dirHandle) return false;

    try {
      // Split path in case of subfolders
      const parts = fileName.split('/');
      let currentDir = this.dirHandle;

      for (let i = 0; i < parts.length - 1; i++) {
        currentDir = await currentDir.getDirectoryHandle(parts[i], { create: true });
      }

      const fileHandle = await currentDir.getFileHandle(parts[parts.length - 1], { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(content);
      await writable.close();

      // Also update Pyodide's FS
      const pyodide = (window as any).pyodideInstance;
      if (pyodide && pyodide.FS) {
        try {
          pyodide.FS.writeFile(fileName, content);
        } catch (e) {
          // ignore
        }
      }

      return true;
    } catch (err) {
      console.error('Failed to write directly to hard drive:', err);
      return false;
    }
  }

  /**
   * Syncs files into Pyodide WebAssembly's virtual root so standard Python scripts
   * like `with open("data.txt") as f:` or `import os; os.listdir()` see the real files!
   */
  public async syncToPyodideFS(files: FileItem[]): Promise<void> {
    const pyodide = (window as any).pyodideInstance;
    if (!pyodide || !pyodide.FS) return;

    for (const f of files) {
      try {
        const pathParts = f.name.split('/');
        let dir = '';
        for (let i = 0; i < pathParts.length - 1; i++) {
          dir = dir ? `${dir}/${pathParts[i]}` : pathParts[i];
          try {
            pyodide.FS.mkdir(dir);
          } catch (e) {
            // directory might already exist
          }
        }
        pyodide.FS.writeFile(f.name, f.content);
      } catch (err) {
        console.warn('Failed to sync file to Pyodide FS:', f.name, err);
      }
    }

    // Run quick python sync script to update os.getcwd()
    try {
      await pyodide.runPythonAsync(`
import os
try:
    files_in_dir = os.listdir('.')
    print(f"[Storage] Python working directory synchronized ({len(files_in_dir)} files accessible via open())")
except Exception:
    pass
`);
    } catch (e) {
      // ignore
    }
  }

  /**
   * After Python script execution, check if any new files were created in Pyodide.FS
   * and sync them back to the user's hard drive!
   */
  public async syncPyodideOutputToDisk(): Promise<void> {
    if (!this.dirHandle) return;
    const pyodide = (window as any).pyodideInstance;
    if (!pyodide || !pyodide.FS) return;

    try {
      const files = pyodide.FS.readdir('.');
      for (const fname of files) {
        if (fname === '.' || fname === '..' || fname === 'tmp' || fname === 'home' || fname === 'dev' || fname === 'proc') continue;
        try {
          const stat = pyodide.FS.stat(fname);
          if (pyodide.FS.isFile(stat.mode)) {
            const content = pyodide.FS.readFile(fname, { encoding: 'utf8' });
            await this.saveFileToDisk(fname, content);
          }
        } catch (e) {
          // ignore non-text or binary
        }
      }
    } catch (err) {
      console.warn('Error syncing Pyodide output to disk:', err);
    }
  }
}

export const localDiskService = new LocalDiskService();
