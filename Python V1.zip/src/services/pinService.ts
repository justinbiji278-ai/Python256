/**
 * Python V1 - Security Service
 * Handles persistent app lock PIN/password verification, failsafe verification,
 * and secure credential updates.
 * Initial PIN is 4971.
 * Initial Failsafe is "8.5/70".
 */

const PIN_STORAGE_KEY = 'python_v1_app_pin';
const FAILSAFE_STORAGE_KEY = 'python_v1_failsafe';

export const INITIAL_PIN = '4971';
export const INITIAL_FAILSAFE = '8.5/70';

export const pinService = {
  getPin(): string {
    if (typeof window === 'undefined') return INITIAL_PIN;
    return localStorage.getItem(PIN_STORAGE_KEY) || INITIAL_PIN;
  },

  verifyPin(inputPin: string): boolean {
    return inputPin.trim() === this.getPin().trim();
  },

  setPin(newPin: string): boolean {
    if (typeof window === 'undefined') return false;
    if (!newPin || newPin.trim().length === 0) return false;
    try {
      localStorage.setItem(PIN_STORAGE_KEY, newPin.trim());
      return true;
    } catch (e) {
      console.error('Failed to save new PIN:', e);
      return false;
    }
  },

  getFailsafe(): string {
    if (typeof window === 'undefined') return INITIAL_FAILSAFE;
    return localStorage.getItem(FAILSAFE_STORAGE_KEY) || INITIAL_FAILSAFE;
  },

  verifyFailsafe(inputFailsafe: string): boolean {
    return inputFailsafe.trim() === this.getFailsafe().trim();
  },

  setFailsafe(newFailsafe: string): boolean {
    if (typeof window === 'undefined') return false;
    if (!newFailsafe || newFailsafe.trim().length === 0) return false;
    try {
      localStorage.setItem(FAILSAFE_STORAGE_KEY, newFailsafe.trim());
      return true;
    } catch (e) {
      console.error('Failed to save new failsafe:', e);
      return false;
    }
  },
};
