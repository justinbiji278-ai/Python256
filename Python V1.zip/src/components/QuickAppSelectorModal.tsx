/**
 * PyIDLE Mobile & Desktop - Quick App / Assistant Selector Modal
 * Allows switching the 3-dot menu shortcut between ChatGPT, Gemini, Claude,
 * DeepSeek, Perplexity, or custom apps.
 */

import React, { useState } from 'react';
import {
  X, Check, Plus, ExternalLink, Globe, Sparkles,
  Bot, MessageSquare, Compass, ArrowRight, Trash2
} from 'lucide-react';
import {
  QuickAppConfig, PRESET_QUICK_APPS,
  loadCustomQuickApps, saveCustomQuickApps
} from '../utils/quickAppLauncher';
import { ThemeColors } from '../utils/themePresets';

interface QuickAppSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedApp: QuickAppConfig;
  onSelectApp: (app: QuickAppConfig) => void;
  colors: ThemeColors;
}

export const QuickAppSelectorModal: React.FC<QuickAppSelectorModalProps> = ({
  isOpen,
  onClose,
  selectedApp,
  onSelectApp,
  colors,
}) => {
  const [customApps, setCustomApps] = useState<QuickAppConfig[]>(loadCustomQuickApps());
  const [isAddingCustom, setIsAddingCustom] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customUrl, setCustomUrl] = useState('');
  const [customDesc, setCustomDesc] = useState('');

  if (!isOpen) return null;

  const handleSelect = (app: QuickAppConfig) => {
    onSelectApp(app);
    onClose();
  };

  const handleSaveCustomApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim() || !customUrl.trim()) return;

    let finalUrl = customUrl.trim();
    if (!/^https?:\/\//i.test(finalUrl) && !/^[a-z0-9_-]+:\/\//i.test(finalUrl)) {
      finalUrl = 'https://' + finalUrl;
    }

    const newApp: QuickAppConfig = {
      id: 'custom_' + Date.now(),
      name: customName.trim(),
      description: customDesc.trim() || `Open ${customName.trim()}`,
      url: finalUrl,
      iconType: 'custom',
      color: '#8b5cf6', // Violet
    };

    const updated = [...customApps, newApp];
    setCustomApps(updated);
    saveCustomQuickApps(updated);
    onSelectApp(newApp);
    setIsAddingCustom(false);
    setCustomName('');
    setCustomUrl('');
    setCustomDesc('');
    onClose();
  };

  const handleDeleteCustomApp = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const updated = customApps.filter((a) => a.id !== id);
    setCustomApps(updated);
    saveCustomQuickApps(updated);
    if (selectedApp.id === id) {
      onSelectApp(PRESET_QUICK_APPS[0]); // Fall back to ChatGPT
    }
  };

  const renderIcon = (app: QuickAppConfig) => {
    switch (app.iconType) {
      case 'chatgpt':
        return (
          <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow">
            <Bot className="w-5 h-5" />
          </div>
        );
      case 'gemini':
        return (
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-500 to-amber-400 text-white flex items-center justify-center shadow">
            <Sparkles className="w-5 h-5" />
          </div>
        );
      case 'claude':
        return (
          <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center font-bold text-sm shadow">
            <MessageSquare className="w-5 h-5" />
          </div>
        );
      case 'deepseek':
        return (
          <div className="w-9 h-9 rounded-xl bg-sky-600 text-white flex items-center justify-center font-bold text-sm shadow">
            <Compass className="w-5 h-5" />
          </div>
        );
      case 'perplexity':
        return (
          <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-sm shadow">
            <Globe className="w-5 h-5" />
          </div>
        );
      default:
        return (
          <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center font-bold text-sm shadow">
            <ExternalLink className="w-5 h-5" />
          </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-xs select-none">
      <div
        className="relative w-full max-w-md max-h-[88vh] rounded-2xl border shadow-2xl flex flex-col overflow-hidden"
        style={{
          backgroundColor: colors.bg,
          borderColor: colors.headerBorder,
          color: colors.text,
        }}
      >
        {/* Header */}
        <div
          className="p-4 border-b flex items-center justify-between shrink-0"
          style={{
            backgroundColor: colors.headerBg,
            borderColor: colors.headerBorder,
          }}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm leading-tight">Quick App Shortcut</h3>
              <p className="text-[11px] opacity-75">
                Current in 3-dot: <span className="font-semibold text-emerald-400">{selectedApp.name}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg opacity-60 hover:opacity-100 transition-opacity"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-4 text-xs">
          <div>
            <div className="px-1 text-[11px] font-bold uppercase tracking-wider mb-2 opacity-65">
              Select Quick Companion App
            </div>
            <div className="space-y-1.5">
              {PRESET_QUICK_APPS.map((app) => {
                const isSelected = selectedApp.id === app.id;
                return (
                  <button
                    key={app.id}
                    onClick={() => handleSelect(app)}
                    className={`w-full p-2.5 rounded-xl border flex items-center justify-between text-left transition-all ${
                      isSelected
                        ? 'border-emerald-500/80 bg-emerald-500/10'
                        : 'border-transparent hover:bg-black/10 dark:hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {renderIcon(app)}
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-xs leading-tight truncate">{app.name}</h4>
                          {isSelected && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500 text-white font-medium">
                              Active in 3-Dot
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] opacity-75 truncate">{app.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {isSelected ? (
                        <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow">
                          <Check className="w-3.5 h-3.5" />
                        </div>
                      ) : (
                        <span className="text-[10px] opacity-50 flex items-center gap-1">
                          Select <ArrowRight className="w-3 h-3" />
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Apps */}
          {customApps.length > 0 && (
            <div>
              <div className="px-1 text-[11px] font-bold uppercase tracking-wider mb-2 opacity-65">
                Custom Configured Apps
              </div>
              <div className="space-y-1.5">
                {customApps.map((app) => {
                  const isSelected = selectedApp.id === app.id;
                  return (
                    <div
                      key={app.id}
                      onClick={() => handleSelect(app)}
                      className={`w-full p-2.5 rounded-xl border flex items-center justify-between text-left cursor-pointer transition-all ${
                        isSelected
                          ? 'border-emerald-500/80 bg-emerald-500/10'
                          : 'border-transparent hover:bg-black/10 dark:hover:bg-white/5'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {renderIcon(app)}
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-xs leading-tight truncate">{app.name}</h4>
                            {isSelected && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500 text-white font-medium">
                                Active in 3-Dot
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] opacity-75 font-mono truncate">{app.url}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {isSelected && (
                          <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center mr-1 shadow">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                        )}
                        <button
                          onClick={(e) => handleDeleteCustomApp(e, app.id)}
                          className="p-1 rounded-lg hover:bg-red-500/20 text-red-400 opacity-70 hover:opacity-100"
                          title="Delete custom app"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Add Custom App Form */}
          {!isAddingCustom ? (
            <button
              onClick={() => setIsAddingCustom(true)}
              className="w-full py-2.5 px-3 rounded-xl border border-dashed flex items-center justify-center gap-2 hover:bg-black/5 dark:hover:bg-white/5 transition-colors opacity-80 hover:opacity-100"
              style={{ borderColor: colors.headerBorder }}
            >
              <Plus className="w-4 h-4 text-emerald-500" />
              <span className="font-semibold text-xs">Add Custom App or Website</span>
            </button>
          ) : (
            <form
              onSubmit={handleSaveCustomApp}
              className="p-3 rounded-xl border space-y-3"
              style={{
                backgroundColor: colors.headerBg,
                borderColor: colors.headerBorder,
              }}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs">Add New App / Website</span>
                <button
                  type="button"
                  onClick={() => setIsAddingCustom(false)}
                  className="opacity-60 hover:opacity-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold mb-1 opacity-70">
                  App Name
                </label>
                <input
                  type="text"
                  placeholder="e.g., Python Docs, GitHub, StackOverflow"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border text-xs focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-black/10 dark:bg-white/5"
                  style={{ borderColor: colors.headerBorder }}
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold mb-1 opacity-70">
                  App URL or Deep Link
                </label>
                <input
                  type="text"
                  placeholder="e.g., docs.python.org or customapp://"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border text-xs font-mono focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-black/10 dark:bg-white/5"
                  style={{ borderColor: colors.headerBorder }}
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold mb-1 opacity-70">
                  Short Description (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g., Official Python Library Reference"
                  value={customDesc}
                  onChange={(e) => setCustomDesc(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border text-xs focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-black/10 dark:bg-white/5"
                  style={{ borderColor: colors.headerBorder }}
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingCustom(false)}
                  className="px-3 py-1.5 rounded-lg opacity-70 hover:opacity-100 text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow"
                >
                  Save &amp; Set as Quick Option
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer info */}
        <div
          className="p-3 border-t flex items-center justify-between text-[11px] opacity-75 shrink-0"
          style={{
            backgroundColor: colors.headerBg,
            borderColor: colors.headerBorder,
          }}
        >
          <span>Opens in new tab or native mobile app</span>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded-lg bg-slate-700/50 hover:bg-slate-700 text-white font-medium"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
