/**
 * PyIDLE Mobile & Desktop - Interactive Python IDLE Shell (Terminal & Interpreter)
 * Provides authentic IDLE REPL with >>> and ... prompts, multiline evaluation,
 * command history navigation, interactive input() handler, and dynamic custom theme colors.
 */

import React, { useState, useRef, useEffect } from 'react';
import { RotateCcw, Trash2, ArrowUp, ArrowDown, Send, CornerDownLeft, Terminal as TermIcon, MoreVertical } from 'lucide-react';
import { ShellMessage } from '../types';
import { IDLEPreferences } from '../utils/themePresets';
import { pyodideService } from '../services/pyodideService';

interface IDLEShellProps {
  preferences: IDLEPreferences;
  onRestartShell: () => void;
  isRunning?: boolean;
  onOpenSidebar?: () => void;
}

const IDLE_BANNER = `Python 3.12.1 (tags/v3.12:pyodide, wasm32) [Emscripten] on Android & PC
Type "help", "copyright", "credits" or "license" for more information.`;

export const IDLEShell: React.FC<IDLEShellProps> = ({
  preferences,
  onRestartShell,
  isRunning = false,
  onOpenSidebar,
}) => {
  const [messages, setMessages] = useState<ShellMessage[]>([
    {
      id: 'msg_banner',
      type: 'system',
      text: IDLE_BANNER,
      timestamp: Date.now(),
    },
  ]);
  const [inputLine, setInputLine] = useState('');
  const [multilineBuffer, setMultilineBuffer] = useState<string[]>([]);
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [pendingInputPrompt, setPendingInputPrompt] = useState<string | null>(null);
  const [userResponseText, setUserResponseText] = useState('');
  const [inputResolver, setInputResolver] = useState<((val: string) => void) | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const colors = preferences.colors;

  // Listen to standard output and error from Python engine
  useEffect(() => {
    const unsubStdout = pyodideService.onStdout((text) => {
      setMessages((prev) => [
        ...prev,
        {
          id: 'out_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          type: 'stdout',
          text,
          timestamp: Date.now(),
        },
      ]);
    });

    const unsubStderr = pyodideService.onStderr((text) => {
      setMessages((prev) => [
        ...prev,
        {
          id: 'err_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          type: 'stderr',
          text,
          timestamp: Date.now(),
        },
      ]);
    });

    // Register input() hook
    pyodideService.setInputPromptHandler(async (promptText) => {
      return new Promise<string>((resolve) => {
        setPendingInputPrompt(promptText || 'input: ');
        setInputResolver(() => resolve);
      });
    });

    return () => {
      unsubStdout();
      unsubStderr();
    };
  }, []);

  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, pendingInputPrompt, multilineBuffer]);

  // Handle command execution
  const handleExecute = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const line = inputLine;
    setInputLine('');

    const isMultiline = multilineBuffer.length > 0;
    const promptPrefix = isMultiline ? '... ' : '>>> ';

    // Append prompt + input to shell messages
    setMessages((prev) => [
      ...prev,
      {
        id: 'cmd_' + Date.now(),
        type: 'prompt',
        text: promptPrefix + line,
        timestamp: Date.now(),
      },
    ]);

    // Check if continuing multiline block
    if (line.trim().endsWith(':')) {
      setMultilineBuffer((prev) => [...prev, line]);
      setInputLine('    ');
      return;
    } else if (isMultiline) {
      if (line.trim() === '') {
        const fullBlock = [...multilineBuffer, line].join('\n');
        setMultilineBuffer([]);
        if (fullBlock.trim()) {
          setHistory((prev) => [...prev, fullBlock]);
          setHistoryIndex(-1);
          await pyodideService.runPython(fullBlock);
        }
        return;
      } else {
        setMultilineBuffer((prev) => [...prev, line]);
        setInputLine('    ');
        return;
      }
    }

    if (line.trim()) {
      setHistory((prev) => [...prev, line]);
      setHistoryIndex(-1);

      if (line.trim() === 'clear' || line.trim() === 'cls') {
        handleClear();
        return;
      }

      await pyodideService.runReplLine(line);
    }
  };

  const handleClear = () => {
    setMessages([
      {
        id: 'msg_banner_' + Date.now(),
        type: 'system',
        text: IDLE_BANNER,
        timestamp: Date.now(),
      },
    ]);
    setMultilineBuffer([]);
  };

  const handleHistoryNav = (direction: 'up' | 'down') => {
    if (history.length === 0) return;

    if (direction === 'up') {
      const nextIdx = historyIndex === -1 ? history.length - 1 : Math.max(0, historyIndex - 1);
      setHistoryIndex(nextIdx);
      setInputLine(history[nextIdx] || '');
    } else {
      if (historyIndex === -1) return;
      const nextIdx = historyIndex + 1;
      if (nextIdx >= history.length) {
        setHistoryIndex(-1);
        setInputLine('');
      } else {
        setHistoryIndex(nextIdx);
        setInputLine(history[nextIdx] || '');
      }
    }
  };

  const handleInputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputResolver) {
      inputResolver(userResponseText);
      setInputResolver(null);
      setPendingInputPrompt(null);
      setUserResponseText('');
    }
  };

  return (
    <div
      className="flex flex-col h-full font-mono text-[13px] select-text relative"
      style={{
        backgroundColor: colors.bg,
        color: colors.text,
        fontSize: `${preferences.fontSize}px`,
        fontFamily: preferences.fontFamily,
      }}
    >
      {/* Shell Title Bar */}
      <div
        className="flex items-center justify-between px-3 h-10 border-b text-xs select-none shrink-0"
        style={{
          backgroundColor: colors.headerBg,
          borderColor: colors.headerBorder,
          color: colors.text,
        }}
      >
        <div className="flex items-center gap-2">
          <TermIcon className="w-3.5 h-3.5 text-blue-500" />
          <span className="font-semibold tracking-tight">Python 3.12 IDLE Shell</span>
          {isRunning && (
            <span className="text-[10px] text-amber-500 font-sans flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
              Running...
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => handleHistoryNav('up')}
            className="p-1.5 rounded transition-colors opacity-75 hover:opacity-100"
            title="Previous Command (Alt+P)"
          >
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => handleHistoryNav('down')}
            className="p-1.5 rounded transition-colors opacity-75 hover:opacity-100"
            title="Next Command (Alt+N)"
          >
            <ArrowDown className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onRestartShell}
            className="flex items-center gap-1 px-2 py-1 rounded text-[11px] font-sans transition-colors"
            style={{ color: colors.prompt }}
            title="Restart Shell (Ctrl+F6)"
          >
            <RotateCcw className="w-3 h-3" />
            <span className="hidden sm:inline">Restart</span>
          </button>
          <button
            onClick={handleClear}
            className="p-1.5 rounded transition-colors opacity-75 hover:opacity-100"
            title="Clear Screen"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          {onOpenSidebar && (
            <button
              onClick={onOpenSidebar}
              className="p-1.5 rounded-lg border ml-1 transition-colors opacity-85 hover:opacity-100"
              style={{
                backgroundColor: colors.bg,
                borderColor: colors.headerBorder,
              }}
              title="Options & Tools Menu"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Shell Output Stream */}
      <div className="flex-1 overflow-y-auto p-3 space-y-0.5 leading-relaxed font-mono">
        {messages.map((msg) => {
          if (msg.type === 'system') {
            return (
              <div key={msg.id} style={{ color: colors.definition }} className="whitespace-pre-wrap py-0.5 font-medium">
                {msg.text}
              </div>
            );
          }
          if (msg.type === 'prompt') {
            return (
              <div key={msg.id} className="whitespace-pre-wrap py-0.5">
                <span style={{ color: colors.prompt, fontWeight: 'bold' }}>{msg.text.slice(0, 4)}</span>
                <span style={{ color: colors.text }}>{msg.text.slice(4)}</span>
              </div>
            );
          }
          if (msg.type === 'stderr') {
            return (
              <div key={msg.id} style={{ color: colors.error }} className="whitespace-pre-wrap py-0.5">
                {msg.text}
              </div>
            );
          }
          return (
            <div key={msg.id} style={{ color: colors.text }} className="whitespace-pre-wrap py-0.5">
              {msg.text}
            </div>
          );
        })}

        {/* Multiline buffer display */}
        {multilineBuffer.length > 0 && (
          <div className="opacity-80 py-0.5">
            {multilineBuffer.map((line, idx) => (
              <div key={idx} className="whitespace-pre-wrap">
                <span style={{ color: colors.prompt, fontWeight: 'bold' }}>{idx === 0 ? '>>> ' : '... '}</span>
                <span>{line}</span>
              </div>
            ))}
          </div>
        )}

        {/* Interactive input() prompt box when Python code calls input(...) */}
        {pendingInputPrompt !== null && (
          <form
            onSubmit={handleInputSubmit}
            className="my-2 p-2.5 rounded-lg border flex items-center gap-2"
            style={{
              backgroundColor: colors.gutterBg,
              borderColor: colors.headerBorder,
            }}
          >
            <span className="font-semibold text-xs whitespace-nowrap" style={{ color: colors.accent }}>
              {pendingInputPrompt}
            </span>
            <input
              type="text"
              autoFocus
              value={userResponseText}
              onChange={(e) => setUserResponseText(e.target.value)}
              placeholder="Type answer & press Enter..."
              className="flex-1 px-2 py-1 rounded text-xs outline-none border"
              style={{
                backgroundColor: colors.bg,
                color: colors.text,
                borderColor: colors.headerBorder,
              }}
            />
            <button
              type="submit"
              className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-semibold flex items-center gap-1"
            >
              <span>Submit</span>
              <CornerDownLeft className="w-3 h-3" />
            </button>
          </form>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Interactive Command Input Line */}
      <form
        onSubmit={handleExecute}
        className="flex items-center px-2 py-1.5 border-t shrink-0"
        style={{
          backgroundColor: colors.headerBg,
          borderColor: colors.headerBorder,
        }}
      >
        <span className="select-none mr-1.5 font-bold" style={{ color: colors.prompt }}>
          {multilineBuffer.length > 0 ? '... ' : '>>> '}
        </span>
        <input
          ref={inputRef}
          type="text"
          value={inputLine}
          onChange={(e) => setInputLine(e.target.value)}
          placeholder={multilineBuffer.length > 0 ? 'Enter block or empty line to run' : 'Type Python statement, expression, or help()...'}
          className="flex-1 bg-transparent outline-none font-mono text-[13px]"
          style={{
            color: colors.text,
            fontSize: `${preferences.fontSize}px`,
            fontFamily: preferences.fontFamily,
          }}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
          onKeyDown={(e) => {
            if (e.key === 'ArrowUp') {
              e.preventDefault();
              handleHistoryNav('up');
            } else if (e.key === 'ArrowDown') {
              e.preventDefault();
              handleHistoryNav('down');
            }
          }}
        />
        <button
          type="submit"
          className="p-1.5 ml-1 rounded transition-colors"
          style={{ color: colors.accent }}
          title="Send"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
