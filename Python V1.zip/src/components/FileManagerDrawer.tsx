/**
 * PyIDLE Mobile & Desktop - Android & Windows File Management System
 * Full file explorer supporting creating files, folders, saving scripts,
 * direct Hard Drive mounting (showDirectoryPicker), importing, and downloading.
 */

import React, { useState } from 'react';
import {
  Folder, FolderPlus, FilePlus, FileCode,
  Download, Upload, Trash2, Edit2, Copy,
  ChevronRight, ArrowLeft, MoreVertical,
  Check, X, HardDrive, RefreshCw, FolderInput,
  FolderSync, Laptop
} from 'lucide-react';
import { EditorTheme, FileItem, FolderItem } from '../types';
import { fileSystemService } from '../services/fileSystemService';
import { localDiskService } from '../services/localDiskService';

interface FileManagerDrawerProps {
  theme: EditorTheme;
  isOpen: boolean;
  onClose: () => void;
  files: FileItem[];
  folders: FolderItem[];
  activeFileId: string | null;
  onOpenFile: (fileId: string) => void;
  onRefreshVFS: () => void;
  onSaveCurrentScript: () => void;
  onMountedHardDrive?: (files: FileItem[], folderName: string) => void;
  mountedFolderName?: string | null;
}

export const FileManagerDrawer: React.FC<FileManagerDrawerProps> = ({
  theme,
  isOpen,
  onClose,
  files,
  folders,
  activeFileId,
  onOpenFile,
  onRefreshVFS,
  onSaveCurrentScript,
  onMountedHardDrive,
  mountedFolderName,
}) => {
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modals state
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [showNewFolderModal, setShowNewFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [renameTarget, setRenameTarget] = useState<{ id: string; type: 'file' | 'folder'; currentName: string } | null>(null);
  const [renameInput, setRenameInput] = useState('');
  const [moveTarget, setMoveTarget] = useState<FileItem | null>(null);

  const isDark = theme === 'idle-dark';

  if (!isOpen) return null;

  // Filter current folder items
  const currentFolders = folders.filter((f) => f.parentId === currentFolderId);
  const currentFiles = files
    .filter((f) => f.folderId === currentFolderId)
    .filter((f) => f.name.toLowerCase().includes(searchQuery.toLowerCase()));

  const activeFolder = folders.find((f) => f.id === currentFolderId);

  // Breadcrumbs path
  const getBreadcrumbs = () => {
    const rootName = mountedFolderName ? `HardDrive: ${mountedFolderName}` : 'PythonProjects';
    const crumbs: { id: string | null; name: string }[] = [{ id: null, name: rootName }];
    if (activeFolder) {
      crumbs.push({ id: activeFolder.id, name: activeFolder.name });
    }
    return crumbs;
  };

  // Mount real local hard drive folder
  const handleMountHardDrive = async () => {
    try {
      const res = await localDiskService.mountLocalFolder();
      if (res && onMountedHardDrive) {
        onMountedHardDrive(res.files, res.folderName);
        onRefreshVFS();
      }
    } catch (err: any) {
      alert(`Could not mount folder: ${err.message || err}`);
    }
  };

  // Create New File
  const handleCreateFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;
    const file = fileSystemService.createFile(newFileName.trim(), '', currentFolderId);
    setNewFileName('');
    setShowNewFileModal(false);
    onRefreshVFS();
    onOpenFile(file.id);
    onClose();
  };

  // Create New Folder
  const handleCreateFolder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;
    fileSystemService.createFolder(newFolderName.trim(), currentFolderId);
    setNewFolderName('');
    setShowNewFolderModal(false);
    onRefreshVFS();
  };

  // Handle Rename
  const handleRenameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameTarget || !renameInput.trim()) return;
    if (renameTarget.type === 'file') {
      fileSystemService.renameFile(renameTarget.id, renameInput.trim());
    } else {
      fileSystemService.renameFolder(renameTarget.id, renameInput.trim());
    }
    setRenameTarget(null);
    setRenameInput('');
    onRefreshVFS();
  };

  // Handle Move
  const handleMoveFile = (targetFolderId: string | null) => {
    if (!moveTarget) return;
    fileSystemService.moveFile(moveTarget.id, targetFolderId);
    setMoveTarget(null);
    onRefreshVFS();
  };

  // Handle Import from Device
  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    fileSystemService.importFromFileObject(file, currentFolderId).then((newFile) => {
      onRefreshVFS();
      onOpenFile(newFile.id);
      onClose();
    });
  };

  const bgModal = isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const itemHover = isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs select-none">
      <div className={`relative w-full max-w-xl h-[85vh] max-h-[680px] rounded-2xl border shadow-2xl flex flex-col overflow-hidden ${bgModal}`}>
        
        {/* Top Header: Storage Title & Mount Hard Drive Option */}
        <div className={`p-4 border-b flex items-center justify-between shrink-0 ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/10 text-blue-500 flex items-center justify-center">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-sm leading-tight flex items-center gap-2">
                <span>File Storage &amp; Hard Drive</span>
                {mountedFolderName && (
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded font-mono">
                    Mounted
                  </span>
                )}
              </h2>
              <p className="text-[11px] text-slate-400 font-mono">
                {mountedFolderName ? `Hard Drive: ${mountedFolderName}` : '/storage/emulated/0/PythonProjects'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Mount Real Local Hard Drive Folder */}
            <button
              onClick={handleMountHardDrive}
              className="px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-indigo-500/30"
              title="Mount a real folder from your PC hard drive or Android phone storage"
            >
              <FolderSync className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Mount Hard Drive Folder</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Toolbar: Breadcrumbs, New File, New Folder, Import */}
        <div className={`px-4 py-2 border-b flex items-center justify-between gap-2 shrink-0 ${
          isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-100/70 border-slate-200'
        }`}>
          {/* Breadcrumbs */}
          <div className="flex items-center gap-1 text-xs font-mono overflow-x-auto no-scrollbar">
            {getBreadcrumbs().map((crumb, idx) => (
              <React.Fragment key={crumb.id || 'root'}>
                {idx > 0 && <ChevronRight className="w-3 h-3 text-slate-400 shrink-0" />}
                <button
                  onClick={() => setCurrentFolderId(crumb.id)}
                  className={`px-1.5 py-0.5 rounded hover:bg-blue-500/10 hover:text-blue-500 transition-colors whitespace-nowrap ${
                    idx === getBreadcrumbs().length - 1 ? 'font-semibold text-blue-500' : 'text-slate-400'
                  }`}
                >
                  {crumb.name}
                </button>
              </React.Fragment>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => { setNewFileName(''); setShowNewFileModal(true); }}
              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium flex items-center gap-1 shadow-xs"
            >
              <FilePlus className="w-3.5 h-3.5" />
              <span>+ File</span>
            </button>
            <button
              onClick={() => { setNewFolderName(''); setShowNewFolderModal(true); }}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium border flex items-center gap-1 ${
                isDark ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700' : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <FolderPlus className="w-3.5 h-3.5 text-amber-500" />
              <span>+ Folder</span>
            </button>

            {/* File input for import from device */}
            <label className={`p-1.5 rounded-lg border cursor-pointer ${
              isDark ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700' : 'bg-white border-slate-300 text-slate-600 hover:bg-slate-100'
            }`} title="Import .py from Device">
              <Upload className="w-3.5 h-3.5" />
              <input type="file" accept=".py,.txt" onChange={handleFileImport} className="hidden" />
            </label>
          </div>
        </div>

        {/* Content list: Folders and Files */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {/* Back button if in subfolder */}
          {currentFolderId && (
            <button
              onClick={() => setCurrentFolderId(null)}
              className={`w-full p-2.5 rounded-xl border flex items-center gap-2.5 text-xs text-slate-400 font-medium ${itemHover} ${
                isDark ? 'border-slate-800 bg-slate-800/30' : 'border-slate-200 bg-slate-50'
              }`}
            >
              <ArrowLeft className="w-4 h-4" />
              <span>.. Back to Root Directory</span>
            </button>
          )}

          {/* Folders */}
          {currentFolders.map((folder) => {
            const count = files.filter((f) => f.folderId === folder.id).length;
            return (
              <div
                key={folder.id}
                onClick={() => setCurrentFolderId(folder.id)}
                className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${itemHover} ${
                  isDark ? 'bg-slate-800/50 border-slate-800' : 'bg-white border-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center">
                    <Folder className="w-5 h-5 fill-amber-500/20" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-xs leading-tight">{folder.name}</h4>
                    <p className="text-[11px] text-slate-400">{count} {count === 1 ? 'file' : 'files'}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => {
                      setRenameTarget({ id: folder.id, type: 'folder', currentName: folder.name });
                      setRenameInput(folder.name);
                    }}
                    className="p-1.5 rounded-md hover:bg-slate-700/50 text-slate-400 hover:text-slate-200"
                    title="Rename Folder"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Delete folder "${folder.name}" and all scripts inside?`)) {
                        fileSystemService.deleteFolder(folder.id);
                        onRefreshVFS();
                      }
                    }}
                    className="p-1.5 rounded-md hover:bg-red-500/10 text-slate-400 hover:text-red-500"
                    title="Delete Folder"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}

          {/* Files */}
          {currentFiles.map((file) => {
            const isActive = file.id === activeFileId;
            const fileSize = (new Blob([file.content]).size / 1024).toFixed(1);
            return (
              <div
                key={file.id}
                onClick={() => {
                  onOpenFile(file.id);
                  onClose();
                }}
                className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${itemHover} ${
                  isActive
                    ? isDark
                      ? 'bg-blue-950/40 border-blue-600'
                      : 'bg-blue-50 border-blue-400'
                    : isDark
                    ? 'bg-slate-800/40 border-slate-800'
                    : 'bg-white border-slate-200'
                }`}
              >
                <div className="flex items-center gap-3 truncate">
                  <div className="w-9 h-9 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center shrink-0">
                    <FileCode className="w-5 h-5" />
                  </div>
                  <div className="truncate">
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-semibold text-xs font-mono truncate">{file.name}</h4>
                      {isActive && (
                        <span className="text-[10px] bg-blue-500 text-white px-1.5 py-0.2 rounded font-sans">
                          Active
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 font-mono">
                      {fileSize} KB · {new Date(file.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>

                {/* File Action Controls */}
                <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => fileSystemService.downloadFile(file.id)}
                    className="p-1.5 rounded-md hover:bg-blue-500/10 text-slate-400 hover:text-blue-500"
                    title="Download .py to Device"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      fileSystemService.duplicateFile(file.id);
                      onRefreshVFS();
                    }}
                    className="p-1.5 rounded-md hover:bg-slate-700/50 text-slate-400 hover:text-slate-200"
                    title="Duplicate"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setMoveTarget(file)}
                    className="p-1.5 rounded-md hover:bg-slate-700/50 text-slate-400 hover:text-slate-200"
                    title="Move to Folder"
                  >
                    <FolderInput className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      setRenameTarget({ id: file.id, type: 'file', currentName: file.name });
                      setRenameInput(file.name);
                    }}
                    className="p-1.5 rounded-md hover:bg-slate-700/50 text-slate-400 hover:text-slate-200"
                    title="Rename"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Delete file "${file.name}"?`)) {
                        fileSystemService.deleteFile(file.id);
                        onRefreshVFS();
                      }
                    }}
                    className="p-1.5 rounded-md hover:bg-red-500/10 text-slate-400 hover:text-red-500"
                    title="Delete File"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}

          {currentFolders.length === 0 && currentFiles.length === 0 && (
            <div className="text-center py-12 text-slate-400">
              <Folder className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-xs">This folder is empty</p>
              <button
                onClick={() => setShowNewFileModal(true)}
                className="mt-2 text-xs text-blue-500 hover:underline"
              >
                + Create your first Python script here
              </button>
            </div>
          )}
        </div>

        {/* Bottom Actions Footer */}
        <div className={`p-3 border-t flex items-center justify-between text-xs shrink-0 ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (confirm('Reset file storage to default sample projects?')) {
                  fileSystemService.resetToDefaults();
                  onRefreshVFS();
                }
              }}
              className="text-slate-400 hover:text-slate-200 text-[11px] flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset Samples</span>
            </button>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onSaveCurrentScript}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-lg text-xs"
            >
              Save Current Script
            </button>
            <button
              onClick={onClose}
              className={`px-3 py-1.5 border rounded-lg font-medium text-xs ${
                isDark ? 'border-slate-700 text-slate-300 hover:bg-slate-800' : 'border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
            >
              Done
            </button>
          </div>
        </div>

        {/* Modal: Create New File */}
        {showNewFileModal && (
          <div className="absolute inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
            <form
              onSubmit={handleCreateFile}
              className={`w-full max-w-sm rounded-xl p-4 border shadow-xl ${
                isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <h3 className="font-bold text-sm mb-2">Create New Python File</h3>
              <input
                type="text"
                autoFocus
                placeholder="script_name.py"
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                className={`w-full px-3 py-2 rounded-lg text-xs font-mono border mb-3 outline-none ${
                  isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-black'
                }`}
              />
              <div className="flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setShowNewFileModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-600 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 text-white font-medium rounded-lg"
                >
                  Create File
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Modal: Create New Folder */}
        {showNewFolderModal && (
          <div className="absolute inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
            <form
              onSubmit={handleCreateFolder}
              className={`w-full max-w-sm rounded-xl p-4 border shadow-xl ${
                isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <h3 className="font-bold text-sm mb-2">Create New Folder</h3>
              <input
                type="text"
                autoFocus
                placeholder="Folder Name (e.g., algorithms)"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                className={`w-full px-3 py-2 rounded-lg text-xs border mb-3 outline-none ${
                  isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-black'
                }`}
              />
              <div className="flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setShowNewFolderModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-600 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-amber-600 text-white font-medium rounded-lg"
                >
                  Create Folder
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Modal: Rename */}
        {renameTarget && (
          <div className="absolute inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
            <form
              onSubmit={handleRenameSubmit}
              className={`w-full max-w-sm rounded-xl p-4 border shadow-xl ${
                isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <h3 className="font-bold text-sm mb-2">Rename {renameTarget.type === 'file' ? 'File' : 'Folder'}</h3>
              <input
                type="text"
                autoFocus
                value={renameInput}
                onChange={(e) => setRenameInput(e.target.value)}
                className={`w-full px-3 py-2 rounded-lg text-xs font-mono border mb-3 outline-none ${
                  isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-black'
                }`}
              />
              <div className="flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setRenameTarget(null)}
                  className="px-3 py-1.5 rounded-lg border border-slate-600 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 text-white font-medium rounded-lg"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Modal: Move File to Folder */}
        {moveTarget && (
          <div className="absolute inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
            <div className={`w-full max-w-sm rounded-xl p-4 border shadow-xl ${
              isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
            }`}>
              <h3 className="font-bold text-sm mb-1">Move "{moveTarget.name}" to:</h3>
              <p className="text-xs text-slate-400 mb-3">Select destination folder:</p>
              
              <div className="space-y-1 max-h-48 overflow-y-auto mb-4">
                <button
                  onClick={() => handleMoveFile(null)}
                  className={`w-full p-2 text-left rounded-lg text-xs flex items-center gap-2 ${
                    moveTarget.folderId === null ? 'bg-blue-600/20 text-blue-400 font-semibold' : itemHover
                  }`}
                >
                  <HardDrive className="w-4 h-4 text-slate-400" />
                  <span>Root (PythonProjects)</span>
                </button>
                {folders.map((folder) => (
                  <button
                    key={folder.id}
                    onClick={() => handleMoveFile(folder.id)}
                    className={`w-full p-2 text-left rounded-lg text-xs flex items-center gap-2 ${
                      moveTarget.folderId === folder.id ? 'bg-blue-600/20 text-blue-400 font-semibold' : itemHover
                    }`}
                  >
                    <Folder className="w-4 h-4 text-amber-500" />
                    <span>{folder.name}</span>
                  </button>
                ))}
              </div>

              <div className="flex justify-end text-xs">
                <button
                  onClick={() => setMoveTarget(null)}
                  className="px-3 py-1.5 rounded-lg border border-slate-600 text-slate-400"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
