import React, { useState } from 'react';
import { X, ShieldAlert, CheckCircle2, AlertCircle, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { pinService } from '../services/pinService';
import { ThemeColors } from '../utils/themePresets';

interface ResetFailsafeModalProps {
  isOpen: boolean;
  onClose: () => void;
  colors: ThemeColors;
}

export const ResetFailsafeModal: React.FC<ResetFailsafeModalProps> = ({
  isOpen,
  onClose,
  colors,
}) => {
  const [step, setStep] = useState<'verify-password' | 'enter-failsafe' | 'success'>('verify-password');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [newFailsafe, setNewFailsafe] = useState('');
  const [confirmFailsafe, setConfirmFailsafe] = useState('');
  const [showFailsafeText, setShowFailsafeText] = useState(true);

  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleReset = () => {
    setStep('verify-password');
    setPassword('');
    setShowPassword(false);
    setNewFailsafe('');
    setConfirmFailsafe('');
    setError(null);
  };

  const handleClose = () => {
    handleReset();
    onClose();
  };

  const handleVerifyPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!password) {
      setError('Please enter your password.');
      return;
    }

    if (!pinService.verifyPin(password)) {
      setError('Incorrect password. Please try again.');
      return;
    }

    // Password verified, proceed to enter new failsafe
    setStep('enter-failsafe');
  };

  const handleSaveFailsafe = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!newFailsafe || newFailsafe.trim().length === 0) {
      setError('Please enter a new failsafe.');
      return;
    }

    if (!confirmFailsafe || confirmFailsafe.trim().length === 0) {
      setError('Please confirm your new failsafe.');
      return;
    }

    if (newFailsafe.trim() !== confirmFailsafe.trim()) {
      setError('New failsafe and confirm failsafe do not match.');
      return;
    }

    const success = pinService.setFailsafe(newFailsafe);
    if (success) {
      setStep('success');
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate(60); } catch { /* ignore */ }
      }
      setTimeout(() => {
        handleClose();
      }, 1800);
    } else {
      setError('Failed to update failsafe. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs select-none animate-in fade-in duration-150">
      <div
        className="w-full max-w-sm rounded-2xl border shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150"
        style={{
          backgroundColor: colors.bg,
          borderColor: colors.headerBorder,
          color: colors.text,
        }}
      >
        {/* Header */}
        <div
          className="p-4 border-b flex items-center justify-between"
          style={{
            backgroundColor: colors.headerBg,
            borderColor: colors.headerBorder,
          }}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm leading-tight">Reset Failsafe</h3>
              <p className="text-[11px] opacity-75">Emergency recovery key configuration</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded-lg opacity-60 hover:opacity-100 transition-opacity"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5">
          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {step === 'verify-password' && (
            <form onSubmit={handleVerifyPassword} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold block opacity-85">
                  Enter current password
                </label>
                <p className="text-[11px] opacity-65 leading-tight mb-2">
                  Verify your password before configuring a new emergency failsafe.
                </p>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setError(null);
                    }}
                    placeholder="Enter password"
                    autoFocus
                    className="w-full px-3 py-2.5 pr-10 rounded-xl text-xs font-mono outline-none border transition-colors focus:ring-1 focus:ring-amber-500"
                    style={{
                      backgroundColor: colors.headerBg,
                      borderColor: colors.headerBorder,
                      color: colors.text,
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 transition-opacity p-1"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleClose}
                  className="flex-1 py-2.5 px-3 rounded-xl border font-medium text-xs opacity-80 hover:opacity-100 transition-colors"
                  style={{ borderColor: colors.headerBorder }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-colors shadow-lg shadow-amber-600/30"
                >
                  Verify Password
                </button>
              </div>
            </form>
          )}

          {step === 'enter-failsafe' && (
            <form onSubmit={handleSaveFailsafe} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold block opacity-85">
                  Enter new failsafe
                </label>
                <div className="relative">
                  <input
                    type={showFailsafeText ? 'text' : 'password'}
                    value={newFailsafe}
                    onChange={(e) => {
                      setNewFailsafe(e.target.value);
                      setError(null);
                    }}
                    placeholder="e.g. 8.5/70 or custom failsafe"
                    autoFocus
                    className="w-full px-3 py-2.5 pr-10 rounded-xl text-xs font-mono outline-none border transition-colors focus:ring-1 focus:ring-amber-500"
                    style={{
                      backgroundColor: colors.headerBg,
                      borderColor: colors.headerBorder,
                      color: colors.text,
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowFailsafeText(!showFailsafeText)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 transition-opacity p-1"
                  >
                    {showFailsafeText ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold block opacity-85">
                  Confirm new failsafe
                </label>
                <input
                  type={showFailsafeText ? 'text' : 'password'}
                  value={confirmFailsafe}
                  onChange={(e) => {
                    setConfirmFailsafe(e.target.value);
                    setError(null);
                  }}
                  placeholder="Re-enter new failsafe"
                  className="w-full px-3 py-2.5 rounded-xl text-xs font-mono outline-none border transition-colors focus:ring-1 focus:ring-amber-500"
                  style={{
                    backgroundColor: colors.headerBg,
                    borderColor: colors.headerBorder,
                    color: colors.text,
                  }}
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setStep('verify-password')}
                  className="flex-1 py-2.5 px-3 rounded-xl border font-medium text-xs opacity-80 hover:opacity-100 transition-colors"
                  style={{ borderColor: colors.headerBorder }}
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-colors shadow-lg shadow-amber-600/30 flex items-center justify-center gap-1.5"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Update Failsafe</span>
                </button>
              </div>
            </form>
          )}

          {step === 'success' && (
            <div className="py-6 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-base font-bold text-emerald-400">
                  failsafe successfully added
                </h4>
                <p className="text-xs opacity-75 mt-1">
                  Your new password recovery failsafe is now active.
                </p>
              </div>
              <button
                type="button"
                onClick={handleClose}
                className="mt-4 px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-emerald-600/30"
              >
                Done
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
