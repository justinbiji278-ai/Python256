/**
 * PyIDLE Mobile - Save and Run Confirmation Dialog
 * Authentic Python IDLE dialog shown when pressing F5 or Run on an unsaved script.
 */

import React, { useEffect, useRef } from 'react';
import { Play, Save, X, AlertCircle } from 'lucide-react';
import { EditorTheme } from '../types';

interface SaveAndRunModalProps {
  theme: EditorTheme;
  isOpen: boolean;
  fileName: string;
  onSaveAndRun: () => void;
  onRunWithoutSaving?: () => void;
  onCancel: () => void;
}

export const SaveAndRunModal: React.FC<SaveAndRunModalProps> = ({
  theme,
  isOpen,
  fileName,
  onSaveAndRun,
  onRunWithoutSaving,
  onCancel,
}) => {
  const saveBtnRef = useRef<HTMLButtonElement>(null);
  const isDark = theme === 'idle-dark';

  useEffect(() => {
    if (isOpen) {
      saveBtnRef.current?.focus();
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onCancel();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        onSaveAndRun();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onCancel, onSaveAndRun]);

  if (!isOpen) return null;

  const bgModal = isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-300 text-slate-900';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs select-none">
      <div className={`w-full max-w-sm rounded-xl border shadow-2xl p-5 ${bgModal}`}>
        
        {/* Title */}
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center shrink-0">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm leading-tight">Save Before Run</h3>
            <p className="text-xs text-slate-400 font-mono">{fileName}</p>
          </div>
        </div>

        {/* Message matching classic IDLE behavior */}
        <p className="text-xs text-slate-400 leading-relaxed mb-5">
          Source code has unsaved modifications. In Python IDLE, scripts must be saved before execution.
        </p>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2 text-xs">
          <button
            onClick={onCancel}
            className={`px-3 py-2 rounded-lg border font-medium transition-colors ${
              isDark ? 'border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-slate-200' : 'border-slate-300 text-slate-600 hover:bg-slate-100'
            }`}
          >
            Cancel
          </button>

          {onRunWithoutSaving && (
            <button
              onClick={onRunWithoutSaving}
              className={`px-3 py-2 rounded-lg border font-medium transition-colors ${
                isDark ? 'border-slate-700 text-slate-300 hover:bg-slate-800' : 'border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
            >
              Run Only
            </button>
          )}

          <button
            ref={saveBtnRef}
            onClick={onSaveAndRun}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg flex items-center gap-1.5 shadow transition-transform active:scale-95"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save &amp; Run (Enter)</span>
          </button>
        </div>

      </div>
    </div>
  );
};
