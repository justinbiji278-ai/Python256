/**
 * PyIDLE Mobile & Desktop - Unified Side Drawer (3-Dot Menu)
 * Consolidates Files, Download Pips, Touch Bar Keys, Graphics Display,
 * Configure IDLE (8 theme presets + color customizer), and Help & Shortcuts.
 */

import React, { useState } from 'react';
import {
  FolderOpen, Package, Gamepad2, Keyboard,
  FilePlus, Save, Download, Upload, RotateCcw,
  Trash2, Sun, Moon, Maximize2, Minimize2,
  Monitor, Smartphone, ChevronRight, X,
  HelpCircle, Code2, LayoutTemplate,
  SlidersHorizontal, Check, FileText, RotateCw,
  Laptop, Columns, ArrowLeftRight, HardDrive,
  Command, Sparkles, Palette, Settings2,
  Bot, MessageSquare, Compass, Globe, ExternalLink,
  Info, User, ShieldCheck, Lock, KeyRound, ShieldAlert
} from 'lucide-react';
import { EditorTheme } from '../types';
import { IDLEPreferences, PRESET_THEMES } from '../utils/themePresets';
import {
  QuickAppConfig, loadSelectedQuickApp,
  saveSelectedQuickApp, launchExternalApp
} from '../utils/quickAppLauncher';
import { QuickAppSelectorModal } from './QuickAppSelectorModal';
import { ChangePinModal } from './ChangePinModal';
import { ResetFailsafeModal } from './ResetFailsafeModal';

interface IDLESidebarProps {
  theme: EditorTheme;
  preferences: IDLEPreferences;
  onOpenConfigureIDLE: () => void;
  isOpen: boolean;
  onClose: () => void;
  onOpenFiles: () => void;
  onOpenPip: () => void;
  onOpenGraphics: () => void;
  showTouchBar: boolean;
  onToggleTouchBar: () => void;
  onNewFile: () => void;
  onSaveFile: () => void;
  onSaveAs: () => void;
  onExportScript: () => void;
  onImportScript: () => void;
  onIndent: () => void;
  onDedent: () => void;
  onComment: () => void;
  onRestartShell: () => void;
  onClearShell: () => void;
  layoutMode: 'editor' | 'shell' | 'split';
  onLayoutModeChange: (mode: 'editor' | 'shell' | 'split') => void;
  orientation: 'landscape' | 'portrait';
  onToggleOrientation: () => void;
  isMaximized: boolean;
  onToggleMaximize: () => void;
  isDeviceFrame: boolean;
  onToggleDeviceFrame: () => void;
  activeFileName?: string;
  onResetSplitRatio?: (ratio: number) => void;
  onMountHardDrive?: () => void;
  mountedFolderName?: string | null;
  onInstallPwa?: () => void;
  canInstallPwa?: boolean;
  onLockApp?: () => void;
}

export const IDLESidebar: React.FC<IDLESidebarProps> = ({
  preferences,
  onOpenConfigureIDLE,
  isOpen,
  onClose,
  onOpenFiles,
  onOpenPip,
  onOpenGraphics,
  showTouchBar,
  onToggleTouchBar,
  onNewFile,
  onSaveFile,
  onSaveAs,
  onExportScript,
  onImportScript,
  onIndent,
  onDedent,
  onComment,
  onRestartShell,
  onClearShell,
  layoutMode,
  onLayoutModeChange,
  orientation,
  onToggleOrientation,
  isMaximized,
  onToggleMaximize,
  isDeviceFrame,
  onToggleDeviceFrame,
  activeFileName,
  onResetSplitRatio,
  onMountHardDrive,
  mountedFolderName,
  onInstallPwa,
  canInstallPwa,
  onLockApp,
}) => {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [showChangePinModal, setShowChangePinModal] = useState(false);
  const [showResetFailsafeModal, setShowResetFailsafeModal] = useState(false);
  const [quickApp, setQuickApp] = useState<QuickAppConfig>(loadSelectedQuickApp());
  const [showQuickAppSelector, setShowQuickAppSelector] = useState(false);

  const colors = preferences.colors;

  if (!isOpen) return null;

  const toggleSection = (name: string) => {
    setExpandedSection(expandedSection === name ? null : name);
  };

  const currentThemeName = preferences.themeId === 'custom'
    ? 'Custom Palette'
    : PRESET_THEMES[preferences.themeId]?.name || 'Theme';

  const renderQuickAppIcon = (iconType: QuickAppConfig['iconType']) => {
    switch (iconType) {
      case 'chatgpt':
        return <Bot className="w-4 h-4" />;
      case 'gemini':
        return <Sparkles className="w-4 h-4" />;
      case 'claude':
        return <MessageSquare className="w-4 h-4" />;
      case 'deepseek':
        return <Compass className="w-4 h-4" />;
      case 'perplexity':
        return <Globe className="w-4 h-4" />;
      default:
        return <ExternalLink className="w-4 h-4" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs select-none animate-in fade-in duration-150">
      {/* Backdrop click to dismiss */}
      <div className="flex-1" onClick={onClose} />

      {/* Drawer Container */}
      <div
        className="w-full max-w-xs sm:max-w-sm h-full flex flex-col overflow-hidden shadow-2xl border-l"
        style={{
          backgroundColor: colors.bg,
          borderColor: colors.headerBorder,
          color: colors.text,
        }}
      >
        {/* Drawer Header */}
        <div
          className="p-4 border-b flex items-center justify-between shrink-0"
          style={{
            backgroundColor: colors.headerBg,
            borderColor: colors.headerBorder,
          }}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow">
              Py
            </div>
            <div>
              <h2 className="font-bold text-sm leading-tight">Python V1 Options</h2>
              {activeFileName && (
                <p className="text-[11px] opacity-75 font-mono truncate max-w-[170px]">
                  {activeFileName}
                </p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg opacity-75 hover:opacity-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Options List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4 text-xs">
          
          {/* Main Action: Configure IDLE Themes & Colors */}
          <button
            onClick={() => { onOpenConfigureIDLE(); onClose(); }}
            className="w-full p-3 rounded-xl border flex items-center justify-between text-left transition-all bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border-indigo-500/30"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow">
                <Palette className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-xs leading-tight">Configure IDLE (Themes)</h4>
                <p className="text-[10px] opacity-75">
                  Current: {currentThemeName}
                </p>
              </div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500 text-white font-semibold">
              Customize
            </span>
          </button>

          {/* Quick Companion / External App Launcher (Defaults to ChatGPT; switchable to Gemini, Claude, etc.) */}
          <div className="flex items-center gap-1.5 w-full">
            <button
              onClick={() => {
                launchExternalApp(quickApp);
              }}
              className="flex-1 p-2.5 rounded-xl border flex items-center justify-between text-left transition-all hover:bg-black/10 dark:hover:bg-white/5 group"
              style={{
                borderColor: colors.headerBorder,
                backgroundColor: colors.headerBg,
              }}
              title={`Launch ${quickApp.name} in native app or browser`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-white shrink-0 shadow-xs transition-transform group-hover:scale-105"
                  style={{ backgroundColor: quickApp.color }}
                >
                  {renderQuickAppIcon(quickApp.iconType)}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-xs leading-tight truncate">{quickApp.name}</h4>
                    <ExternalLink className="w-3 h-3 opacity-50 shrink-0" />
                  </div>
                  <p className="text-[10px] opacity-75 truncate">{quickApp.description}</p>
                </div>
              </div>
              <span
                className="text-[10px] px-2 py-0.5 rounded font-semibold text-white shadow-xs shrink-0"
                style={{ backgroundColor: quickApp.color }}
              >
                Open
              </span>
            </button>

            <button
              onClick={() => setShowQuickAppSelector(true)}
              className="p-2.5 rounded-xl border flex items-center justify-center hover:bg-black/10 dark:hover:bg-white/5 opacity-75 hover:opacity-100 transition-colors shrink-0"
              style={{
                borderColor: colors.headerBorder,
                backgroundColor: colors.headerBg,
              }}
              title="Change Companion App (ChatGPT, Gemini, Claude, DeepSeek, or Custom)"
            >
              <Settings2 className="w-4 h-4" />
            </button>
          </div>

          {/* Section 1: Main Tools */}
          <div>
            <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider mb-1 opacity-60">
              Main Tools
            </div>
            <div className="space-y-1">
              {/* Files */}
              <button
                onClick={() => { onOpenFiles(); onClose(); }}
                className="w-full p-2.5 rounded-xl flex items-center justify-between text-left transition-colors hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center">
                    <FolderOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-xs leading-tight">Files &amp; Folders</h4>
                    <p className="text-[10px] opacity-75">
                      {mountedFolderName ? `Hard Drive: ${mountedFolderName}` : 'Storage & Script Manager'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] opacity-60 font-mono">Ctrl+O</span>
              </button>

              {/* Mount Real Hard Drive Folder */}
              {onMountHardDrive && (
                <button
                  onClick={() => { onMountHardDrive(); onClose(); }}
                  className="w-full p-2.5 rounded-xl flex items-center justify-between text-left transition-colors hover:bg-black/10 dark:hover:bg-white/5"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                      <HardDrive className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-xs leading-tight">Mount Hard Drive Folder</h4>
                      <p className="text-[10px] opacity-75">Real disk read/write for Python</p>
                    </div>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono">
                    Direct Disk
                  </span>
                </button>
              )}

              {/* Download Pips */}
              <button
                onClick={() => { onOpenPip(); onClose(); }}
                className="w-full p-2.5 rounded-xl flex items-center justify-between text-left transition-colors hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                    <Package className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-xs leading-tight">Download Pips</h4>
                    <p className="text-[10px] opacity-75">NumPy, Pygame, Matplotlib...</p>
                  </div>
                </div>
                <span className="text-[10px] opacity-60 font-mono">Ctrl+P</span>
              </button>

              {/* Graphics Display */}
              <button
                onClick={() => { onOpenGraphics(); onClose(); }}
                className="w-full p-2.5 rounded-xl flex items-center justify-between text-left transition-colors hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-pink-500/10 text-pink-500 flex items-center justify-center">
                    <Gamepad2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-xs leading-tight">Graphics Display</h4>
                    <p className="text-[10px] opacity-75">Pygame Canvas &amp; Plots</p>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-60" />
              </button>

              {/* Touch Bar Key Strip Toggle */}
              <button
                onClick={() => { onToggleTouchBar(); }}
                className="w-full p-2.5 rounded-xl flex items-center justify-between text-left transition-colors hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                    <Keyboard className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-xs leading-tight">Touch Key Bar</h4>
                    <p className="text-[10px] opacity-75">
                      {showTouchBar ? 'Visible (Tap to hide)' : 'Hidden (Keyboard & PC mode)'}
                    </p>
                  </div>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${
                  showTouchBar ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700/40 text-slate-400'
                }`}>
                  {showTouchBar ? 'ON' : 'OFF'}
                </span>
              </button>

              {/* Install PWA on PC or Phone */}
              {canInstallPwa && onInstallPwa && (
                <button
                  onClick={() => { onInstallPwa(); onClose(); }}
                  className="w-full p-2.5 rounded-xl flex items-center justify-between text-left transition-colors bg-blue-600/10 hover:bg-blue-600/20 text-blue-400"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center">
                      <Download className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-xs leading-tight">Install App on PC / Phone</h4>
                      <p className="text-[10px] opacity-75">Run standalone without browser tabs</p>
                    </div>
                  </div>
                  <span className="text-[10px] bg-blue-500 text-white px-2 py-0.5 rounded font-semibold">Install</span>
                </button>
              )}
            </div>
          </div>

          {/* Section 2: Screen & Split Layout */}
          <div>
            <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider mb-1 opacity-60">
              Screen &amp; Split Layout
            </div>
            
            {/* Split Mode Selector */}
            <div
              className="grid grid-cols-3 gap-1.5 p-1 rounded-xl border"
              style={{
                backgroundColor: colors.headerBg,
                borderColor: colors.headerBorder,
              }}
            >
              <button
                onClick={() => { onLayoutModeChange('editor'); onClose(); }}
                className={`py-2 px-1 text-center rounded-lg font-medium text-xs transition-colors ${
                  layoutMode === 'editor' ? 'bg-blue-600 text-white font-semibold' : 'opacity-70 hover:opacity-100'
                }`}
                title="100% Editor Screen"
              >
                Editor
              </button>
              <button
                onClick={() => { onLayoutModeChange('shell'); onClose(); }}
                className={`py-2 px-1 text-center rounded-lg font-medium text-xs transition-colors ${
                  layoutMode === 'shell' ? 'bg-blue-600 text-white font-semibold' : 'opacity-70 hover:opacity-100'
                }`}
                title="100% Terminal Shell"
              >
                Shell
              </button>
              <button
                onClick={() => { onLayoutModeChange('split'); onClose(); }}
                className={`py-2 px-1 text-center rounded-lg font-medium text-xs transition-colors ${
                  layoutMode === 'split' ? 'bg-blue-600 text-white font-semibold' : 'opacity-70 hover:opacity-100'
                }`}
                title="Side-by-Side Dual View"
              >
                Split
              </button>
            </div>

            {/* Quick Split Ratio Presets */}
            {layoutMode === 'split' && onResetSplitRatio && (
              <div
                className="mt-2 flex items-center justify-between gap-1 p-1.5 rounded-lg border"
                style={{
                  backgroundColor: colors.headerBg,
                  borderColor: colors.headerBorder,
                }}
              >
                <span className="text-[10px] opacity-75 flex items-center gap-1">
                  <ArrowLeftRight className="w-3 h-3 text-blue-400" />
                  <span>Split Presets:</span>
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onResetSplitRatio(50)}
                    className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono"
                  >
                    50 / 50
                  </button>
                  <button
                    onClick={() => onResetSplitRatio(65)}
                    className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono"
                  >
                    65 / 35
                  </button>
                  <button
                    onClick={() => onResetSplitRatio(35)}
                    className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono"
                  >
                    35 / 65
                  </button>
                </div>
              </div>
            )}

            <div className="mt-2 space-y-1">
              {/* Orientation Switcher */}
              <button
                onClick={() => { onToggleOrientation(); }}
                className="w-full p-2 rounded-lg flex items-center justify-between text-left transition-colors hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-2">
                  <RotateCw className="w-4 h-4 text-amber-400" />
                  <span>Screen Mode</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-semibold capitalize">
                  {orientation === 'landscape' ? 'Landscape (PC / Laptop)' : 'Portrait (Mobile)'}
                </span>
              </button>

              <button
                onClick={() => { onToggleMaximize(); onClose(); }}
                className="w-full p-2 rounded-lg flex items-center justify-between text-left transition-colors hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-2">
                  {isMaximized ? <Minimize2 className="w-4 h-4 text-amber-500" /> : <Maximize2 className="w-4 h-4 text-blue-500" />}
                  <span>{isMaximized ? 'Exit Maximize View' : 'Maximize Code Screen'}</span>
                </div>
                <span className="text-[10px] opacity-60 font-mono">F11</span>
              </button>

              <button
                onClick={() => { onToggleDeviceFrame(); onClose(); }}
                className="w-full p-2 rounded-lg flex items-center justify-between text-left transition-colors hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-2">
                  {isDeviceFrame ? <Monitor className="w-4 h-4 text-purple-400" /> : <Smartphone className="w-4 h-4 text-purple-400" />}
                  <span>{isDeviceFrame ? 'Switch to Full PC Display' : 'Switch to Phone Mockup Frame'}</span>
                </div>
              </button>
            </div>
          </div>

          {/* Section 3: IDLE Menus */}
          <div>
            <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider mb-1 opacity-60">
              Python IDLE Menus
            </div>

            {/* File Menu */}
            <div
              className="rounded-xl border overflow-hidden mb-1.5"
              style={{ borderColor: colors.headerBorder }}
            >
              <button
                onClick={() => toggleSection('file')}
                className="w-full p-2.5 flex items-center justify-between font-semibold hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-2">
                  <FileText className="w-3.5 h-3.5 text-blue-400" />
                  <span>File Menu</span>
                </div>
                <ChevronRight className={`w-3.5 h-3.5 transition-transform ${expandedSection === 'file' ? 'rotate-90' : ''}`} />
              </button>
              {expandedSection === 'file' && (
                <div
                  className="p-2 pt-0 space-y-1 border-t"
                  style={{
                    backgroundColor: colors.headerBg,
                    borderColor: colors.headerBorder,
                  }}
                >
                  <button
                    onClick={() => { onNewFile(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <span>New File</span>
                    <span className="text-[10px] opacity-60">Ctrl+N</span>
                  </button>
                  <button
                    onClick={() => { onSaveFile(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <span>Save</span>
                    <span className="text-[10px] opacity-60">Ctrl+S</span>
                  </button>
                  <button
                    onClick={() => { onSaveAs(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <span>Save As...</span>
                  </button>
                  <button
                    onClick={() => { onExportScript(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center gap-2 hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <Download className="w-3 h-3 text-blue-400" />
                    <span>Export .py Script</span>
                  </button>
                  <button
                    onClick={() => { onImportScript(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center gap-2 hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <Upload className="w-3 h-3 text-amber-400" />
                    <span>Import Script from Disk</span>
                  </button>
                </div>
              )}
            </div>

            {/* Edit / Format Menu */}
            <div
              className="rounded-xl border overflow-hidden mb-1.5"
              style={{ borderColor: colors.headerBorder }}
            >
              <button
                onClick={() => toggleSection('edit')}
                className="w-full p-2.5 flex items-center justify-between font-semibold hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-2">
                  <Code2 className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Edit &amp; Format</span>
                </div>
                <ChevronRight className={`w-3.5 h-3.5 transition-transform ${expandedSection === 'edit' ? 'rotate-90' : ''}`} />
              </button>
              {expandedSection === 'edit' && (
                <div
                  className="p-2 pt-0 space-y-1 border-t"
                  style={{
                    backgroundColor: colors.headerBg,
                    borderColor: colors.headerBorder,
                  }}
                >
                  <button
                    onClick={() => { onIndent(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <span>Indent Region (spaces)</span>
                    <span className="text-[10px] opacity-60">Tab</span>
                  </button>
                  <button
                    onClick={() => { onDedent(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <span>Dedent Region</span>
                    <span className="text-[10px] opacity-60">Shift+Tab</span>
                  </button>
                  <button
                    onClick={() => { onComment(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <span>Comment / Uncomment</span>
                    <span className="text-[10px] opacity-60">#</span>
                  </button>
                </div>
              )}
            </div>

            {/* Shell Menu */}
            <div
              className="rounded-xl border overflow-hidden mb-1.5"
              style={{ borderColor: colors.headerBorder }}
            >
              <button
                onClick={() => toggleSection('shell')}
                className="w-full p-2.5 flex items-center justify-between font-semibold hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-2">
                  <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                  <span>Shell Menu</span>
                </div>
                <ChevronRight className={`w-3.5 h-3.5 transition-transform ${expandedSection === 'shell' ? 'rotate-90' : ''}`} />
              </button>
              {expandedSection === 'shell' && (
                <div
                  className="p-2 pt-0 space-y-1 border-t"
                  style={{
                    backgroundColor: colors.headerBg,
                    borderColor: colors.headerBorder,
                  }}
                >
                  <button
                    onClick={() => { onRestartShell(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <span>Restart Shell</span>
                    <span className="text-[10px] opacity-60">Ctrl+F6</span>
                  </button>
                  <button
                    onClick={() => { onClearShell(); onClose(); }}
                    className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-black/10 dark:hover:bg-white/5"
                  >
                    <span>Clear Screen</span>
                  </button>
                </div>
              )}
            </div>

            {/* About App Menu */}
            <div
              className="rounded-xl border overflow-hidden mb-1.5"
              style={{ borderColor: colors.headerBorder }}
            >
              <button
                onClick={() => toggleSection('about')}
                className="w-full p-2.5 flex items-center justify-between font-semibold hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-2">
                  <Info className="w-3.5 h-3.5 text-blue-400" />
                  <span className="font-bold">About App:</span>
                </div>
                <ChevronRight className={`w-3.5 h-3.5 transition-transform ${expandedSection === 'about' ? 'rotate-90' : ''}`} />
              </button>
              {expandedSection === 'about' && (
                <div
                  className="p-3 pt-2 space-y-3 border-t text-[11px] leading-relaxed"
                  style={{
                    backgroundColor: colors.headerBg,
                    borderColor: colors.headerBorder,
                  }}
                >
                  <div className="flex items-center gap-2.5 pb-2 border-b" style={{ borderColor: colors.headerBorder }}>
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 via-indigo-600 to-amber-500 text-white font-bold flex items-center justify-center text-sm shadow">
                      Py
                    </div>
                    <div>
                      <h4 className="font-bold text-xs leading-tight">Python V1 IDE</h4>
                      <p className="text-[10px] opacity-75 font-mono">CPython 3.12 Engine (Offline Edition)</p>
                    </div>
                  </div>

                  {/* Creator Attribution */}
                  <div className="p-2.5 rounded-lg border bg-blue-500/10 border-blue-500/30 text-blue-300 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-xs text-blue-200">
                      <User className="w-3.5 h-3.5" />
                      <span>Developer &amp; Creator</span>
                    </div>
                    <p className="text-[11px] text-blue-100">
                      This app was created by <strong className="text-white font-semibold">Justin B Chalackal</strong>. This app was also designed for making BEAU his personal AI, and as a primary, dedicated Python application to code and execute Python for his personal use on phones, tablets, and laptops.
                    </p>
                  </div>

                  {/* App Overview & Knowledge */}
                  <div>
                    <h5 className="font-bold text-[10px] uppercase tracking-wider mb-1.5 opacity-75">
                      About App &amp; Core Functions:
                    </h5>
                    <ul className="space-y-1.5 text-[10px] opacity-90">
                      <li className="flex items-start gap-1.5">
                        <span className="text-emerald-400 font-bold">•</span>
                        <span><strong className="text-white font-semibold">100% Offline Python 3.12 Engine:</strong> Embedded CPython WebAssembly runtime cached locally on your device. Executes scripts, math, data structures, and algorithms without any internet connection.</span>
                      </li>
                      <li className="flex items-start gap-1.5">
                        <span className="text-blue-400 font-bold">•</span>
                        <span><strong className="text-white font-semibold">Authentic IDLE REPL &amp; Editor:</strong> Features the original IDLE terminal prompt (`&gt;&gt;&gt;` and `...`), command history recall (`Alt+P`/`Alt+N`), multi-line code blocks, syntax code highlighting, and the authentic F5 Run Module flow.</span>
                      </li>
                    </ul>
                  </div>

                  <button
                    onClick={() => setShowAboutModal(true)}
                    className="w-full py-1.5 px-3 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 font-medium text-center text-[10px] transition-colors border border-blue-500/30 flex items-center justify-center gap-1.5"
                  >
                    <Info className="w-3 h-3" />
                    <span>View Full Info &amp; System Specs</span>
                  </button>
                </div>
              )}
            </div>

            {/* Password & Security Menu */}
            <div
              className="rounded-xl border overflow-hidden mb-1.5"
              style={{ borderColor: colors.headerBorder }}
            >
              <button
                onClick={() => toggleSection('password')}
                className="w-full p-2.5 flex items-center justify-between font-semibold hover:bg-black/10 dark:hover:bg-white/5"
              >
                <div className="flex items-center gap-2">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-bold">Password &amp; Security:</span>
                </div>
                <ChevronRight className={`w-3.5 h-3.5 transition-transform ${expandedSection === 'password' ? 'rotate-90' : ''}`} />
              </button>
              {expandedSection === 'password' && (
                <div
                  className="p-2.5 space-y-2 border-t text-xs"
                  style={{
                    backgroundColor: colors.headerBg,
                    borderColor: colors.headerBorder,
                  }}
                >
                  <p className="text-[10px] opacity-75 leading-tight">
                    Manage your app lock password, PIN, and failsafe security for Python V1.
                  </p>

                  {/* Change Password / PIN */}
                  <button
                    onClick={() => { setShowChangePinModal(true); }}
                    className="w-full p-2.5 rounded-lg flex items-center justify-between hover:bg-emerald-500/20 border border-emerald-500/40 bg-emerald-500/10 text-emerald-300 font-semibold transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <KeyRound className="w-4 h-4 text-emerald-400" />
                      <span>Change Password / PIN</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 opacity-60" />
                  </button>

                  {/* Reset Failsafe */}
                  <button
                    onClick={() => { setShowResetFailsafeModal(true); }}
                    className="w-full p-2.5 rounded-lg flex items-center justify-between hover:bg-amber-500/20 border border-amber-500/40 bg-amber-500/10 text-amber-300 font-semibold transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-amber-400" />
                      <span>Reset Failsafe</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 opacity-60" />
                  </button>

                  {/* Quick Lock App */}
                  {onLockApp && (
                    <button
                      onClick={() => { onLockApp(); onClose(); }}
                      className="w-full p-2 rounded-lg flex items-center justify-between hover:bg-slate-700/30 border border-slate-700 text-slate-300 font-medium transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <Lock className="w-3.5 h-3.5 text-amber-400" />
                        <span>Lock Python V1 Now</span>
                      </div>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold font-mono">F12</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Drawer Footer: HELP & SHORTCUTS BUTTON */}
        <div
          className="p-3 border-t flex items-center justify-between text-xs shrink-0"
          style={{
            backgroundColor: colors.headerBg,
            borderColor: colors.headerBorder,
          }}
        >
          <button
            onClick={() => setShowHelpModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 font-medium transition-colors border border-blue-500/20"
          >
            <HelpCircle className="w-4 h-4 text-blue-400" />
            <span className="font-semibold">Help &amp; Shortcuts</span>
          </button>
          <span className="font-mono text-[10px]">Python 3.12</span>
        </div>

      </div>

      {/* Complete Help & Keyboard Shortcuts Modal */}
      {showHelpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70">
          <div
            className="w-full max-w-md max-h-[85vh] overflow-y-auto rounded-2xl p-5 border shadow-2xl"
            style={{
              backgroundColor: colors.bg,
              borderColor: colors.headerBorder,
              color: colors.text,
            }}
          >
            <div className="flex items-center justify-between mb-3 border-b pb-3" style={{ borderColor: colors.headerBorder }}>
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center">
                  <Command className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm leading-tight">Help &amp; Keyboard Shortcuts</h3>
                  <p className="text-[11px] opacity-75">Complete guide for Phone (OTG) &amp; Windows PC</p>
                </div>
              </div>
              <button
                onClick={() => setShowHelpModal(false)}
                className="p-1 rounded-lg opacity-60 hover:opacity-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Shortcuts table */}
            <div className="space-y-4 text-xs">
              <div>
                <h4 className="font-bold text-[11px] uppercase tracking-wider mb-2 opacity-75">
                  Execution &amp; Files
                </h4>
                <div
                  className="rounded-xl p-2.5 space-y-2 font-mono border"
                  style={{
                    backgroundColor: colors.headerBg,
                    borderColor: colors.headerBorder,
                  }}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Run Script:</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">F5</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Save Script:</span>
                    <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-bold">Ctrl + S</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Open File Explorer:</span>
                    <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-bold">Ctrl + O</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">New Python File:</span>
                    <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-bold">Ctrl + N</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Restart Python Shell:</span>
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold">Ctrl + F6</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Download Pips Manager:</span>
                    <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-400 font-bold">Ctrl + P</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-[11px] uppercase tracking-wider mb-2 opacity-75">
                  Layout &amp; Navigation
                </h4>
                <div
                  className="rounded-xl p-2.5 space-y-2 font-mono border"
                  style={{
                    backgroundColor: colors.headerBg,
                    borderColor: colors.headerBorder,
                  }}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Editor Max View:</span>
                    <span className="px-2 py-0.5 rounded bg-black/20 dark:bg-white/10">Ctrl + 1</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Shell Max View:</span>
                    <span className="px-2 py-0.5 rounded bg-black/20 dark:bg-white/10">Ctrl + 2</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Split Dual View:</span>
                    <span className="px-2 py-0.5 rounded bg-black/20 dark:bg-white/10">Ctrl + 3</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Fullscreen Maximize:</span>
                    <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 font-bold">F11</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Quick Lock Python V1:</span>
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold">F12</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Previous Command in Shell:</span>
                    <span className="px-2 py-0.5 rounded bg-black/20 dark:bg-white/10">Alt + P / ↑</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Next Command in Shell:</span>
                    <span className="px-2 py-0.5 rounded bg-black/20 dark:bg-white/10">Alt + N / ↓</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-[11px] uppercase tracking-wider mb-2 opacity-75">
                  Code Formatting &amp; Editing
                </h4>
                <div
                  className="rounded-xl p-2.5 space-y-2 font-mono border"
                  style={{
                    backgroundColor: colors.headerBg,
                    borderColor: colors.headerBorder,
                  }}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Indent ({preferences.indentWidth} spaces):</span>
                    <span className="px-2 py-0.5 rounded bg-black/20 dark:bg-white/10">Tab</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Dedent:</span>
                    <span className="px-2 py-0.5 rounded bg-black/20 dark:bg-white/10">Shift + Tab</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-sans">Auto-Indent after colon (:):</span>
                    <span className="px-2 py-0.5 rounded bg-black/20 dark:bg-white/10">Enter</span>
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowHelpModal(false)}
              className="mt-5 w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg text-xs transition-colors"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {/* Quick Companion / External App Selector Modal */}
      <QuickAppSelectorModal
        isOpen={showQuickAppSelector}
        onClose={() => setShowQuickAppSelector(false)}
        selectedApp={quickApp}
        onSelectApp={(newApp) => {
          setQuickApp(newApp);
          saveSelectedQuickApp(newApp);
        }}
        colors={colors}
      />

      {/* Comprehensive About App Modal Dialog */}
      {showAboutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-xs select-none">
          <div
            className="w-full max-w-lg max-h-[88vh] overflow-y-auto rounded-2xl p-5 border shadow-2xl space-y-4"
            style={{
              backgroundColor: colors.bg,
              borderColor: colors.headerBorder,
              color: colors.text,
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b pb-3" style={{ borderColor: colors.headerBorder }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-amber-500 text-white font-bold flex items-center justify-center text-lg shadow">
                  Py
                </div>
                <div>
                  <h3 className="font-bold text-base leading-tight">About App: Python V1</h3>
                  <p className="text-xs opacity-75">Personal Python IDE &amp; Offline Interpreter</p>
                </div>
              </div>
              <button
                onClick={() => setShowAboutModal(false)}
                className="p-1.5 rounded-lg opacity-60 hover:opacity-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Creator Badge */}
            <div
              className="p-3.5 rounded-xl border space-y-1.5"
              style={{
                backgroundColor: colors.headerBg,
                borderColor: colors.headerBorder,
              }}
            >
              <div className="flex items-center gap-2 text-xs font-bold text-blue-400">
                <User className="w-4 h-4" />
                <span>Developer &amp; Creator</span>
              </div>
              <p className="text-xs leading-relaxed">
                This app was created by <strong className="text-white font-semibold">Justin B Chalackal</strong>. This app was also designed for making BEAU his personal AI, and as a primary, dedicated Python application to write, experiment with, and execute Python for his personal use across mobile phones, tablets, and laptops.
              </p>
            </div>

            {/* Technical Overview & Knowledge */}
            <div className="space-y-3 text-xs leading-relaxed">
              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider mb-1.5 text-blue-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Architecture &amp; Offline Autonomy</span>
                </h4>
                <p className="opacity-80">
                  Python V1 is powered by a WebAssembly port of the genuine CPython 3.12 interpreter. All execution takes place directly on your device CPU. The Service Worker caches the interpreter runtime so that your coding environment works 100% offline without needing internet access. Only fetching new libraries from PyPI requires an online connection.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider mb-1.5 text-amber-400">
                  Direct Physical Hard Drive Access
                </h4>
                <p className="opacity-80">
                  Unlike traditional sandboxed mobile interpreters, Python V1 connects to physical hard drives and device storage folders via the File System Access API. Standard file operations like <code className="px-1 py-0.5 rounded bg-black/30 font-mono text-[11px]">open("notes.txt", "w")</code> read and write directly to real files on your disk.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider mb-1.5 text-purple-400">
                  Core Functions &amp; Capabilities
                </h4>
                <ul className="space-y-2 opacity-85">
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 shrink-0" />
                    <span><strong>Authentic IDLE REPL:</strong> Evaluates statements interactively with <code className="font-mono text-amber-400">&gt;&gt;&gt;</code> prompts, command history (<kbd className="font-mono bg-black/30 px-1 rounded">Alt+P</kbd>/<kbd className="font-mono bg-black/30 px-1 rounded">Alt+N</kbd>), and multi-line continuation prompts.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                    <span><strong>F5 Save &amp; Run:</strong> Matches Python IDLE's authentic workflow—prompting to save modified scripts before executing.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                    <span><strong>Pip Package Downloader:</strong> Easy one-tap installation of NumPy, Pygame-CE, Matplotlib, SymPy, SciPy, Pandas, and pure Python packages from PyPI.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-pink-400 mt-1.5 shrink-0" />
                    <span><strong>Interactive Graphics &amp; Game Canvas:</strong> Output window for 2D graphics, games, and scientific plots with responsive touch D-pad controls.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                    <span><strong>Dual Laptop &amp; Phone Modes:</strong> Side-by-side drag-resizable split panes in landscape laptop mode, and full-screen view with a smart accessory keyboard strip in portrait mobile mode.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5 shrink-0" />
                    <span><strong>Customizable IDLE Themes:</strong> 8 pre-configured palettes (Dark Modern, Classic Light, Monokai Pro, Dracula, Nord, Solarized, Matrix, Sepia) plus individual syntax element color pickers.</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={() => setShowAboutModal(false)}
              className="mt-4 w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl text-xs transition-colors shadow"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Change Password / PIN Modal */}
      <ChangePinModal
        isOpen={showChangePinModal}
        onClose={() => setShowChangePinModal(false)}
        colors={colors}
      />

      {/* Reset Emergency Failsafe Modal */}
      <ResetFailsafeModal
        isOpen={showResetFailsafeModal}
        onClose={() => setShowResetFailsafeModal(false)}
        colors={colors}
      />
    </div>
  );
};
