/**
 * PyIDLE Mobile - Graphics & Canvas Display Window
 * Dedicated graphics window for Pygame 2D canvas, Matplotlib figures,
 * and visual Python simulations with virtual D-pad and controls.
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Gamepad2, Image, Trash2, Download,
  Maximize2, X, RefreshCw, ArrowUp, ArrowDown, ArrowLeft, ArrowRight
} from 'lucide-react';
import { EditorTheme } from '../types';
import { pyodideService } from '../services/pyodideService';

interface GraphicsCanvasModalProps {
  theme: EditorTheme;
  isOpen: boolean;
  onClose: () => void;
}

export const GraphicsCanvasModal: React.FC<GraphicsCanvasModalProps> = ({
  theme,
  isOpen,
  onClose,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [matplotlibImages, setMatplotlibImages] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'canvas' | 'plots'>('canvas');
  const [showDpad, setShowDpad] = useState(true);

  const isDark = theme === 'idle-dark';

  // Listen to Pygame canvas events & Matplotlib figures
  useEffect(() => {
    pyodideService.setCanvasCallback((action: any) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      if (action.type === 'init') {
        canvas.width = action.width || 360;
        canvas.height = action.height || 320;
        ctx.fillStyle = '#111827';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else if (action.type === 'fill') {
        ctx.fillStyle = action.color || 'black';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else if (action.type === 'circle') {
        ctx.beginPath();
        ctx.arc(action.x, action.y, action.r, 0, Math.PI * 2);
        if (action.width > 0) {
          ctx.strokeStyle = action.fill;
          ctx.lineWidth = action.width;
          ctx.stroke();
        } else {
          ctx.fillStyle = action.fill;
          ctx.fill();
        }
      } else if (action.type === 'rect') {
        if (action.width > 0) {
          ctx.strokeStyle = action.fill;
          ctx.lineWidth = action.width;
          ctx.strokeRect(action.x, action.y, action.w, action.h);
        } else {
          ctx.fillStyle = action.fill;
          ctx.fillRect(action.x, action.y, action.w, action.h);
        }
      } else if (action.type === 'line') {
        ctx.beginPath();
        ctx.moveTo(action.x1, action.y1);
        ctx.lineTo(action.x2, action.y2);
        ctx.strokeStyle = action.color;
        ctx.lineWidth = action.width || 1;
        ctx.stroke();
      }
    });

    pyodideService.setMatplotlibCallback((base64Png: string) => {
      setMatplotlibImages((prev) => [base64Png, ...prev]);
      setActiveTab('plots');
    });
  }, []);

  if (!isOpen) return null;

  const handleClearCanvas = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#111827';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
    }
  };

  const handleDownloadSnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `pyidle_frame_${Date.now()}.png`;
    a.click();
  };

  const bgModal = isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs select-none">
      <div className={`relative w-full max-w-xl h-[85vh] max-h-[680px] rounded-2xl border shadow-2xl flex flex-col overflow-hidden ${bgModal}`}>
        
        {/* Header */}
        <div className={`p-4 border-b flex items-center justify-between shrink-0 ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-pink-500/10 text-pink-500 flex items-center justify-center">
              <Gamepad2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm leading-tight">Graphics Display Window</h2>
              <p className="text-[11px] text-slate-400">Pygame 2D Canvas &amp; Matplotlib Output</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* View Tabs */}
        <div className={`flex items-center justify-between px-4 border-b text-xs shrink-0 ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
        }`}>
          <div className="flex items-center">
            <button
              onClick={() => setActiveTab('canvas')}
              className={`py-2.5 px-3 font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
                activeTab === 'canvas'
                  ? 'border-pink-500 text-pink-500 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>Interactive Canvas</span>
            </button>
            <button
              onClick={() => setActiveTab('plots')}
              className={`py-2.5 px-3 font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
                activeTab === 'plots'
                  ? 'border-pink-500 text-pink-500 font-semibold'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Image className="w-3.5 h-3.5" />
              <span>Matplotlib Plots ({matplotlibImages.length})</span>
            </button>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handleClearCanvas}
              className="p-1.5 rounded-md hover:bg-slate-700/50 text-slate-400 hover:text-slate-200"
              title="Clear Canvas"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleDownloadSnapshot}
              className="p-1.5 rounded-md hover:bg-slate-700/50 text-slate-400 hover:text-slate-200"
              title="Download Snapshot PNG"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-center bg-slate-950">
          {activeTab === 'canvas' ? (
            <div className="flex flex-col items-center justify-center w-full h-full gap-4">
              <div className="relative rounded-xl overflow-hidden border border-slate-800 shadow-2xl bg-black max-w-full">
                <canvas
                  ref={canvasRef}
                  width={360}
                  height={320}
                  className="block w-full max-w-[360px] h-auto object-contain"
                />
              </div>

              {/* On-screen Touch Controls for Pygame (D-Pad + Action Buttons) */}
              {showDpad && (
                <div className="w-full max-w-xs flex items-center justify-between px-2 pt-1 select-none">
                  {/* D-Pad */}
                  <div className="grid grid-cols-3 gap-1 w-28 h-28">
                    <div />
                    <button
                      className="w-9 h-9 rounded-lg bg-slate-800/80 active:bg-blue-600 text-slate-300 flex items-center justify-center shadow"
                      title="Up"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <div />
                    <button
                      className="w-9 h-9 rounded-lg bg-slate-800/80 active:bg-blue-600 text-slate-300 flex items-center justify-center shadow"
                      title="Left"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <div className="w-9 h-9 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-[10px] text-slate-500 font-mono">
                      +
                    </div>
                    <button
                      className="w-9 h-9 rounded-lg bg-slate-800/80 active:bg-blue-600 text-slate-300 flex items-center justify-center shadow"
                      title="Right"
                    >
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <div />
                    <button
                      className="w-9 h-9 rounded-lg bg-slate-800/80 active:bg-blue-600 text-slate-300 flex items-center justify-center shadow"
                      title="Down"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                    <div />
                  </div>

                  {/* Action Buttons A & B */}
                  <div className="flex items-center gap-3">
                    <button
                      className="w-12 h-12 rounded-full bg-red-600/90 active:bg-red-500 text-white font-bold text-sm flex items-center justify-center shadow-lg active:scale-95 transition-transform"
                      title="Button B"
                    >
                      B
                    </button>
                    <button
                      className="w-12 h-12 rounded-full bg-emerald-600/90 active:bg-emerald-500 text-white font-bold text-sm flex items-center justify-center shadow-lg active:scale-95 transition-transform"
                      title="Button A"
                    >
                      A
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="w-full h-full overflow-y-auto space-y-4">
              {matplotlibImages.length > 0 ? (
                matplotlibImages.map((src, i) => (
                  <div key={i} className="rounded-xl overflow-hidden border border-slate-800 bg-white p-2">
                    <img src={src} alt={`Matplotlib figure ${i + 1}`} className="w-full h-auto rounded" />
                  </div>
                ))
              ) : (
                <div className="text-center py-16 text-slate-400">
                  <Image className="w-12 h-12 mx-auto mb-2 opacity-40" />
                  <p className="text-xs">No Matplotlib plots generated yet.</p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Run `matplotlib_demo.py` from File Management to see automatic plot rendering!
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className={`p-3 border-t flex items-center justify-between text-xs shrink-0 ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowDpad(!showDpad)}
              className="text-xs text-slate-400 hover:text-slate-200"
            >
              {showDpad ? 'Hide Touch D-Pad' : 'Show Touch D-Pad'}
            </button>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
