/**
 * PyIDLE Mobile - IDLE Menu Bar Component
 * Classic Python IDLE desktop menu bar adapted for mobile touch interfaces.
 * Provides File, Edit, Format, Run, Shell, Pip, Options, Help menus.
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  FileText, Play, RotateCcw, Download,
  FolderOpen, Save, Settings, HelpCircle,
  Package, ChevronDown, Check, Sun, Moon
} from 'lucide-react';
import { EditorTheme } from '../types';

interface IDLEMenuBarProps {
  theme: EditorTheme;
  onThemeChange: (theme: EditorTheme) => void;
  onNewFile: () => void;
  onOpenFile: () => void;
  onSaveFile: () => void;
  onSaveAs: () => void;
  onRunModule: () => void;
  onRestartShell: () => void;
  onClearShell: () => void;
  onOpenPip: () => void;
  onOpenFiles: () => void;
  onOpenGraphics: () => void;
  onIndent: () => void;
  onDedent: () => void;
  onComment: () => void;
  onDownloadScript: () => void;
  onImportScript: () => void;
  activeFileName?: string;
  isDirty?: boolean;
}

export const IDLEMenuBar: React.FC<IDLEMenuBarProps> = ({
  theme,
  onThemeChange,
  onNewFile,
  onOpenFile,
  onSaveFile,
  onSaveAs,
  onRunModule,
  onRestartShell,
  onClearShell,
  onOpenPip,
  onOpenFiles,
  onOpenGraphics,
  onIndent,
  onDedent,
  onComment,
  onDownloadScript,
  onImportScript,
  activeFileName,
  isDirty,
}) => {
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [showAbout, setShowAbout] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpenMenu(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleMenu = (name: string) => {
    setOpenMenu(openMenu === name ? null : name);
  };

  const closeMenu = () => setOpenMenu(null);

  const isDark = theme === 'idle-dark';
  const barBg = isDark ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-slate-100 border-slate-300 text-slate-800';
  const dropdownBg = isDark ? 'bg-slate-900 border-slate-700 text-slate-200 shadow-xl' : 'bg-white border-slate-300 text-slate-800 shadow-lg';
  const hoverItem = isDark ? 'hover:bg-slate-800 hover:text-white' : 'hover:bg-blue-50 hover:text-blue-700';

  return (
    <div ref={menuRef} className={`relative border-b text-xs select-none z-30 transition-colors ${barBg}`}>
      <div className="flex items-center justify-between px-2 h-9 overflow-x-auto no-scrollbar">
        {/* Left: Classic IDLE Menus */}
        <div className="flex items-center space-x-0.5 shrink-0">
          {/* File Menu */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('file')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium ${
                openMenu === 'file' ? (isDark ? 'bg-slate-800' : 'bg-slate-200') : hoverItem
              }`}
            >
              <span>File</span>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>
            {openMenu === 'file' && (
              <div className={`absolute left-0 mt-1 w-52 py-1 rounded-md border text-xs z-50 ${dropdownBg}`}>
                <button
                  onClick={() => { onNewFile(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <span>New File</span>
                  <span className="text-[10px] text-slate-400">Ctrl+N</span>
                </button>
                <button
                  onClick={() => { onOpenFiles(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <span>Open...</span>
                  <span className="text-[10px] text-slate-400">Ctrl+O</span>
                </button>
                <div className={`my-1 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />
                <button
                  onClick={() => { onSaveFile(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <span>Save</span>
                  <span className="text-[10px] text-slate-400">Ctrl+S</span>
                </button>
                <button
                  onClick={() => { onSaveAs(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <span>Save As...</span>
                  <span className="text-[10px] text-slate-400">Alt+S</span>
                </button>
                <div className={`my-1 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />
                <button
                  onClick={() => { onImportScript(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center gap-2 ${hoverItem}`}
                >
                  <FolderOpen className="w-3.5 h-3.5 text-amber-500" />
                  <span>Import from Device</span>
                </button>
                <button
                  onClick={() => { onDownloadScript(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center gap-2 ${hoverItem}`}
                >
                  <Download className="w-3.5 h-3.5 text-blue-500" />
                  <span>Export .py Script</span>
                </button>
              </div>
            )}
          </div>

          {/* Edit Menu */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('edit')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium ${
                openMenu === 'edit' ? (isDark ? 'bg-slate-800' : 'bg-slate-200') : hoverItem
              }`}
            >
              <span>Edit</span>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>
            {openMenu === 'edit' && (
              <div className={`absolute left-0 mt-1 w-48 py-1 rounded-md border text-xs z-50 ${dropdownBg}`}>
                <button
                  onClick={() => { onIndent(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <span>Indent Region</span>
                  <span className="text-[10px] text-slate-400">Tab</span>
                </button>
                <button
                  onClick={() => { onDedent(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <span>Dedent Region</span>
                  <span className="text-[10px] text-slate-400">Shift+Tab</span>
                </button>
                <button
                  onClick={() => { onComment(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <span>Comment / Uncomment</span>
                  <span className="text-[10px] text-slate-400">#</span>
                </button>
              </div>
            )}
          </div>

          {/* Run Menu */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('run')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium ${
                openMenu === 'run' ? (isDark ? 'bg-slate-800' : 'bg-slate-200') : hoverItem
              }`}
            >
              <span className="text-emerald-500 font-semibold">Run</span>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>
            {openMenu === 'run' && (
              <div className={`absolute left-0 mt-1 w-52 py-1 rounded-md border text-xs z-50 ${dropdownBg}`}>
                <button
                  onClick={() => { onRunModule(); closeMenu(); }}
                  className={`w-full px-3 py-2 text-left font-medium text-emerald-600 flex items-center justify-between ${hoverItem}`}
                >
                  <div className="flex items-center gap-2">
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Run Module</span>
                  </div>
                  <span className="text-[10px] bg-emerald-500/10 px-1.5 py-0.5 rounded text-emerald-600">F5</span>
                </button>
                <button
                  onClick={() => { onOpenGraphics(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <span>Open Graphics Display</span>
                  <span className="text-[10px] text-slate-400">Canvas</span>
                </button>
              </div>
            )}
          </div>

          {/* Shell Menu */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('shell')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium ${
                openMenu === 'shell' ? (isDark ? 'bg-slate-800' : 'bg-slate-200') : hoverItem
              }`}
            >
              <span>Shell</span>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>
            {openMenu === 'shell' && (
              <div className={`absolute left-0 mt-1 w-48 py-1 rounded-md border text-xs z-50 ${dropdownBg}`}>
                <button
                  onClick={() => { onRestartShell(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <div className="flex items-center gap-1.5">
                    <RotateCcw className="w-3 h-3 text-amber-500" />
                    <span>Restart Shell</span>
                  </div>
                  <span className="text-[10px] text-slate-400">Ctrl+F6</span>
                </button>
                <button
                  onClick={() => { onClearShell(); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left ${hoverItem}`}
                >
                  Clear Screen
                </button>
              </div>
            )}
          </div>

          {/* Pip Packages Menu */}
          <div className="relative">
            <button
              onClick={() => { onOpenPip(); closeMenu(); }}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1.5 font-medium text-indigo-500 ${hoverItem}`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>Pip</span>
            </button>
          </div>

          {/* Options / Theme Menu */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('options')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium ${
                openMenu === 'options' ? (isDark ? 'bg-slate-800' : 'bg-slate-200') : hoverItem
              }`}
            >
              <Settings className="w-3 h-3 opacity-70" />
              <span>Options</span>
            </button>
            {openMenu === 'options' && (
              <div className={`absolute left-0 mt-1 w-48 py-1 rounded-md border text-xs z-50 ${dropdownBg}`}>
                <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  Color Theme
                </div>
                <button
                  onClick={() => { onThemeChange('idle-classic'); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <div className="flex items-center gap-2">
                    <Sun className="w-3.5 h-3.5 text-amber-500" />
                    <span>IDLE Classic (Light)</span>
                  </div>
                  {theme === 'idle-classic' && <Check className="w-3.5 h-3.5 text-blue-600" />}
                </button>
                <button
                  onClick={() => { onThemeChange('idle-dark'); closeMenu(); }}
                  className={`w-full px-3 py-1.5 text-left flex items-center justify-between ${hoverItem}`}
                >
                  <div className="flex items-center gap-2">
                    <Moon className="w-3.5 h-3.5 text-indigo-400" />
                    <span>IDLE Dark (Modern)</span>
                  </div>
                  {theme === 'idle-dark' && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                </button>
              </div>
            )}
          </div>

          {/* Help Menu */}
          <div className="relative">
            <button
              onClick={() => setShowAbout(true)}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium ${hoverItem}`}
            >
              <HelpCircle className="w-3 h-3 opacity-70" />
              <span>Help</span>
            </button>
          </div>
        </div>

        {/* Right: Active file indicator & Run action */}
        <div className="flex items-center gap-2 shrink-0">
          {activeFileName && (
            <span className="text-[11px] font-mono text-slate-400 truncate max-w-[130px] hidden sm:inline">
              {activeFileName}{isDirty ? ' *' : ''}
            </span>
          )}
          <button
            onClick={onRunModule}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium shadow-sm transition-transform active:scale-95"
            title="Run Module (F5)"
          >
            <Play className="w-3 h-3 fill-current" />
            <span className="font-semibold">Run</span>
          </button>
        </div>
      </div>

      {/* About IDLE Modal */}
      {showAbout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className={`w-full max-w-sm rounded-xl p-5 border shadow-2xl ${isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'}`}>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-amber-500 flex items-center justify-center text-white font-bold text-lg shadow-md">
                Py
              </div>
              <div>
                <h3 className="font-bold text-base leading-tight">Python V1</h3>
                <p className="text-xs text-slate-500">Python 3.12 for Android &amp; PC</p>
              </div>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              An authentic Python IDLE implementation for mobile devices powered by WebAssembly. Includes an interactive REPL interpreter, syntax highlighting editor, pip package downloader (NumPy, Matplotlib, Pygame, etc.), and file organizer.
            </p>
            <div className={`p-3 rounded-lg text-xs space-y-1 mb-4 ${isDark ? 'bg-slate-800/70 text-slate-300' : 'bg-slate-100 text-slate-700'}`}>
              <div className="flex justify-between">
                <span>Interpreter:</span>
                <span className="font-mono font-medium">CPython 3.12 (Pyodide Wasm)</span>
              </div>
              <div className="flex justify-between">
                <span>Pip Engine:</span>
                <span className="font-mono font-medium">micropip 0.6.0</span>
              </div>
              <div className="flex justify-between">
                <span>Virtual Storage:</span>
                <span className="font-mono font-medium">/storage/emulated/0/Python</span>
              </div>
            </div>
            <button
              onClick={() => setShowAbout(false)}
              className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg text-xs transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
