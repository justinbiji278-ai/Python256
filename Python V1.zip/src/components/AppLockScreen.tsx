import React, { useState, useEffect, useCallback } from 'react';
import {
  Lock, Unlock, Delete, KeyRound, AlertCircle,
  HelpCircle, CheckCircle2, ArrowLeft, Eye, EyeOff, ShieldAlert
} from 'lucide-react';
import { pinService } from '../services/pinService';

interface AppLockScreenProps {
  onUnlock: () => void;
}

export const AppLockScreen: React.FC<AppLockScreenProps> = ({ onUnlock }) => {
  // Main PIN input state
  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState(false);
  const [showPinText, setShowPinText] = useState(false);

  // Forgot Password / Failsafe Recovery state
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [recoveryStep, setRecoveryStep] = useState<'failsafe' | 'new-password' | 'success'>('failsafe');
  const [failsafeInput, setFailsafeInput] = useState('');
  const [recoveryError, setRecoveryError] = useState<string | null>(null);

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);

  // --- Normal Lock Screen Handlers ---
  const handleDigit = useCallback((digit: string) => {
    if (isForgotPasswordOpen) return;
    setError(null);
    setPin((prev) => {
      if (prev.length >= 8) return prev;
      return prev + digit;
    });
  }, [isForgotPasswordOpen]);

  const handleBackspace = useCallback(() => {
    if (isForgotPasswordOpen) return;
    setError(null);
    setPin((prev) => prev.slice(0, -1));
  }, [isForgotPasswordOpen]);

  const handleClear = useCallback(() => {
    if (isForgotPasswordOpen) return;
    setError(null);
    setPin('');
  }, [isForgotPasswordOpen]);

  const handleVerify = useCallback(() => {
    if (isForgotPasswordOpen) return;
    if (!pin) {
      setError('Please enter your password or PIN');
      return;
    }

    if (pinService.verifyPin(pin)) {
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate(50); } catch { /* ignore */ }
      }
      onUnlock();
    } else {
      setIsShaking(true);
      setError('Incorrect password. Please try again.');
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate([100, 50, 100]); } catch { /* ignore */ }
      }
      setTimeout(() => {
        setIsShaking(false);
        setPin('');
      }, 600);
    }
  }, [pin, onUnlock, isForgotPasswordOpen]);

  // Physical keyboard listener for PIN keypad (disabled when recovery modal is open)
  useEffect(() => {
    if (isForgotPasswordOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        handleDigit(e.key);
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Enter') {
        handleVerify();
      } else if (e.key === 'Escape') {
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleDigit, handleBackspace, handleVerify, handleClear, isForgotPasswordOpen]);

  // Auto-verify when 4 digits entered if it matches current PIN length
  useEffect(() => {
    if (isForgotPasswordOpen) return;
    const currentPin = pinService.getPin();
    if (pin.length === currentPin.length && pin === currentPin) {
      handleVerify();
    }
  }, [pin, handleVerify, isForgotPasswordOpen]);

  // --- Forgot Password Recovery Handlers ---
  const handleOpenForgotPassword = () => {
    setIsForgotPasswordOpen(true);
    setRecoveryStep('failsafe');
    setFailsafeInput('');
    setRecoveryError(null);
    setNewPassword('');
    setConfirmPassword('');
  };

  const handleCloseForgotPassword = () => {
    setIsForgotPasswordOpen(false);
    setRecoveryStep('failsafe');
    setFailsafeInput('');
    setRecoveryError(null);
    setNewPassword('');
    setConfirmPassword('');
  };

  const handleVerifyFailsafe = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);

    if (!failsafeInput.trim()) {
      setRecoveryError('Please enter the password failsafe.');
      return;
    }

    if (pinService.verifyFailsafe(failsafeInput.trim())) {
      setRecoveryStep('new-password');
      setRecoveryError(null);
    } else {
      setRecoveryError('Incorrect password failsafe. Please try again.');
    }
  };

  const handleSetNewPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);

    if (!newPassword || newPassword.trim().length === 0) {
      setRecoveryError('Please enter a new password.');
      return;
    }

    if (newPassword.trim().length < 4) {
      setRecoveryError('Password must be at least 4 characters/digits.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setRecoveryError('Passwords do not match.');
      return;
    }

    // Save new password
    const success = pinService.setPin(newPassword.trim());
    if (success) {
      setRecoveryStep('success');
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate(60); } catch { /* ignore */ }
      }
      setTimeout(() => {
        setIsForgotPasswordOpen(false);
        onUnlock();
      }, 1500);
    } else {
      setRecoveryError('Failed to save password. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-white select-none p-4">
      {/* Decorative background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Lock Card */}
      <div className="w-full max-w-sm flex flex-col items-center z-10">
        
        {/* App Branding */}
        <div className="flex flex-col items-center mb-5 text-center">
          <div className="relative mb-3">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 p-0.5 shadow-xl shadow-blue-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center">
                <span className="font-extrabold text-2xl bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent font-mono">
                  Py
                </span>
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-blue-600 border-2 border-slate-900 flex items-center justify-center shadow">
              <Lock className="w-3 h-3 text-white" />
            </div>
          </div>

          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
            Python V1
            <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
              Locked
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Personal IDE for Justin B Chalackal
          </p>
        </div>

        {/* PIN Entry Area */}
        <div className={`w-full flex flex-col items-center mb-5 ${isShaking ? 'animate-bounce' : ''}`}>
          <div className="text-xs font-medium text-slate-300 mb-2.5 flex items-center gap-1.5">
            <KeyRound className="w-3.5 h-3.5 text-blue-400" />
            <span>Enter password to unlock</span>
          </div>

          {/* Dots / Digits Display */}
          <div className="flex items-center gap-3 mb-2 h-12 px-6 rounded-xl bg-slate-900/80 border border-slate-800 shadow-inner">
            {[0, 1, 2, 3].map((idx) => {
              const isFilled = pin.length > idx;
              return (
                <div
                  key={idx}
                  className={`w-4 h-4 rounded-full transition-all duration-150 flex items-center justify-center ${
                    isFilled
                      ? 'bg-blue-500 scale-110 shadow-md shadow-blue-500/50'
                      : 'border-2 border-slate-700 bg-slate-800/50'
                  }`}
                >
                  {showPinText && isFilled && (
                    <span className="text-[10px] font-bold text-white font-mono">
                      {pin[idx]}
                    </span>
                  )}
                </div>
              );
            })}
            {pin.length > 4 && (
              <span className="text-xs font-mono text-blue-400">
                +{pin.length - 4}
              </span>
            )}
          </div>

          {/* Error Message */}
          {error && (
            <div className="flex items-center gap-1.5 text-rose-400 text-xs font-medium mt-1">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-2.5 w-full max-w-[280px]">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              onClick={() => handleDigit(digit)}
              className="h-13 rounded-2xl bg-slate-800/70 hover:bg-slate-700 active:scale-95 text-xl font-semibold text-white transition-all duration-100 flex items-center justify-center border border-slate-700/60 shadow hover:border-blue-500/40"
            >
              {digit}
            </button>
          ))}

          {/* Clear button */}
          <button
            onClick={handleClear}
            className="h-13 rounded-2xl bg-slate-900/60 hover:bg-slate-800 active:scale-95 text-xs font-bold text-slate-400 uppercase tracking-wider transition-all duration-100 flex items-center justify-center border border-slate-800 hover:text-white"
          >
            Clear
          </button>

          {/* Zero */}
          <button
            onClick={() => handleDigit('0')}
            className="h-13 rounded-2xl bg-slate-800/70 hover:bg-slate-700 active:scale-95 text-xl font-semibold text-white transition-all duration-100 flex items-center justify-center border border-slate-700/60 shadow hover:border-blue-500/40"
          >
            0
          </button>

          {/* Backspace */}
          <button
            onClick={handleBackspace}
            className="h-13 rounded-2xl bg-slate-900/60 hover:bg-slate-800 active:scale-95 text-slate-400 hover:text-white transition-all duration-100 flex items-center justify-center border border-slate-800"
            title="Backspace"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Unlock Action Button */}
        <button
          onClick={handleVerify}
          disabled={pin.length === 0}
          className={`mt-4 w-full max-w-[280px] py-3 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-lg ${
            pin.length > 0
              ? 'bg-blue-600 hover:bg-blue-500 active:scale-98 text-white shadow-blue-600/30'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
          }`}
        >
          <Unlock className="w-4 h-4" />
          <span>Unlock Python V1</span>
        </button>

        {/* Lower Controls: Show Digits and Forgot Password */}
        <div className="flex items-center justify-between w-full max-w-[280px] mt-4 text-xs">
          <button
            type="button"
            onClick={() => setShowPinText(!showPinText)}
            className="text-slate-400 hover:text-slate-200 transition-colors"
          >
            {showPinText ? 'Hide Digits' : 'Show Digits'}
          </button>

          {/* Forgot Password Link */}
          <button
            type="button"
            onClick={handleOpenForgotPassword}
            className="text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Forgot Password?</span>
          </button>
        </div>

      </div>

      {/* Forgot Password Recovery Modal */}
      {isForgotPasswordOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs select-none animate-in fade-in duration-150">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-5 text-white animate-in zoom-in-95 duration-150">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm leading-tight">Password Recovery</h3>
                  <p className="text-[11px] text-slate-400">Emergency failsafe verification</p>
                </div>
              </div>
              <button
                onClick={handleCloseForgotPassword}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>

            {/* Error banner */}
            {recoveryError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{recoveryError}</span>
              </div>
            )}

            {/* Step 1: Enter the password failsafe: */}
            {recoveryStep === 'failsafe' && (
              <form onSubmit={handleVerifyFailsafe} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold block text-slate-200">
                    Enter the password failsafe:
                  </label>
                  <p className="text-[11px] text-slate-400 leading-tight">
                    Type your emergency failsafe code to reset your password.
                  </p>
                  <input
                    type="text"
                    value={failsafeInput}
                    onChange={(e) => {
                      setFailsafeInput(e.target.value);
                      setRecoveryError(null);
                    }}
                    placeholder="Enter failsafe code"
                    autoFocus
                    className="w-full px-3 py-2.5 rounded-xl text-xs font-mono bg-slate-950 border border-slate-750 text-white outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="pt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCloseForgotPassword}
                    className="flex-1 py-2.5 px-3 rounded-xl border border-slate-700 font-medium text-xs text-slate-300 hover:bg-slate-800 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors shadow-lg shadow-blue-600/30"
                  >
                    Verify Failsafe
                  </button>
                </div>
              </form>
            )}

            {/* Step 2: Enter new password & Confirm new password */}
            {recoveryStep === 'new-password' && (
              <form onSubmit={handleSetNewPassword} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold block text-slate-200">
                    Enter new password
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      value={newPassword}
                      onChange={(e) => {
                        setNewPassword(e.target.value);
                        setRecoveryError(null);
                      }}
                      placeholder="Enter new password (min 4 digits)"
                      autoFocus
                      className="w-full px-3 py-2.5 pr-10 rounded-xl text-xs font-mono bg-slate-950 border border-slate-750 text-white outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                    >
                      {showNewPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold block text-slate-200">
                    Confirm new password
                  </label>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      setRecoveryError(null);
                    }}
                    placeholder="Confirm new password"
                    className="w-full px-3 py-2.5 rounded-xl text-xs font-mono bg-slate-950 border border-slate-750 text-white outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="pt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setRecoveryStep('failsafe')}
                    className="flex-1 py-2.5 px-3 rounded-xl border border-slate-700 font-medium text-xs text-slate-300 hover:bg-slate-800 transition-colors"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors shadow-lg shadow-blue-600/30"
                  >
                    Set Password &amp; Unlock
                  </button>
                </div>
              </form>
            )}

            {/* Step 3: Password successfully set! */}
            {recoveryStep === 'success' && (
              <div className="py-6 flex flex-col items-center justify-center text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center animate-bounce">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-emerald-400">
                    Password successfully set!
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Unlocking Python V1...
                  </p>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
