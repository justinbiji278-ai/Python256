import React, { useState } from 'react';
import { X, Lock, CheckCircle2, AlertCircle, Eye, EyeOff, KeyRound } from 'lucide-react';
import { pinService } from '../services/pinService';
import { ThemeColors } from '../utils/themePresets';

interface ChangePinModalProps {
  isOpen: boolean;
  onClose: () => void;
  colors: ThemeColors;
}

export const ChangePinModal: React.FC<ChangePinModalProps> = ({ isOpen, onClose, colors }) => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleReset = () => {
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setError(null);
    setIsSuccess(false);
  };

  const handleClose = () => {
    handleReset();
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // 1. Validate current password
    if (!currentPassword) {
      setError('Please enter your current password.');
      return;
    }

    if (!pinService.verifyPin(currentPassword)) {
      setError('Current password is incorrect.');
      return;
    }

    // 2. Validate new password
    if (!newPassword || newPassword.trim().length === 0) {
      setError('Please enter a new password.');
      return;
    }

    if (newPassword.trim().length < 4) {
      setError('New password must be at least 4 characters/digits.');
      return;
    }

    // 3. Validate confirm password
    if (!confirmPassword) {
      setError('Please confirm your new password.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('New password and confirm password do not match.');
      return;
    }

    // 4. Save new password
    const success = pinService.setPin(newPassword);
    if (success) {
      setIsSuccess(true);
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try { navigator.vibrate(60); } catch { /* ignore */ }
      }
      setTimeout(() => {
        handleClose();
      }, 1800);
    } else {
      setError('Failed to update password. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs select-none animate-in fade-in duration-150">
      <div
        className="w-full max-w-sm rounded-2xl border shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150"
        style={{
          backgroundColor: colors.bg,
          borderColor: colors.headerBorder,
          color: colors.text,
        }}
      >
        {/* Header */}
        <div
          className="p-4 border-b flex items-center justify-between"
          style={{
            backgroundColor: colors.headerBg,
            borderColor: colors.headerBorder,
          }}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm leading-tight">Change Password / PIN</h3>
              <p className="text-[11px] opacity-75">Python V1 Security Settings</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded-lg opacity-60 hover:opacity-100 transition-opacity"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5">
          {isSuccess ? (
            /* Success State */
            <div className="py-6 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-base font-bold text-emerald-400">
                  Password successfully set!
                </h4>
                <p className="text-xs opacity-75 mt-1">
                  Your new PIN has been saved securely for Python V1.
                </p>
              </div>
              <button
                type="button"
                onClick={handleClose}
                className="mt-4 px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-emerald-600/30"
              >
                Done
              </button>
            </div>
          ) : (
            /* Form Fields: Enter current password, enter new password, confirm new password */
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* 1. Enter current password */}
              <div className="space-y-1">
                <label className="text-xs font-semibold block opacity-85">
                  Enter current password
                </label>
                <div className="relative">
                  <input
                    type={showCurrent ? 'text' : 'password'}
                    value={currentPassword}
                    onChange={(e) => {
                      setCurrentPassword(e.target.value);
                      setError(null);
                    }}
                    placeholder="Enter current password"
                    autoFocus
                    className="w-full px-3 py-2.5 pr-10 rounded-xl text-xs font-mono outline-none border transition-colors focus:ring-1 focus:ring-blue-500"
                    style={{
                      backgroundColor: colors.headerBg,
                      borderColor: colors.headerBorder,
                      color: colors.text,
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrent(!showCurrent)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 transition-opacity p-1"
                  >
                    {showCurrent ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* 2. Enter new password */}
              <div className="space-y-1">
                <label className="text-xs font-semibold block opacity-85">
                  Enter new password
                </label>
                <div className="relative">
                  <input
                    type={showNew ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => {
                      setNewPassword(e.target.value);
                      setError(null);
                    }}
                    placeholder="Enter new PIN / password (min 4 digits)"
                    className="w-full px-3 py-2.5 pr-10 rounded-xl text-xs font-mono outline-none border transition-colors focus:ring-1 focus:ring-blue-500"
                    style={{
                      backgroundColor: colors.headerBg,
                      borderColor: colors.headerBorder,
                      color: colors.text,
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowNew(!showNew)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 transition-opacity p-1"
                  >
                    {showNew ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* 3. Confirm new password */}
              <div className="space-y-1">
                <label className="text-xs font-semibold block opacity-85">
                  Confirm new password
                </label>
                <div className="relative">
                  <input
                    type={showConfirm ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      setError(null);
                    }}
                    placeholder="Re-enter new PIN / password"
                    className="w-full px-3 py-2.5 pr-10 rounded-xl text-xs font-mono outline-none border transition-colors focus:ring-1 focus:ring-blue-500"
                    style={{
                      backgroundColor: colors.headerBg,
                      borderColor: colors.headerBorder,
                      color: colors.text,
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm(!showConfirm)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 transition-opacity p-1"
                  >
                    {showConfirm ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleClose}
                  className="flex-1 py-2.5 px-3 rounded-xl border font-medium text-xs opacity-80 hover:opacity-100 transition-colors"
                  style={{ borderColor: colors.headerBorder }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors shadow-lg shadow-blue-600/30 flex items-center justify-center gap-1.5"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Update Password</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
