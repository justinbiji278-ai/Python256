/**
 * PyIDLE Mobile - Pip Package Manager
 * Allows downloading and installing packages from PyPI (NumPy, Pygame, Matplotlib, Pandas, Kivy, etc.)
 * with live micropip download logs, package catalog, and installed package list.
 * Gracefully informs user when offline that internet is required for PyPI downloads,
 * while installed packages run 100% offline.
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Package, Download, CheckCircle2, AlertCircle,
  Terminal, Trash2, Search, ExternalLink, X, Loader2, Sparkles,
  Wifi, WifiOff
} from 'lucide-react';
import { EditorTheme, InstalledPackage, PipLogEntry, PopularPackage } from '../types';
import { pyodideService } from '../services/pyodideService';

interface PipManagerModalProps {
  theme: EditorTheme;
  isOpen: boolean;
  onClose: () => void;
}

const POPULAR_PACKAGES: PopularPackage[] = [
  {
    name: 'numpy',
    displayName: 'NumPy',
    category: 'Math & Science',
    description: 'N-dimensional arrays, linear algebra, FFT, and matrix computations.',
    recommendedImport: 'import numpy as np',
  },
  {
    name: 'matplotlib',
    displayName: 'Matplotlib',
    category: 'Data',
    description: 'Comprehensive 2D publication-quality plotting and data figures.',
    recommendedImport: 'import matplotlib.pyplot as plt',
  },
  {
    name: 'pandas',
    displayName: 'Pandas',
    category: 'Data',
    description: 'Data manipulation and analysis with DataFrames and Series.',
    recommendedImport: 'import pandas as pd',
  },
  {
    name: 'scipy',
    displayName: 'SciPy',
    category: 'Math & Science',
    description: 'Scientific algorithms for optimization, integration, and statistics.',
    recommendedImport: 'import scipy',
  },
  {
    name: 'sympy',
    displayName: 'SymPy',
    category: 'Math & Science',
    description: 'Computer algebra system for symbolic mathematics and calculus.',
    recommendedImport: 'import sympy as sp',
  },
  {
    name: 'pygame',
    displayName: 'Pygame',
    category: 'Games & UI',
    description: '2D game graphics engine with Canvas display and mobile touch support.',
    recommendedImport: 'import pygame',
  },
  {
    name: 'kivy',
    displayName: 'Kivy',
    category: 'Games & UI',
    description: 'Mobile user interface toolkit for rapid touch-driven Android apps.',
    recommendedImport: 'import kivy',
  },
  {
    name: 'scikit-learn',
    displayName: 'Scikit-Learn',
    category: 'Data',
    description: 'Machine learning algorithms, classification, and regression.',
    recommendedImport: 'from sklearn.linear_model import LinearRegression',
  },
  {
    name: 'requests',
    displayName: 'Requests',
    category: 'Utilities',
    description: 'HTTP library for Python, built for human developers.',
    recommendedImport: 'import requests',
  },
  {
    name: 'beautifulsoup4',
    displayName: 'Beautiful Soup 4',
    category: 'Utilities',
    description: 'HTML/XML parser for web scraping and data extraction.',
    recommendedImport: 'from bs4 import BeautifulSoup',
  },
  {
    name: 'cowsay',
    displayName: 'Cowsay',
    category: 'Utilities',
    description: 'Generates configurable ASCII art of speaking animals.',
    recommendedImport: 'import cowsay; cowsay.cow("Hello Android!")',
  },
  {
    name: 'rich',
    displayName: 'Rich',
    category: 'Utilities',
    description: 'Terminal formatting with rich text, tables, and colors.',
    recommendedImport: 'from rich import print',
  },
];

export const PipManagerModal: React.FC<PipManagerModalProps> = ({
  theme,
  isOpen,
  onClose,
}) => {
  const [packageNameInput, setPackageNameInput] = useState('');
  const [activeTab, setActiveTab] = useState<'catalog' | 'installed' | 'logs'>('catalog');
  const [isInstalling, setIsInstalling] = useState(false);
  const [installingTarget, setInstallingTarget] = useState<string | null>(null);
  const [installedList, setInstalledList] = useState<InstalledPackage[]>([]);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [logs, setLogs] = useState<PipLogEntry[]>([
    {
      id: 'log_init',
      type: 'info',
      message: 'Python V1 Micropip Engine initialized. Installed wheels run 100% offline.',
      timestamp: Date.now(),
    },
  ]);

  const logEndRef = useRef<HTMLDivElement>(null);
  const isDark = theme === 'idle-dark';

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    if (isOpen) {
      setInstalledList(pyodideService.getInstalledPackages());
    }
  }, [isOpen]);

  useEffect(() => {
    if (activeTab === 'logs') {
      logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, activeTab]);

  if (!isOpen) return null;

  const appendLog = (message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    setLogs((prev) => [
      ...prev,
      {
        id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5),
        type,
        message,
        timestamp: Date.now(),
      },
    ]);
  };

  const handleInstall = async (pkgName: string) => {
    const clean = pkgName.trim().toLowerCase();
    if (!clean || isInstalling) return;

    // Check online connectivity
    if (!navigator.onLine) {
      setActiveTab('logs');
      appendLog(`$ pip install ${clean}`, 'info');
      appendLog(
        `[Network Error] Device is currently OFFLINE. An active internet connection is required to download new packages from PyPI.`,
        'error'
      );
      appendLog(
        `Note: All your previously downloaded pips, Python scripts, and editor work 100% offline without internet.`,
        'warning'
      );
      return;
    }

    setIsInstalling(true);
    setInstallingTarget(clean);
    setActiveTab('logs');
    appendLog(`$ pip install ${clean}`, 'info');

    try {
      const ok = await pyodideService.installPackage(clean, (msg, type) => {
        appendLog(msg, type || 'info');
      });

      if (ok) {
        appendLog(`Requirement successfully satisfied for: ${clean}. Cached for offline use.`, 'success');
        setInstalledList(pyodideService.getInstalledPackages());
        setPackageNameInput('');
      } else {
        appendLog(`Failed to install ${clean}. Check package name spelling or compatibility.`, 'error');
      }
    } catch (err: any) {
      appendLog(`Installation exception: ${err.message || String(err)}`, 'error');
    } finally {
      setIsInstalling(false);
      setInstallingTarget(null);
    }
  };

  const bgModal = isDark ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const itemBg = isDark ? 'bg-slate-800/40 border-slate-800' : 'bg-slate-50 border-slate-200';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs select-none">
      <div className={`relative w-full max-w-2xl h-[85vh] max-h-[700px] rounded-2xl border shadow-2xl flex flex-col overflow-hidden ${bgModal}`}>
        
        {/* Header */}
        <div className={`p-4 border-b flex items-center justify-between shrink-0 ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/10 text-indigo-500 flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-sm leading-tight">Pip Package Downloader</h2>
                {isOnline ? (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-medium flex items-center gap-1">
                    <Wifi className="w-3 h-3" />
                    <span>Online (PyPI Ready)</span>
                  </span>
                ) : (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 font-medium flex items-center gap-1">
                    <WifiOff className="w-3 h-3" />
                    <span>Offline (Local Cache Only)</span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">Download packages online; once installed, they run 100% offline.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Pip Install Input Bar */}
        <div className={`p-3 border-b flex items-center gap-2 shrink-0 ${
          isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-100/70 border-slate-200'
        }`}>
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Enter package name (e.g. numpy, pygame, pandas, rich...)"
              value={packageNameInput}
              onChange={(e) => setPackageNameInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleInstall(packageNameInput);
                }
              }}
              disabled={isInstalling}
              className={`w-full pl-9 pr-3 py-2 rounded-lg text-xs font-mono border outline-none ${
                isDark ? 'bg-slate-800 border-slate-700 text-white placeholder:text-slate-500' : 'bg-white border-slate-300 text-black placeholder:text-slate-400'
              }`}
            />
          </div>
          <button
            onClick={() => handleInstall(packageNameInput)}
            disabled={!packageNameInput.trim() || isInstalling}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow shrink-0 transition-transform active:scale-95"
          >
            {isInstalling && installingTarget === packageNameInput.trim().toLowerCase() ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Downloading...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>Download Pip</span>
              </>
            )}
          </button>
        </div>

        {/* Tabs Bar */}
        <div className={`flex items-center px-4 border-b text-xs shrink-0 ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
        }`}>
          <button
            onClick={() => setActiveTab('catalog')}
            className={`py-2.5 px-3 font-medium border-b-2 transition-colors ${
              activeTab === 'catalog'
                ? 'border-indigo-500 text-indigo-500 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Recommended Packages
          </button>
          <button
            onClick={() => setActiveTab('installed')}
            className={`py-2.5 px-3 font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'installed'
                ? 'border-indigo-500 text-indigo-500 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Installed &amp; Cached</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-700 text-slate-300 font-mono">
              {installedList.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`py-2.5 px-3 font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'logs'
                ? 'border-indigo-500 text-indigo-500 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Pip Terminal Log</span>
            {isInstalling && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />}
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {/* Catalog Tab */}
          {activeTab === 'catalog' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {POPULAR_PACKAGES.map((pkg) => {
                  const isAlreadyInstalled = installedList.some((ip) => ip.name.toLowerCase() === pkg.name.toLowerCase());
                  const isCurrentInstalling = isInstalling && installingTarget === pkg.name;

                  return (
                    <div
                      key={pkg.name}
                      className={`p-3.5 rounded-xl border flex flex-col justify-between transition-all ${itemBg}`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs">{pkg.displayName}</span>
                            <span className="text-[10px] font-mono text-slate-400">({pkg.name})</span>
                          </div>
                          <span className="text-[10px] text-indigo-400 font-medium">
                            {pkg.category}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed mb-2.5">
                          {pkg.description}
                        </p>
                        <div className={`p-1.5 rounded font-mono text-[10px] mb-3 truncate ${
                          isDark ? 'bg-slate-900 text-slate-300' : 'bg-white border text-slate-700'
                        }`}>
                          {pkg.recommendedImport}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        {isAlreadyInstalled ? (
                          <div className="flex items-center gap-1.5 text-xs text-emerald-500 font-medium">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Installed (Runs Offline)</span>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleInstall(pkg.name)}
                            disabled={isInstalling}
                            className="w-full py-1.5 px-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 shadow-xs transition-transform active:scale-98"
                          >
                            {isCurrentInstalling ? (
                              <>
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                <span>Downloading...</span>
                              </>
                            ) : (
                              <>
                                <Download className="w-3.5 h-3.5" />
                                <span>Download to Device</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Installed Tab */}
          {activeTab === 'installed' && (
            <div className="space-y-2">
              {installedList.map((pkg) => (
                <div
                  key={pkg.name}
                  className={`p-3 rounded-xl border flex items-center justify-between ${itemBg}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center font-bold text-xs">
                      pip
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-xs font-mono">{pkg.name}</h4>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-700/50 text-slate-300 font-mono">
                          v{pkg.version}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        Cached locally · Usable 100% offline
                      </p>
                    </div>
                  </div>
                  <div className="text-emerald-500 text-xs flex items-center gap-1 font-medium">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Ready Offline</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Logs Tab */}
          {activeTab === 'logs' && (
            <div className={`p-3 rounded-xl border font-mono text-xs leading-relaxed overflow-x-auto min-h-[300px] ${
              isDark ? 'bg-slate-950 border-slate-800 text-slate-200' : 'bg-slate-900 border-slate-800 text-slate-100'
            }`}>
              {logs.map((log) => {
                let color = 'text-slate-300';
                if (log.type === 'success') color = 'text-emerald-400 font-semibold';
                if (log.type === 'error') color = 'text-red-400 font-semibold';
                if (log.type === 'warning') color = 'text-amber-400';
                return (
                  <div key={log.id} className={`${color} py-0.5 whitespace-pre-wrap`}>
                    {log.message}
                  </div>
                );
              })}
              <div ref={logEndRef} />
            </div>
          )}
        </div>

        {/* Footer */}
        <div className={`p-3 border-t flex items-center justify-between text-xs shrink-0 ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Downloaded packages are saved to local cache for offline use</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
