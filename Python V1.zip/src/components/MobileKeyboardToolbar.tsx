/**
 * PyIDLE Mobile - Mobile Keyboard Accessory Toolbar
 * Essential mobile developer toolbar providing one-tap access to
 * indentation, Python syntax symbols, brackets, and common keywords.
 */

import React from 'react';
import { Play, CornerDownRight, Undo2, Redo2 } from 'lucide-react';
import { EditorTheme } from '../types';

interface MobileKeyboardToolbarProps {
  theme: EditorTheme;
  onInsertText: (text: string) => void;
  onIndent: () => void;
  onDedent: () => void;
  onRun: () => void;
  onUndo?: () => void;
  onRedo?: () => void;
}

const COMMON_SYMBOLS = [
  ':', '(', ')', '[', ']', '{', '}',
  '"', "'", '=', '+', '-', '*', '/',
  '_', '<', '>', ',', '.', '#', '%'
];

const COMMON_KEYWORDS = [
  'def ', 'class ', 'import ', 'return ',
  'if ', 'else:', 'elif ', 'for ', 'in ',
  'while ', 'print(', 'range('
];

export const MobileKeyboardToolbar: React.FC<MobileKeyboardToolbarProps> = ({
  theme,
  onInsertText,
  onIndent,
  onDedent,
  onRun,
  onUndo,
  onRedo,
}) => {
  const isDark = theme === 'idle-dark';

  const barBg = isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-200 border-slate-300';
  const keyBg = isDark
    ? 'bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-slate-200 border-slate-700'
    : 'bg-white hover:bg-slate-100 active:bg-slate-300 text-slate-800 border-slate-300';
  const keywordBg = isDark
    ? 'bg-indigo-950/60 hover:bg-indigo-900 active:bg-indigo-800 text-indigo-300 border-indigo-800'
    : 'bg-indigo-50 hover:bg-indigo-100 active:bg-indigo-200 text-indigo-700 border-indigo-200';

  return (
    <div className={`border-t select-none shrink-0 ${barBg}`}>
      {/* Scrollable Key Strip */}
      <div className="flex items-center gap-1.5 p-1.5 overflow-x-auto no-scrollbar">
        {/* Quick Run */}
        <button
          onClick={onRun}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-medium text-xs shadow shrink-0"
          title="Run Module (F5)"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span className="font-semibold">Run</span>
        </button>

        {/* Indent & Dedent */}
        <button
          onClick={onIndent}
          className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-mono font-medium shadow-2xs shrink-0 active:scale-95 ${keyBg}`}
          title="Indent (4 spaces)"
        >
          <CornerDownRight className="w-3 h-3 text-blue-500" />
          <span>Tab</span>
        </button>
        <button
          onClick={onDedent}
          className={`px-2 py-1.5 rounded-lg border text-xs font-mono font-medium shadow-2xs shrink-0 active:scale-95 ${keyBg}`}
          title="Dedent (Remove 4 spaces)"
        >
          <span>⇤</span>
        </button>

        {/* Divider */}
        <div className={`h-5 w-px shrink-0 ${isDark ? 'bg-slate-700' : 'bg-slate-300'}`} />

        {/* Symbols */}
        {COMMON_SYMBOLS.map((sym) => (
          <button
            key={sym}
            onClick={() => onInsertText(sym)}
            className={`min-w-[32px] h-8 flex items-center justify-center rounded-lg border text-xs font-mono font-semibold shadow-2xs shrink-0 active:scale-90 transition-transform ${keyBg}`}
          >
            {sym}
          </button>
        ))}

        {/* Divider */}
        <div className={`h-5 w-px shrink-0 ${isDark ? 'bg-slate-700' : 'bg-slate-300'}`} />

        {/* Keywords */}
        {COMMON_KEYWORDS.map((kw) => (
          <button
            key={kw}
            onClick={() => onInsertText(kw)}
            className={`px-2 py-1.5 rounded-lg border text-xs font-mono shadow-2xs shrink-0 active:scale-95 ${keywordBg}`}
          >
            {kw.trim()}
          </button>
        ))}

        {/* Undo / Redo */}
        {onUndo && (
          <button
            onClick={onUndo}
            className={`p-1.5 rounded-lg border text-xs shadow-2xs shrink-0 active:scale-95 ${keyBg}`}
            title="Undo"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
        )}
        {onRedo && (
          <button
            onClick={onRedo}
            className={`p-1.5 rounded-lg border text-xs shadow-2xs shrink-0 active:scale-95 ${keyBg}`}
            title="Redo"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
