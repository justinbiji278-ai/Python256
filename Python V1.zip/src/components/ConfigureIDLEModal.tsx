/**
 * PyIDLE Mobile & Desktop - Configure IDLE Preferences Modal
 * Full customizability matching original Python IDLE desktop preferences:
 * 8 theme presets, custom syntax element color pickers, font size, font family,
 * indentation width, line numbers toggle, and live interactive Python code preview.
 */

import React, { useState } from 'react';
import {
  Palette, Sliders, Type, RotateCcw,
  Check, X, Sparkles, Eye, Sun, Moon
} from 'lucide-react';
import {
  IDLEPreferences, PRESET_THEMES, PresetThemeId,
  ThemeColors, DEFAULT_PREFERENCES
} from '../utils/themePresets';
import { tokenizePythonLine, getTokenStyle } from '../utils/pythonHighlighter';

interface ConfigureIDLEModalProps {
  isOpen: boolean;
  onClose: () => void;
  preferences: IDLEPreferences;
  onSavePreferences: (prefs: IDLEPreferences) => void;
}

const PREVIEW_PYTHON_CODE = `# Live IDLE Customization Preview
import math

def calculate_orbit(radius: float) -> dict:
    """Compute orbital path and metrics."""
    circumference = 2 * math.pi * radius
    is_valid = radius > 0
    return {"length": round(circumference, 2), "valid": is_valid}

# Test function execution
print("Orbital calculation:", calculate_orbit(42.5))
`;

export const ConfigureIDLEModal: React.FC<ConfigureIDLEModalProps> = ({
  isOpen,
  onClose,
  preferences,
  onSavePreferences,
}) => {
  const [activeTab, setActiveTab] = useState<'themes' | 'colors' | 'font'>('themes');
  const [draft, setDraft] = useState<IDLEPreferences>(preferences);

  // Sync draft when opened
  React.useEffect(() => {
    if (isOpen) {
      setDraft(preferences);
    }
  }, [isOpen, preferences]);

  if (!isOpen) return null;

  const handleSelectPreset = (presetId: Exclude<PresetThemeId, 'custom'>) => {
    const preset = PRESET_THEMES[presetId];
    if (preset) {
      setDraft((prev) => ({
        ...prev,
        themeId: presetId,
        colors: { ...preset.colors },
      }));
    }
  };

  const handleColorChange = (key: keyof ThemeColors, value: string) => {
    setDraft((prev) => ({
      ...prev,
      themeId: 'custom',
      colors: {
        ...prev.colors,
        [key]: value,
      },
    }));
  };

  const handleApplyAndClose = () => {
    onSavePreferences(draft);
    onClose();
  };

  const handleReset = (preset: 'idle-dark' | 'idle-classic') => {
    const p = PRESET_THEMES[preset];
    setDraft({
      ...DEFAULT_PREFERENCES,
      themeId: preset,
      colors: { ...p.colors },
    });
  };

  const isDarkCanvas = draft.colors.bg.toLowerCase() !== '#ffffff' && draft.colors.bg.toLowerCase() !== '#fbf0d9';

  const previewLines = PREVIEW_PYTHON_CODE.trim().split('\n');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-xs select-none">
      <div className={`relative w-full max-w-2xl h-[90vh] max-h-[720px] rounded-2xl border shadow-2xl flex flex-col overflow-hidden ${
        isDarkCanvas ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-300 text-slate-900'
      }`}>
        
        {/* Header */}
        <div className={`p-4 border-b flex items-center justify-between shrink-0 ${
          isDarkCanvas ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/10 text-indigo-500 flex items-center justify-center">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-sm leading-tight">Configure IDLE Preferences</h2>
              <p className="text-[11px] text-slate-400">Themes, syntax colors, font sizes &amp; formatting</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className={`flex items-center px-4 border-b text-xs shrink-0 ${
          isDarkCanvas ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
        }`}>
          <button
            onClick={() => setActiveTab('themes')}
            className={`py-2.5 px-3 font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'themes'
                ? 'border-indigo-500 text-indigo-500 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Theme Presets</span>
          </button>
          <button
            onClick={() => setActiveTab('colors')}
            className={`py-2.5 px-3 font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'colors'
                ? 'border-indigo-500 text-indigo-500 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Customize Colors</span>
          </button>
          <button
            onClick={() => setActiveTab('font')}
            className={`py-2.5 px-3 font-medium border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'font'
                ? 'border-indigo-500 text-indigo-500 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Type className="w-3.5 h-3.5" />
            <span>Font &amp; Indent</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          
          {/* TAB 1: Theme Presets */}
          {activeTab === 'themes' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {(Object.keys(PRESET_THEMES) as Array<Exclude<PresetThemeId, 'custom'>>).map((presetId) => {
                const preset = PRESET_THEMES[presetId];
                const isSelected = draft.themeId === presetId;

                return (
                  <div
                    key={presetId}
                    onClick={() => handleSelectPreset(presetId)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-500/5'
                        : isDarkCanvas ? 'bg-slate-800/40 border-slate-800 hover:border-slate-700' : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-xs">{preset.name}</span>
                        {presetId === 'idle-dark' && (
                          <span className="text-[10px] bg-indigo-500/20 text-indigo-400 px-1.5 py-0.2 rounded font-sans">
                            Default Dark
                          </span>
                        )}
                        {presetId === 'idle-classic' && (
                          <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.2 rounded font-sans">
                            Classic
                          </span>
                        )}
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-blue-500" />}
                    </div>

                    <p className="text-[11px] text-slate-400 mb-2.5 leading-snug">
                      {preset.description}
                    </p>

                    {/* Color Swatch Preview Bar */}
                    <div className="flex items-center gap-1.5 p-1 rounded-lg border border-slate-700/30" style={{ backgroundColor: preset.colors.bg }}>
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: preset.colors.keyword }} title="Keyword" />
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: preset.colors.builtin }} title="Builtin" />
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: preset.colors.string }} title="String" />
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: preset.colors.comment }} title="Comment" />
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: preset.colors.definition }} title="Definition" />
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: preset.colors.prompt }} title="Prompt >>>" />
                      <span className="ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded" style={{ color: preset.colors.text }}>
                        print()
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 2: Custom Colors */}
          {activeTab === 'colors' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {[
                  { label: 'Background', key: 'bg' as keyof ThemeColors },
                  { label: 'Normal Text', key: 'text' as keyof ThemeColors },
                  { label: 'Keywords (def, for)', key: 'keyword' as keyof ThemeColors },
                  { label: 'Built-ins (print, len)', key: 'builtin' as keyof ThemeColors },
                  { label: 'Strings ("hello")', key: 'string' as keyof ThemeColors },
                  { label: 'Comments (# note)', key: 'comment' as keyof ThemeColors },
                  { label: 'Definitions (func name)', key: 'definition' as keyof ThemeColors },
                  { label: 'Numbers (123, 4.5)', key: 'number' as keyof ThemeColors },
                  { label: 'Shell Prompt (>>>)', key: 'prompt' as keyof ThemeColors },
                  { label: 'Errors & Traceback', key: 'error' as keyof ThemeColors },
                  { label: 'Gutter / Line Numbers', key: 'gutterText' as keyof ThemeColors },
                ].map(({ label, key }) => (
                  <div
                    key={key}
                    className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 ${
                      isDarkCanvas ? 'bg-slate-800/40 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-[11px] font-semibold">{label}</div>
                      <div className="text-[10px] font-mono text-slate-400">{draft.colors[key]}</div>
                    </div>
                    <input
                      type="color"
                      value={draft.colors[key]}
                      onChange={(e) => handleColorChange(key, e.target.value)}
                      className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: Font & Indent */}
          {activeTab === 'font' && (
            <div className="space-y-4">
              {/* Font Size */}
              <div className={`p-3.5 rounded-xl border ${
                isDarkCanvas ? 'bg-slate-800/40 border-slate-800' : 'bg-slate-50 border-slate-200'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-xs">Editor Font Size</span>
                  <span className="font-mono text-xs font-bold text-blue-500">{draft.fontSize}px</span>
                </div>
                <input
                  type="range"
                  min={11}
                  max={20}
                  step={1}
                  value={draft.fontSize}
                  onChange={(e) => setDraft((prev) => ({ ...prev, fontSize: Number(e.target.value) }))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              {/* Font Family */}
              <div className={`p-3.5 rounded-xl border ${
                isDarkCanvas ? 'bg-slate-800/40 border-slate-800' : 'bg-slate-50 border-slate-200'
              }`}>
                <span className="font-semibold text-xs block mb-2">Monospace Font Family</span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {['JetBrains Mono', 'Courier New', 'Consolas', 'Fira Code', 'Monospace'].map((font) => (
                    <button
                      key={font}
                      onClick={() => setDraft((prev) => ({ ...prev, fontFamily: font }))}
                      className={`p-2 rounded-lg border text-xs font-mono text-center transition-colors ${
                        draft.fontFamily === font
                          ? 'border-blue-500 bg-blue-500/10 text-blue-400 font-bold'
                          : isDarkCanvas ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      {font}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tab Indent & Line Numbers */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className={`p-3.5 rounded-xl border ${
                  isDarkCanvas ? 'bg-slate-800/40 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}>
                  <span className="font-semibold text-xs block mb-2">Indentation Width</span>
                  <div className="flex items-center gap-2">
                    {[2, 4, 8].map((spaces) => (
                      <button
                        key={spaces}
                        onClick={() => setDraft((prev) => ({ ...prev, indentWidth: spaces }))}
                        className={`flex-1 py-1.5 rounded-lg border text-xs font-mono font-medium ${
                          draft.indentWidth === spaces
                            ? 'border-blue-500 bg-blue-500/10 text-blue-400 font-bold'
                            : isDarkCanvas ? 'border-slate-700' : 'border-slate-300'
                        }`}
                      >
                        {spaces} spaces
                      </button>
                    ))}
                  </div>
                </div>

                <div className={`p-3.5 rounded-xl border flex items-center justify-between ${
                  isDarkCanvas ? 'bg-slate-800/40 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}>
                  <div>
                    <div className="font-semibold text-xs">Line Numbers Gutter</div>
                    <div className="text-[10px] text-slate-400">Show numbered code margins</div>
                  </div>
                  <button
                    onClick={() => setDraft((prev) => ({ ...prev, showLineNumbers: !prev.showLineNumbers }))}
                    className={`w-11 h-6 rounded-full transition-colors p-0.5 ${
                      draft.showLineNumbers ? 'bg-blue-600' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        draft.showLineNumbers ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Live Preview Box */}
          <div className="mt-4">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              <Eye className="w-3.5 h-3.5" />
              <span>Live IDLE Preview</span>
            </div>
            <div
              className="rounded-xl p-3 border overflow-x-auto shadow-inner"
              style={{
                backgroundColor: draft.colors.bg,
                borderColor: draft.colors.headerBorder,
                fontFamily: draft.fontFamily,
                fontSize: `${draft.fontSize}px`,
                lineHeight: '1.6',
              }}
            >
              {previewLines.map((line, idx) => {
                const tokens = tokenizePythonLine(line);
                return (
                  <div key={idx} className="flex">
                    {draft.showLineNumbers && (
                      <span
                        className="w-8 select-none text-right pr-3 shrink-0 text-xs"
                        style={{ color: draft.colors.gutterText }}
                      >
                        {idx + 1}
                      </span>
                    )}
                    <span className="whitespace-pre">
                      {tokens.map((token, tIdx) => (
                        <span key={tIdx} style={getTokenStyle(token.type, draft.colors)}>
                          {token.text}
                        </span>
                      ))}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className={`p-3 border-t flex items-center justify-between text-xs shrink-0 ${
          isDarkCanvas ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleReset('idle-dark')}
              className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1"
            >
              <Moon className="w-3 h-3 text-indigo-400" />
              <span>Default Dark</span>
            </button>
            <span className="text-slate-600">·</span>
            <button
              onClick={() => handleReset('idle-classic')}
              className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1"
            >
              <Sun className="w-3 h-3 text-amber-500" />
              <span>Classic Light</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className={`px-3 py-1.5 rounded-lg border font-medium ${
                isDarkCanvas ? 'border-slate-700 text-slate-300' : 'border-slate-300 text-slate-700'
              }`}
            >
              Cancel
            </button>
            <button
              onClick={handleApplyAndClose}
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg shadow transition-transform active:scale-95"
            >
              Save Preferences
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
