/**
 * PyIDLE Mobile & Desktop - Python IDLE Script Editor
 * Authentic IDLE code editor with syntax highlighting, line numbers,
 * tabbed document management, smart auto-indentation, and dynamic theme customizability.
 * Pure edge-to-edge coding with ZERO bottom row clutter.
 * Hosts the single quick-access Run (F5) button and 3-dot options menu in the top tab header.
 */

import React, { useRef, useMemo } from 'react';
import { X, Plus, FileCode, Check, Save, Play, MoreVertical, Loader2 } from 'lucide-react';
import { FileItem } from '../types';
import { IDLEPreferences } from '../utils/themePresets';
import { tokenizePythonLine, getTokenStyle } from '../utils/pythonHighlighter';

interface IDLEEditorProps {
  preferences: IDLEPreferences;
  files: FileItem[];
  openFileIds: string[];
  activeFileId: string | null;
  onSelectTab: (id: string) => void;
  onCloseTab: (id: string) => void;
  onNewFile: () => void;
  onChangeContent: (id: string, content: string) => void;
  onSaveFile: (id: string) => void;
  onRunModule?: () => void;
  onOpenSidebar?: () => void;
  isRunning?: boolean;
  isDirty?: boolean;
  textareaRefExternal?: React.RefObject<HTMLTextAreaElement | null>;
}

export const IDLEEditor: React.FC<IDLEEditorProps> = ({
  preferences,
  files,
  openFileIds,
  activeFileId,
  onSelectTab,
  onCloseTab,
  onNewFile,
  onChangeContent,
  onSaveFile,
  onRunModule,
  onOpenSidebar,
  isRunning = false,
  isDirty = false,
  textareaRefExternal,
}) => {
  const activeFile = files.find((f) => f.id === activeFileId);
  const [savedFlash, setSavedFlash] = React.useState(false);

  const localTextareaRef = useRef<HTMLTextAreaElement>(null);
  const textareaRef = textareaRefExternal || localTextareaRef;
  const lineNumbersRef = useRef<HTMLDivElement>(null);

  const colors = preferences.colors;
  const indentSpaces = ' '.repeat(preferences.indentWidth || 4);

  // Calculate lines for line numbering & tokenization
  const lines = useMemo(() => {
    return (activeFile?.content || '').split('\n');
  }, [activeFile?.content]);

  // Sync scroll between textarea, highlight layer, and line numbers
  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    if (lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = e.currentTarget.scrollTop;
    }
    const highlightLayer = document.getElementById('code-highlight-layer');
    if (highlightLayer) {
      highlightLayer.scrollTop = e.currentTarget.scrollTop;
      highlightLayer.scrollLeft = e.currentTarget.scrollLeft;
    }
  };

  // Smart Python Enter & Tab Indentation
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (!activeFile || !textareaRef.current) return;

    // Handle Ctrl+S or Alt+S
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      onSaveFile(activeFile.id);
      setSavedFlash(true);
      setTimeout(() => setSavedFlash(false), 1500);
      return;
    }

    // Handle Tab key
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = textareaRef.current;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const val = ta.value;

      if (e.shiftKey) {
        // Dedent: remove up to indentWidth spaces from current line
        const before = val.substring(0, start);
        const lastNewline = before.lastIndexOf('\n');
        const lineStart = lastNewline === -1 ? 0 : lastNewline + 1;
        const linePrefix = val.substring(lineStart, lineStart + preferences.indentWidth);
        const spacesToRemove = linePrefix.match(/^ +/)?.[0].length || 0;
        if (spacesToRemove > 0) {
          const newVal = val.substring(0, lineStart) + val.substring(lineStart + spacesToRemove);
          onChangeContent(activeFile.id, newVal);
          setTimeout(() => {
            ta.selectionStart = Math.max(lineStart, start - spacesToRemove);
            ta.selectionEnd = Math.max(lineStart, end - spacesToRemove);
          }, 0);
        }
      } else {
        // Indent
        const newVal = val.substring(0, start) + indentSpaces + val.substring(end);
        onChangeContent(activeFile.id, newVal);
        setTimeout(() => {
          ta.selectionStart = ta.selectionEnd = start + indentSpaces.length;
        }, 0);
      }
      return;
    }

    // Smart auto-indent on Enter
    if (e.key === 'Enter') {
      e.preventDefault();
      const ta = textareaRef.current;
      const start = ta.selectionStart;
      const val = ta.value;

      const beforeCursor = val.substring(0, start);
      const curLine = beforeCursor.split('\n').pop() || '';
      const matchIndent = curLine.match(/^(\s*)/);
      let indent = matchIndent ? matchIndent[1] : '';

      // If line ends with a colon, add configured indentation!
      if (curLine.trim().endsWith(':')) {
        indent += indentSpaces;
      }

      const newVal = val.substring(0, start) + '\n' + indent + val.substring(ta.selectionEnd);
      onChangeContent(activeFile.id, newVal);
      setTimeout(() => {
        ta.selectionStart = ta.selectionEnd = start + 1 + indent.length;
      }, 0);
    }
  };

  const handleManualSave = () => {
    if (activeFile) {
      onSaveFile(activeFile.id);
      setSavedFlash(true);
      setTimeout(() => setSavedFlash(false), 1500);
    }
  };

  const openFiles = openFileIds
    .map((id) => files.find((f) => f.id === id))
    .filter((f): f is FileItem => f !== undefined);

  if (!activeFile) {
    return (
      <div
        className="flex flex-col items-center justify-center h-full p-6 text-center select-none"
        style={{ backgroundColor: colors.bg, color: colors.text }}
      >
        <FileCode className="w-12 h-12 mb-3 opacity-60" style={{ color: colors.comment }} />
        <h3 className="text-sm font-semibold mb-1">No file is open in IDLE</h3>
        <p className="text-xs max-w-xs mb-4 opacity-75">
          Create a new Python script or open an existing file from the Virtual File System.
        </p>
        <div className="flex items-center gap-2">
          <button
            onClick={onNewFile}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg text-xs flex items-center gap-1.5 shadow"
          >
            <Plus className="w-4 h-4" />
            <span>New Python File</span>
          </button>
          {onOpenSidebar && (
            <button
              onClick={onOpenSidebar}
              className="p-2 rounded-lg border text-slate-300 hover:bg-slate-800"
              style={{ borderColor: colors.headerBorder }}
              title="Open Options Menu"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      className="flex flex-col h-full select-none"
      style={{
        backgroundColor: colors.bg,
        color: colors.text,
        fontFamily: preferences.fontFamily,
      }}
    >
      {/* Header: Tabs + Only One Quick Run Button + 3-Dot Options Button */}
      <div
        className="flex items-center justify-between border-b text-xs shrink-0 select-none h-10"
        style={{
          backgroundColor: colors.headerBg,
          borderColor: colors.headerBorder,
        }}
      >
        {/* Left: Document Tabs */}
        <div className="flex items-center overflow-x-auto no-scrollbar flex-1 h-full">
          {openFiles.map((file) => {
            const isActive = file.id === activeFileId;
            return (
              <div
                key={file.id}
                onClick={() => onSelectTab(file.id)}
                className="flex items-center gap-1.5 px-3 h-full cursor-pointer border-t-2 font-mono text-xs whitespace-nowrap transition-colors shrink-0"
                style={{
                  backgroundColor: isActive ? colors.bg : 'transparent',
                  color: isActive ? colors.accent : colors.text,
                  borderTopColor: isActive ? colors.accent : 'transparent',
                  opacity: isActive ? 1 : 0.75,
                }}
              >
                <span>{file.name}{isDirty && isActive ? ' *' : ''}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onCloseTab(file.id);
                  }}
                  className="p-0.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 opacity-60 hover:opacity-100"
                  title="Close Tab"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}
          <button
            onClick={onNewFile}
            className="p-1.5 mx-1 rounded opacity-60 hover:opacity-100 shrink-0"
            title="New File (Ctrl+N)"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Right: The Single Accessible Top Run Button & 3-Dot Menu */}
        <div className="flex items-center gap-1.5 px-2 shrink-0">
          {/* Quick Save */}
          <button
            onClick={handleManualSave}
            className="p-1.5 rounded transition-colors opacity-75 hover:opacity-100"
            title="Save (Ctrl+S)"
          >
            {savedFlash ? (
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Save className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Quick Accessible Run (F5) Button */}
          {onRunModule && (
            <button
              onClick={onRunModule}
              disabled={isRunning}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold text-xs shadow transition-transform active:scale-95"
              title="Run Module (F5) - Shows Save dialog if modified"
            >
              {isRunning ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span className="hidden sm:inline">Running</span>
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 fill-current" />
                  <span>Run</span>
                  <span className="text-[10px] opacity-75 font-mono hidden sm:inline">F5</span>
                </>
              )}
            </button>
          )}

          {/* 3-Dot Options Button */}
          {onOpenSidebar && (
            <button
              onClick={onOpenSidebar}
              className="p-1.5 rounded-lg border transition-colors opacity-85 hover:opacity-100"
              style={{
                backgroundColor: colors.bg,
                borderColor: colors.headerBorder,
              }}
              title="Options & Tools Menu"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Editor Body: Line Numbers + Highlight Layer + Textarea (Pure Edge-to-Edge) */}
      <div
        className="relative flex-1 flex overflow-hidden text-[13px]"
        style={{
          fontSize: `${preferences.fontSize}px`,
        }}
      >
        {/* Line Numbers Gutter */}
        {preferences.showLineNumbers && (
          <div
            ref={lineNumbersRef}
            className="w-11 py-3 pr-2 text-right select-none overflow-hidden shrink-0 border-r leading-6 text-xs font-mono"
            style={{
              backgroundColor: colors.gutterBg,
              color: colors.gutterText,
              borderColor: colors.headerBorder,
            }}
          >
            {lines.map((_, i) => (
              <div key={i}>
                {i + 1}
              </div>
            ))}
          </div>
        )}

        {/* Code Area Wrapper */}
        <div className="relative flex-1 h-full overflow-hidden">
          {/* Syntax Highlighted Layer with custom ThemeColors */}
          <div
            id="code-highlight-layer"
            aria-hidden="true"
            className="absolute inset-0 p-3 leading-6 whitespace-pre font-mono overflow-hidden pointer-events-none select-none text-[13px]"
            style={{
              fontSize: `${preferences.fontSize}px`,
              fontFamily: preferences.fontFamily,
            }}
          >
            {lines.map((line, idx) => {
              const tokens = tokenizePythonLine(line);
              return (
                <div key={idx} className="h-6">
                  {tokens.map((token, tIdx) => (
                    <span key={tIdx} style={getTokenStyle(token.type, colors)}>
                      {token.text}
                    </span>
                  ))}
                </div>
              );
            })}
          </div>

          {/* Interactive Textarea */}
          <textarea
            ref={textareaRef}
            value={activeFile.content}
            onChange={(e) => {
              onChangeContent(activeFile.id, e.target.value);
            }}
            onScroll={handleScroll}
            onKeyDown={handleKeyDown}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            autoCorrect="off"
            className="absolute inset-0 p-3 leading-6 font-mono text-[13px] bg-transparent resize-none outline-none overflow-auto whitespace-pre z-10 selection:bg-blue-500/30 text-transparent caret-blue-500"
            style={{
              fontSize: `${preferences.fontSize}px`,
              fontFamily: preferences.fontFamily,
              caretColor: colors.accent,
            }}
          />
        </div>
      </div>
    </div>
  );
};
