/**
 * PyIDLE Mobile - Android Viewport Shell
 * Edge-to-edge maximized coding workspace with zero simulated status bars or duplicate battery icons.
 * Full screen real estate is dedicated entirely to your Python code.
 */

import React from 'react';
import { EditorTheme } from '../types';

interface AndroidFrameProps {
  theme: EditorTheme;
  isMaximized: boolean;
  onToggleMaximize: () => void;
  isDeviceFrame: boolean;
  onToggleDeviceFrame: () => void;
  layoutMode: 'editor' | 'shell' | 'split';
  onLayoutModeChange: (mode: 'editor' | 'shell' | 'split') => void;
  orientation: 'landscape' | 'portrait';
  onToggleOrientation: () => void;
  children: React.ReactNode;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  theme,
  isDeviceFrame,
  orientation,
  children,
}) => {
  const isDark = theme === 'idle-dark';

  const innerContent = (
    <div className={`h-full w-full overflow-hidden flex flex-col ${isDark ? 'bg-[#181825]' : 'bg-white'}`}>
      {/* 100% pure workspace - no simulated status bar or duplicate battery icons */}
      <div className="flex-1 w-full h-full overflow-hidden relative">
        {children}
      </div>
    </div>
  );

  // If testing inside the optional Phone Mockup Frame
  if (isDeviceFrame) {
    const isLandscape = orientation === 'landscape';

    return (
      <div className="min-h-screen w-full bg-slate-950 flex items-center justify-center p-2 sm:p-4 overflow-auto">
        <div
          className={`relative bg-black shadow-2xl border-4 border-slate-800 ring-1 ring-slate-700 flex flex-col overflow-hidden transition-all duration-300 ${
            isLandscape
              ? 'w-full max-w-[920px] h-[88vh] max-h-[560px] rounded-[32px] p-2'
              : 'w-full max-w-[420px] h-[92vh] max-h-[860px] rounded-[44px] p-2.5'
          }`}
        >
          {/* Subtle camera punch hole */}
          <div
            className={`absolute z-40 bg-black flex items-center justify-center ${
              isLandscape
                ? 'top-2 left-1/2 -translate-x-1/2 w-16 h-2.5 rounded-full'
                : 'top-2.5 left-1/2 -translate-x-1/2 w-24 h-3.5 rounded-full'
            }`}
          >
            <div className="w-2 h-2 rounded-full bg-slate-900 border border-slate-800" />
          </div>

          {/* Screen Content */}
          <div className={`w-full h-full overflow-hidden bg-slate-900 flex flex-col ${isLandscape ? 'rounded-[24px]' : 'rounded-[34px]'}`}>
            {innerContent}
          </div>
        </div>
      </div>
    );
  }

  // Pure Edge-to-Edge Screen (Default for connected phone / laptop mode)
  return (
    <div className="h-screen w-screen bg-slate-950 overflow-hidden flex flex-col">
      {innerContent}
    </div>
  );
};
