/**
 * PyIDLE Mobile & Windows PC - Main Application
 * Python IDLE & Pydroid 3 environment runnable on Android phones, tablets, and Windows PC.
 * Runs 100% OFFLINE with CacheFirst WebAssembly engine and local disk read/write.
 * Only downloading new packages from PyPI requires an active internet connection.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { WifiOff } from 'lucide-react';
import { EditorTheme, FileItem, FolderItem } from './types';
import { fileSystemService } from './services/fileSystemService';
import { pyodideService } from './services/pyodideService';
import { localDiskService } from './services/localDiskService';
import { AndroidFrame } from './components/AndroidFrame';
import { IDLEEditor } from './components/IDLEEditor';
import { IDLEShell } from './components/IDLEShell';
import { MobileKeyboardToolbar } from './components/MobileKeyboardToolbar';
import { FileManagerDrawer } from './components/FileManagerDrawer';
import { PipManagerModal } from './components/PipManagerModal';
import { GraphicsCanvasModal } from './components/GraphicsCanvasModal';
import { IDLESidebar } from './components/IDLESidebar';
import { SaveAndRunModal } from './components/SaveAndRunModal';
import { ConfigureIDLEModal } from './components/ConfigureIDLEModal';
import { AppLockScreen } from './components/AppLockScreen';
import { IDLEPreferences, loadIDLEPreferences, saveIDLEPreferences } from './utils/themePresets';

export default function App() {
  // App Lock State (PIN 4971 by default)
  const [isUnlocked, setIsUnlocked] = useState(false);

  // Theme state and custom preferences (8 preset themes + granular syntax color pickers)
  const [preferences, setPreferences] = useState<IDLEPreferences>(loadIDLEPreferences());
  const theme: EditorTheme = preferences.themeId === 'idle-classic' ? 'idle-classic' : 'idle-dark';
  const [showConfigureModal, setShowConfigureModal] = useState(false);
  
  // App Experience: Pydroid 3 (Phone Mode) vs Python IDLE (Laptop/PC Mode)
  const [appExperience, setAppExperience] = useState<'pydroid' | 'idle'>('idle');

  // Online / Offline state
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // File System state
  const [files, setFiles] = useState<FileItem[]>([]);
  const [folders, setFolders] = useState<FolderItem[]>([]);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [openFileIds, setOpenFileIds] = useState<string[]>([]);
  const [isDirtyMap, setIsDirtyMap] = useState<Record<string, boolean>>({});
  const [mountedFolderName, setMountedFolderName] = useState<string | null>(null);

  // Layout & Orientation:
  const [orientation, setOrientation] = useState<'landscape' | 'portrait'>('landscape');
  const [layoutMode, setLayoutMode] = useState<'editor' | 'shell' | 'split'>('editor');
  const [splitRatio, setSplitRatio] = useState<number>(50); // percentage for editor pane
  const [isDraggingSplitter, setIsDraggingSplitter] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [isDeviceFrame, setIsDeviceFrame] = useState(false);
  const [showTouchBar, setShowTouchBar] = useState(false);

  // PWA Install Prompt
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // Modals and Drawers
  const [showSidebar, setShowSidebar] = useState(false);
  const [showFileManager, setShowFileManager] = useState(false);
  const [showPipManager, setShowPipManager] = useState(false);
  const [showGraphics, setShowGraphics] = useState(false);
  const [showSaveAndRunModal, setShowSaveAndRunModal] = useState(false);

  // Engine state
  const [engineStatus, setEngineStatus] = useState<string>('Initializing CPython...');
  const [isRunning, setIsRunning] = useState(false);
  const [engineReady, setEngineReady] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Monitor network connectivity
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Detect initial screen width: if mobile portrait, set pydroid default
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (window.innerWidth < 768 && window.innerHeight > window.innerWidth) {
        setOrientation('portrait');
        setAppExperience('pydroid');
      }
    }
  }, []);

  // Listen for beforeinstallprompt (Windows PC / Android PWA installation)
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleInstallPwa = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  // Load initial files from VFS
  const refreshVFS = useCallback(() => {
    const state = fileSystemService.getState();
    setFiles(state.files);
    setFolders(state.folders);
    setActiveFileId(state.activeFileId);
    setOpenFileIds(state.openFileIds);
  }, []);

  useEffect(() => {
    refreshVFS();

    // Start loading Pyodide in background
    pyodideService.onStatus((status) => {
      setEngineStatus(status);
      if (status === 'Ready') {
        setEngineReady(true);
      }
    });

    pyodideService.init().catch((err) => {
      console.warn('Pyodide init error:', err);
    });
  }, [refreshVFS]);

  const activeFile = files.find((f) => f.id === activeFileId);
  const isCurrentFileDirty = activeFile ? Boolean(isDirtyMap[activeFile.id]) : false;

  // Mount real hard drive folder
  const handleMountHardDrive = async () => {
    try {
      const res = await localDiskService.mountLocalFolder();
      if (res && res.files.length > 0) {
        setMountedFolderName(res.folderName);
        setFiles(res.files);
        setOpenFileIds(res.files.map((f) => f.id));
        setActiveFileId(res.files[0]?.id || null);
        alert(`Successfully mounted hard drive folder "${res.folderName}"! Python scripts now have real read/write disk access.`);
      }
    } catch (err: any) {
      alert(`Could not mount hard drive folder: ${err.message || err}`);
    }
  };

  // File Operations
  const handleSelectTab = (id: string) => {
    const updated = fileSystemService.setActiveFileId(id);
    setActiveFileId(updated.activeFileId);
    setOpenFileIds(updated.openFileIds);
  };

  const handleCloseTab = (id: string) => {
    const updated = fileSystemService.closeFileTab(id);
    setActiveFileId(updated.activeFileId);
    setOpenFileIds(updated.openFileIds);
  };

  const handleNewFile = () => {
    const newFile = fileSystemService.createFile(`untitled_${files.length + 1}.py`);
    refreshVFS();
    handleSelectTab(newFile.id);
  };

  const handleChangeContent = (id: string, newContent: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === id ? { ...f, content: newContent } : f))
    );
    setIsDirtyMap((prev) => ({ ...prev, [id]: true }));
  };

  const handleSaveFile = async (id?: string) => {
    const targetId = id || activeFileId;
    if (!targetId) return;
    const file = files.find((f) => f.id === targetId);
    if (file) {
      fileSystemService.saveScript(file.id, file.content);
      // If hard drive folder is mounted, save directly to real physical hard drive!
      if (mountedFolderName) {
        await localDiskService.saveFileToDisk(file.name, file.content);
      }
      setIsDirtyMap((prev) => ({ ...prev, [file.id]: false }));
    }
  };

  // Direct execution
  const executeScript = async (fileToRun: FileItem) => {
    if (layoutMode === 'editor') {
      setLayoutMode('split');
    }

    setIsRunning(true);
    try {
      // Sync file to Pyodide FS first so open() works
      await localDiskService.syncToPyodideFS([fileToRun]);
      await pyodideService.runPython(fileToRun.content);
      // Sync any new files generated by Python script back to hard drive
      if (mountedFolderName) {
        await localDiskService.syncPyodideOutputToDisk();
      }
    } catch (err) {
      console.error('Execution error:', err);
    } finally {
      setIsRunning(false);
    }
  };

  // Run Module triggered by F5 or Run button:
  const handleRunModuleTrigger = () => {
    if (!activeFile) return;

    if (isCurrentFileDirty) {
      setShowSaveAndRunModal(true);
    } else {
      executeScript(activeFile);
    }
  };

  // Confirmed Save and Run from modal
  const handleConfirmSaveAndRun = async () => {
    if (!activeFile) return;
    await handleSaveFile(activeFile.id);
    setShowSaveAndRunModal(false);
    executeScript(activeFile);
  };

  // Run without saving
  const handleRunWithoutSaving = () => {
    if (!activeFile) return;
    setShowSaveAndRunModal(false);
    executeScript(activeFile);
  };

  // Restart Shell
  const handleRestartShell = async () => {
    setIsRunning(true);
    await pyodideService.restartShell();
    setIsRunning(false);
  };

  // Text insertion for toolbar / shortcuts
  const handleInsertText = (text: string) => {
    if (!textareaRef.current || !activeFile) return;
    const ta = textareaRef.current;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const val = ta.value;

    const newVal = val.substring(0, start) + text + val.substring(end);
    handleChangeContent(activeFile.id, newVal);

    setTimeout(() => {
      ta.focus();
      ta.selectionStart = ta.selectionEnd = start + text.length;
    }, 0);
  };

  const handleIndent = () => {
    handleInsertText('    ');
  };

  const handleDedent = () => {
    if (!textareaRef.current || !activeFile) return;
    const ta = textareaRef.current;
    const val = ta.value;
    const start = ta.selectionStart;

    const before = val.substring(0, start);
    const lastNewline = before.lastIndexOf('\n');
    const lineStart = lastNewline === -1 ? 0 : lastNewline + 1;
    const prefix = val.substring(lineStart, lineStart + 4);
    const count = prefix.match(/^ +/)?.[0].length || 0;

    if (count > 0) {
      const newVal = val.substring(0, lineStart) + val.substring(lineStart + count);
      handleChangeContent(activeFile.id, newVal);
      setTimeout(() => {
        ta.focus();
        ta.selectionStart = ta.selectionEnd = Math.max(lineStart, start - count);
      }, 0);
    }
  };

  const handleComment = () => {
    if (!textareaRef.current || !activeFile) return;
    const ta = textareaRef.current;
    const val = ta.value;
    const start = ta.selectionStart;

    const before = val.substring(0, start);
    const lastNewline = before.lastIndexOf('\n');
    const lineStart = lastNewline === -1 ? 0 : lastNewline + 1;

    if (val.substring(lineStart, lineStart + 1) === '#') {
      const sliceLen = val.substring(lineStart, lineStart + 2) === '# ' ? 2 : 1;
      const newVal = val.substring(0, lineStart) + val.substring(lineStart + sliceLen);
      handleChangeContent(activeFile.id, newVal);
    } else {
      const newVal = val.substring(0, lineStart) + '# ' + val.substring(lineStart);
      handleChangeContent(activeFile.id, newVal);
    }
  };

  // Toggle orientation
  const handleToggleOrientation = () => {
    setOrientation((prev) => (prev === 'landscape' ? 'portrait' : 'landscape'));
  };

  // Drag-to-Resize Split Panes (Mouse on PC & Touch on Phone)
  const handleStartSplitterDrag = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    setIsDraggingSplitter(true);
  };

  useEffect(() => {
    if (!isDraggingSplitter) return;

    const handleMouseMove = (e: MouseEvent | TouchEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const isLandscape = orientation === 'landscape';

      let clientPos = 0;
      let totalSize = 0;

      if ('touches' in e && e.touches.length > 0) {
        clientPos = isLandscape ? e.touches[0].clientX - rect.left : e.touches[0].clientY - rect.top;
      } else if ('clientX' in e) {
        clientPos = isLandscape ? (e as MouseEvent).clientX - rect.left : (e as MouseEvent).clientY - rect.top;
      }

      totalSize = isLandscape ? rect.width : rect.height;
      if (totalSize > 0) {
        const ratio = Math.min(80, Math.max(20, Math.round((clientPos / totalSize) * 100)));
        setSplitRatio(ratio);
      }
    };

    const handleMouseUp = () => {
      setIsDraggingSplitter(false);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('touchmove', handleMouseMove);
    window.addEventListener('touchend', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleMouseMove);
      window.removeEventListener('touchend', handleMouseUp);
    };
  }, [isDraggingSplitter, orientation]);

  // Hardware Keyboard Shortcuts Listener
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // F5: Run Module
      if (e.key === 'F5') {
        e.preventDefault();
        handleRunModuleTrigger();
        return;
      }

      // F11: Toggle Fullscreen Maximize
      if (e.key === 'F11') {
        e.preventDefault();
        setIsMaximized((prev) => !prev);
        return;
      }

      // F12: Quick Lock Python V1
      if (e.key === 'F12') {
        e.preventDefault();
        setIsUnlocked(false);
        return;
      }

      // Ctrl+S / Cmd+S: Save File
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSaveFile();
        return;
      }

      // Ctrl+O: Open File Manager
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'o') {
        e.preventDefault();
        setShowFileManager(true);
        return;
      }

      // Ctrl+N: New File
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        handleNewFile();
        return;
      }

      // Ctrl+F6: Restart Shell
      if ((e.ctrlKey || e.metaKey) && e.key === 'F6') {
        e.preventDefault();
        handleRestartShell();
        return;
      }

      // Ctrl+1: Editor View
      if ((e.ctrlKey || e.metaKey) && e.key === '1') {
        e.preventDefault();
        setLayoutMode('editor');
        return;
      }

      // Ctrl+2: Shell View
      if ((e.ctrlKey || e.metaKey) && e.key === '2') {
        e.preventDefault();
        setLayoutMode('shell');
        return;
      }

      // Ctrl+3: Split View
      if ((e.ctrlKey || e.metaKey) && e.key === '3') {
        e.preventDefault();
        setLayoutMode('split');
        return;
      }

      // Ctrl+P / Cmd+P: Open Pip Manager
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        setShowPipManager(true);
        return;
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [activeFile, files, isCurrentFileDirty, layoutMode]);

  const isLandscape = orientation === 'landscape';

  return (
    <AndroidFrame
      theme={theme}
      isMaximized={isMaximized}
      onToggleMaximize={() => setIsMaximized(!isMaximized)}
      isDeviceFrame={isDeviceFrame}
      onToggleDeviceFrame={() => setIsDeviceFrame(!isDeviceFrame)}
      layoutMode={layoutMode}
      onLayoutModeChange={setLayoutMode}
      orientation={orientation}
      onToggleOrientation={handleToggleOrientation}
    >
      <div className="flex flex-col h-full w-full overflow-hidden select-none relative">
        
        {/* Main Coding Workspace: 100% edge-to-edge screen */}
        <div
          ref={containerRef}
          className={`flex-1 flex overflow-hidden relative ${
            isLandscape ? 'flex-row' : 'flex-col md:flex-row'
          }`}
        >
          {/* Editor Area */}
          {(layoutMode === 'editor' || layoutMode === 'split') && (
            <div
              style={{
                width: layoutMode === 'split' ? (isLandscape ? `${splitRatio}%` : '100%') : '100%',
                height: layoutMode === 'split' ? (isLandscape ? '100%' : `${splitRatio}%`) : '100%',
              }}
              className="overflow-hidden transition-none relative"
            >
              <IDLEEditor
                preferences={preferences}
                files={files}
                openFileIds={openFileIds}
                activeFileId={activeFileId}
                onSelectTab={handleSelectTab}
                onCloseTab={handleCloseTab}
                onNewFile={handleNewFile}
                onChangeContent={handleChangeContent}
                onSaveFile={handleSaveFile}
                onRunModule={handleRunModuleTrigger}
                onOpenSidebar={() => setShowSidebar(true)}
                isRunning={isRunning}
                isDirty={isCurrentFileDirty}
                textareaRefExternal={textareaRef}
              />
            </div>
          )}

          {/* Interactive Drag-Resizable Splitter Bar */}
          {layoutMode === 'split' && (
            <div
              onMouseDown={handleStartSplitterDrag}
              onTouchStart={handleStartSplitterDrag}
              className={`shrink-0 z-20 transition-colors select-none flex items-center justify-center ${
                isLandscape
                  ? 'w-1.5 h-full cursor-col-resize hover:bg-blue-500 active:bg-blue-600 bg-slate-800'
                  : 'w-full h-1.5 cursor-row-resize hover:bg-blue-500 active:bg-blue-600 bg-slate-800'
              } ${isDraggingSplitter ? 'bg-blue-500' : ''}`}
              title="Drag to resize Editor / Shell split"
            >
              <div
                className={`rounded-full bg-slate-400 opacity-60 ${
                  isLandscape ? 'w-0.5 h-6' : 'h-0.5 w-6'
                }`}
              />
            </div>
          )}

          {/* Interactive Shell Area */}
          {(layoutMode === 'shell' || layoutMode === 'split') && (
            <div
              style={{
                width: layoutMode === 'split' ? (isLandscape ? `${100 - splitRatio}%` : '100%') : '100%',
                height: layoutMode === 'split' ? (isLandscape ? '100%' : `${100 - splitRatio}%`) : '100%',
              }}
              className="overflow-hidden transition-none"
            >
              <IDLEShell
                preferences={preferences}
                onRestartShell={handleRestartShell}
                isRunning={isRunning}
                onOpenSidebar={() => setShowSidebar(true)}
              />
            </div>
          )}

          {/* Unobtrusive Python Kernel status badge during initial WebAssembly boot */}
          {!engineReady && (
            <div className="absolute bottom-3 left-3 z-30 px-3 py-1.5 rounded-full bg-slate-900/90 text-slate-200 text-xs border border-slate-700 shadow-lg flex items-center gap-2 backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span className="font-mono">{engineStatus}</span>
            </div>
          )}

          {/* Quiet Offline Indicator if device disconnects from internet */}
          {!isOnline && (
            <div className="absolute top-12 right-3 z-30 px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] flex items-center gap-1.5 backdrop-blur-md">
              <WifiOff className="w-3 h-3 text-amber-400" />
              <span>Offline Mode (Python Engine Running Locally)</span>
            </div>
          )}
        </div>

        {/* Optional Touch Keyboard Toolbar (Toggleable from 3-dot sidebar) */}
        {showTouchBar && (
          <MobileKeyboardToolbar
            theme={theme}
            onInsertText={handleInsertText}
            onIndent={handleIndent}
            onDedent={handleDedent}
            onRun={handleRunModuleTrigger}
          />
        )}

        {/* 3-Dot Sidebar Drawer (Includes Help & Shortcuts button, Hard drive mounting, Pydroid vs IDLE modes) */}
        <IDLESidebar
          theme={theme}
          preferences={preferences}
          onOpenConfigureIDLE={() => setShowConfigureModal(true)}
          isOpen={showSidebar}
          onClose={() => setShowSidebar(false)}
          onOpenFiles={() => setShowFileManager(true)}
          onOpenPip={() => setShowPipManager(true)}
          onOpenGraphics={() => setShowGraphics(true)}
          showTouchBar={showTouchBar}
          onToggleTouchBar={() => setShowTouchBar(!showTouchBar)}
          onNewFile={handleNewFile}
          onSaveFile={() => handleSaveFile()}
          onSaveAs={() => setShowFileManager(true)}
          onExportScript={() => activeFile && fileSystemService.downloadFile(activeFile.id)}
          onImportScript={() => setShowFileManager(true)}
          onIndent={handleIndent}
          onDedent={handleDedent}
          onComment={handleComment}
          onRestartShell={handleRestartShell}
          onClearShell={() => {}}
          layoutMode={layoutMode}
          onLayoutModeChange={setLayoutMode}
          orientation={orientation}
          onToggleOrientation={handleToggleOrientation}
          isMaximized={isMaximized}
          onToggleMaximize={() => setIsMaximized(!isMaximized)}
          isDeviceFrame={isDeviceFrame}
          onToggleDeviceFrame={() => setIsDeviceFrame(!isDeviceFrame)}
          activeFileName={activeFile?.name}
          onResetSplitRatio={(ratio) => setSplitRatio(ratio)}
          onMountHardDrive={handleMountHardDrive}
          mountedFolderName={mountedFolderName}
          onInstallPwa={handleInstallPwa}
          canInstallPwa={Boolean(deferredPrompt)}
          onLockApp={() => setIsUnlocked(false)}
        />

        {/* Authentic IDLE Save-Before-Run Modal */}
        <SaveAndRunModal
          theme={theme}
          isOpen={showSaveAndRunModal}
          fileName={activeFile?.name || 'Untitled.py'}
          onSaveAndRun={handleConfirmSaveAndRun}
          onRunWithoutSaving={handleRunWithoutSaving}
          onCancel={() => setShowSaveAndRunModal(false)}
        />

        {/* File Management System */}
        <FileManagerDrawer
          theme={theme}
          isOpen={showFileManager}
          onClose={() => setShowFileManager(false)}
          files={files}
          folders={folders}
          activeFileId={activeFileId}
          onOpenFile={(id) => {
            handleSelectTab(id);
            setLayoutMode('editor');
          }}
          onRefreshVFS={refreshVFS}
          onSaveCurrentScript={() => handleSaveFile()}
          onMountedHardDrive={(diskFiles, folderName) => {
            setMountedFolderName(folderName);
            setFiles(diskFiles);
            setOpenFileIds(diskFiles.map((f) => f.id));
            setActiveFileId(diskFiles[0]?.id || null);
          }}
          mountedFolderName={mountedFolderName}
        />

        {/* Pip Package Downloader */}
        <PipManagerModal
          theme={theme}
          isOpen={showPipManager}
          onClose={() => setShowPipManager(false)}
        />

        {/* Graphics Display Window (Pygame & Matplotlib) */}
        <GraphicsCanvasModal
          theme={theme}
          isOpen={showGraphics}
          onClose={() => setShowGraphics(false)}
        />

        {/* Configure IDLE Preferences Modal (8 Presets + Custom Color Pickers) */}
        <ConfigureIDLEModal
          isOpen={showConfigureModal}
          onClose={() => setShowConfigureModal(false)}
          preferences={preferences}
          onSavePreferences={(newPrefs) => {
            setPreferences(newPrefs);
            saveIDLEPreferences(newPrefs);
          }}
        />

        {/* App Lock Screen (Default PIN: 4971) */}
        {!isUnlocked && (
          <AppLockScreen onUnlock={() => setIsUnlocked(true)} />
        )}

      </div>
    </AndroidFrame>
  );
}
