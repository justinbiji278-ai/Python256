/**
 * PyIDLE Mobile - Type Definitions
 */

export interface FileItem {
  id: string;
  name: string;
  content: string;
  folderId: string | null; // null for root
  createdAt: number;
  updatedAt: number;
}

export interface FolderItem {
  id: string;
  name: string;
  parentId: string | null; // null for root
  createdAt: number;
}

export interface FileSystemState {
  folders: FolderItem[];
  files: FileItem[];
  activeFileId: string | null;
  openFileIds: string[];
}

export type EditorTheme = 'idle-classic' | 'idle-dark';

export type StreamType = 'stdout' | 'stderr' | 'stdin' | 'system' | 'result' | 'prompt';

export interface ShellMessage {
  id: string;
  type: StreamType;
  text: string;
  timestamp: number;
}

export interface InstalledPackage {
  name: string;
  version: string;
  source: 'builtin' | 'micropip' | 'wheel';
  installedAt?: number;
}

export interface PipLogEntry {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  message: string;
  timestamp: number;
}

export interface PopularPackage {
  name: string;
  displayName: string;
  category: 'Math & Science' | 'Games & UI' | 'Data' | 'Utilities';
  description: string;
  recommendedImport: string;
}

export type ActiveAppView = 'editor' | 'shell' | 'files' | 'pip' | 'graphics';
