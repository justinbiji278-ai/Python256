/**
 * PyIDLE & Pydroid - Offline Service Worker
 * Ensures the entire Python IDE, WebAssembly CPython kernel, code editor,
 * terminal, and graphics run 100% offline without internet.
 * Only downloading new packages from PyPI requires an active internet connection.
 */

const CACHE_NAME = 'pyidle-offline-v1';

// Static resources to cache immediately
const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg',
  '/icon.png',
  '/icon-192.png',
];

// Install: precache core shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_URLS);
    }).then(() => self.skipWaiting())
  );
});

// Activate: clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch: Cache-first for Pyodide WebAssembly binaries and Google fonts,
// Stale-while-revalidate for application assets.
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // 1. Pyodide WebAssembly files & CDN assets -> Cache First!
  // Once downloaded once, they are permanently stored locally for offline Python execution!
  if (
    url.hostname.includes('jsdelivr.net') ||
    url.hostname.includes('pyodide') ||
    url.hostname.includes('fonts.googleapis.com') ||
    url.hostname.includes('fonts.gstatic.com') ||
    url.pathname.endsWith('.wasm') ||
    url.pathname.endsWith('.whl') ||
    url.pathname.endsWith('.zip')
  ) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }
        return fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
          return networkResponse;
        }).catch(() => {
          // If offline and not in cache, return error
          return new Response('Offline: Resource not cached yet', { status: 503 });
        });
      })
    );
    return;
  }

  // 2. Application HTML, JS, CSS -> Network first with cache fallback
  event.respondWith(
    fetch(event.request)
      .then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
        }
        return networkResponse;
      })
      .catch(() => {
        // If offline, serve cached version
        return caches.match(event.request).then((cached) => {
          return cached || caches.match('/');
        });
      })
  );
});
